let cats=require("./categroy/au.js")
let fNames=['au-en','be-fr','be-nl','bg-bg','ch-de','ch-fr','cz-cs','de-de','dk-da','ee-et','es-es','fi-fi','fr-fr','hr-hr','hu-hu','id-id','it-it','lt-lt','lv-lv','mea-ar','mea-en','mx-es','my-en','nl-nl','no-no','nz-en','pe-es','ph-en','pl-pl','pt-pt','ro-ro','rs-sr','se-sv','sg-en','sk-sk','th-th','uk-en','vn-vi','vn-en',"technics-au-en", "technics-be-fr", "technics-be-nl", "technics-bg-bg", "technics-ch-de", "technics-ch-fr", "technics-cz-cs", "technics-de-de", "technics-dk-da", "technics-ee-et", "technics-es-es", "technics-fi-fi", "technics-fr-fr", "technics-hr-hr", "technics-hu-hu", "technics-id-id", "technics-it-it", "technics-lt-lt", "technics-mx-es", "technics-my-en", "technics-nl-nl", "technics-no-no", "technics-nz-en", "technics-pe-es", "technics-pl-pl", "technics-pt-pt", "technics-ro-ro", "technics-se-sv", "technics-sg-en", "technics-sk-sk", "technics-th-th", "technics-uk-en"]
let targetpat=`${__dirname}/new/20220829/`
let fname=fNames[33] //33
// let fname="th-th"
let fs=require('fs')
var xlsx = require('node-xlsx');
let superagent=require("superagent")
var cheerio = require('cheerio');
let result=[['Title','Status','Modifed','Url','Template']]
let fetchpro=(url,nextpage="")=>{
    return new Promise((resolve,reject)=>{
        function pros(url,nextpage){
            superagent.get(url+nextpage).redirects(0).end(function(err,res){
                if(err){
                    console.log(err,'err')
                    resolve()
                }
                console.log(url+nextpage)
                if(res){
                    let $=cheerio.load(res.text)
                    if($("#categorybrowse-results").length>0){
                        $("#categorybrowse-results").find(".linkarea").each((i,el)=>{
                            let smn=$(el).find('.common-productbox-product__title__tx .num').text()
                            let hostpath=fname.indexOf("technics")==-1?'https://www.panasonic.com':"https://www.technics.com"
                            
                            let purl=hostpath+$(el).attr('href')
                            result.push([smn,'','',purl,''])
                        })
                        if($('.pagenation').length>0&&$('.pagenation .next a').length>0&&$('.pagenation .next a').attr('href')!="javascript:void(0);"){
                            let nxt=$('.pagenation .next a').attr('href')
                            pros(url,nxt)
                        }else{
                            
                          resolve()
                        }
                        
                    }else{
                        console.log("noproduct")
                        resolve()
                    }
                }
                
    
            })
        }
        pros(url,nextpage)
    })
}
let writefile=function(){
    return new Promise((resolve)=>{
        
        var buffer = xlsx.build([{name: 'product', data: result}]); 
        fs.writeFile(`${targetpat+fname}.xlsx`, buffer, function(err) {
            console.log('done')
            resolve()
        })
    })
}
async function run(){
    console.log(cats[fname])
    for(let i=0;i<cats[fname].length;i++){
        let cat=cats[fname][i]
        await fetchpro(cat)
        
    };
    await writefile()
}
run()

