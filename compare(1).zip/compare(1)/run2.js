let fs=require('fs')

var xlsx = require('node-xlsx');
var nowDate = new Date();
 var year = nowDate.getFullYear();
 var month = nowDate.getMonth() + 1 < 10 ? "0" + (nowDate.getMonth() + 1)
  : nowDate.getMonth() + 1;
 var day = nowDate.getDate() < 10 ? "0" + nowDate.getDate() : nowDate
  .getDate();
 var dateStr = year + month + day;


let oldpath=`${__dirname}/old/20220822/`
let newpath=`${__dirname}/new/20220829/`
// 获取文件夹下文件
let filename=fs.readdirSync(oldpath);
let newtemplate=[['Site','Title','Status','Modifed','Url','Template']]   //更新模板的产品
let newPage=[['Site','Title','Status','Modifed','Url','Template']]  //新作的产品
let temp_newpage={}
let temp_newtemplate={}

async function run (){
    filename.forEach((file,idx)=>{
        let site= file.split('.')[0]
        let fOld =  xlsx.parse(oldpath+file)[0].data
        let fNew =  xlsx.parse(newpath+file)[0].data
        // console.log(fNew)
        for(let pNew of fNew){
            // console.log(pNew)
            if(pNew[0]!="Title"){
                let newpageB=true
                for( pOld of fOld ){
                    if(pOld[0]!="Title"){

                        if( pNew[3]==pOld[3] ){
                            newpageB=false
                            if( pNew[4] != pOld[4] ){
                                newtemplate.push([site,...pNew])
                                
                                if(temp_newtemplate[site]){
                                    temp_newtemplate[site]++
                                }else{
                                    temp_newtemplate[site]=1
                                }
                            }
                            break;
                        }
                    }
                }
                if(newpageB){
                    // console.log(pNew)
                    newPage.push([site,...pNew])
                    if(temp_newpage[site]){
                        temp_newpage[site]++
                    }else{
                        temp_newpage[site]=1
                    }
                }
            }
            
        }
    })
    let merge_template=[] ,ci_tempalte=1
    for(site in temp_newtemplate ){
        if(temp_newtemplate[site]>1){
            let range = {s: {c: 0, r: ci_tempalte}, e: {c: 0, r: ci_tempalte+temp_newtemplate[site]-1}};
            
            merge_template.push(range)
        }
        ci_tempalte+= temp_newtemplate[site]
    }
    let merge_page=[] ,ci_page=1
    for( site in temp_newpage ){
        if(temp_newpage[site]>1){
            let range = {s: {c: 0, r: ci_page}, e: {c: 0, r: ci_page+temp_newpage[site]-1}};
            merge_page.push(range)
        }
        ci_page+= temp_newpage[site]
    }
    const Options_page = {'!merges': merge_page};
    var buffer = xlsx.build([{name: 'sheet1', data: newPage}], {sheetOptions:Options_page}); 
    fs.writeFile(`newpage_${dateStr}.xlsx`, buffer, function(err) {
        console.log('done')
    })
    const Options_template = {'!merges': merge_template};
    var buffer_template = xlsx.build([{name: 'sheet1', data: newtemplate}], {sheetOptions:Options_template}); 
    fs.writeFile(`newtemplate_${dateStr}.xlsx`, buffer_template, function(err) {
        console.log('done')
    })
}

run ()
// const data = [
//     [1, 2, 3],
//     [true, false, null, 'sheetjs'],
//     ['foo', 'bar', new Date('2014-02-19T14:30Z'), '0.3'],
//     ['baz', null, 'qux'],
// ];
//   const range = {s: {c: 0, r: 0}, e: {c: 0, r: 3}}; // A1:A4
//   const sheetOptions = {'!merges': [range]};
  
//   var buffer = xlsx.build([{name: 'mySheetName', data: data}], {sheetOptions}); 
//   fs.writeFile('test.xlsx', buffer, function(err) {
//     console.log('done')
// })