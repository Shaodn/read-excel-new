/*! lazysizes - v5.3.2 */
window.lazySizesConfig = window.lazySizesConfig || {};
lazySizesConfig.expand = 1500;
lazySizesConfig.expFactor = 3;
!function(e) {
    var t = function(u, D, f) {
        "use strict";
        var k, H;
        if (function() {
            var e;
            var t = {
                lazyClass: "lazyload",
                loadedClass: "lazyloaded",
                loadingClass: "lazyloading",
                preloadClass: "lazypreload",
                errorClass: "lazyerror",
                autosizesClass: "lazyautosizes",
                fastLoadedClass: "ls-is-cached",
                iframeLoadMode: 0,
                srcAttr: "data-src",
                srcsetAttr: "data-srcset",
                sizesAttr: "data-sizes",
                minSize: 40,
                customMedia: {},
                init: true,
                expFactor: 1.5,
                hFac: .8,
                loadMode: 2,
                loadHidden: true,
                ricTimeout: 0,
                throttleDelay: 125
            };
            H = u.lazySizesConfig || u.lazysizesConfig || {};
            for (e in t) {
                if (!(e in H)) {
                    H[e] = t[e]
                }
            }
        }(),
        !D || !D.getElementsByClassName) {
            return {
                init: function() {},
                cfg: H,
                noSupport: true
            }
        }
        var O = D.documentElement
          , i = u.HTMLPictureElement
          , P = "addEventListener"
          , $ = "getAttribute"
          , q = u[P].bind(u)
          , I = u.setTimeout
          , U = u.requestAnimationFrame || I
          , o = u.requestIdleCallback
          , j = /^picture$/i
          , r = ["load", "error", "lazyincluded", "_lazyloaded"]
          , a = {}
          , G = Array.prototype.forEach
          , J = function(e, t) {
            if (!a[t]) {
                a[t] = new RegExp("(\\s|^)" + t + "(\\s|$)")
            }
            return a[t].test(e[$]("class") || "") && a[t]
        }
          , K = function(e, t) {
            if (!J(e, t)) {
                e.setAttribute("class", (e[$]("class") || "").trim() + " " + t)
            }
        }
          , Q = function(e, t) {
            var a;
            if (a = J(e, t)) {
                e.setAttribute("class", (e[$]("class") || "").replace(a, " "))
            }
        }
          , V = function(t, a, e) {
            var i = e ? P : "removeEventListener";
            if (e) {
                V(t, a)
            }
            r.forEach(function(e) {
                t[i](e, a)
            })
        }
          , X = function(e, t, a, i, r) {
            var n = D.createEvent("Event");
            if (!a) {
                a = {}
            }
            a.instance = k;
            n.initEvent(t, !i, !r);
            n.detail = a;
            e.dispatchEvent(n);
            return n
        }
          , Y = function(e, t) {
            var a;
            if (!i && (a = u.picturefill || H.pf)) {
                if (t && t.src && !e[$]("srcset")) {
                    e.setAttribute("srcset", t.src)
                }
                a({
                    reevaluate: true,
                    elements: [e]
                })
            } else if (t && t.src) {
                e.src = t.src
            }
        }
          , Z = function(e, t) {
            return (getComputedStyle(e, null) || {})[t]
        }
          , s = function(e, t, a) {
            a = a || e.offsetWidth;
            while (a < H.minSize && t && !e._lazysizesWidth) {
                a = t.offsetWidth;
                t = t.parentNode
            }
            return a
        }
          , ee = function() {
            var a, i;
            var t = [];
            var r = [];
            var n = t;
            var s = function() {
                var e = n;
                n = t.length ? r : t;
                a = true;
                i = false;
                while (e.length) {
                    e.shift()()
                }
                a = false
            };
            var e = function(e, t) {
                if (a && !t) {
                    e.apply(this, arguments)
                } else {
                    n.push(e);
                    if (!i) {
                        i = true;
                        (D.hidden ? I : U)(s)
                    }
                }
            };
            e._lsFlush = s;
            return e
        }()
          , te = function(a, e) {
            return e ? function() {
                ee(a)
            }
            : function() {
                var e = this;
                var t = arguments;
                ee(function() {
                    a.apply(e, t)
                })
            }
        }
          , ae = function(e) {
            var a;
            var i = 0;
            var r = H.throttleDelay;
            var n = H.ricTimeout;
            var t = function() {
                a = false;
                i = f.now();
                e()
            };
            var s = o && n > 49 ? function() {
                o(t, {
                    timeout: n
                });
                if (n !== H.ricTimeout) {
                    n = H.ricTimeout
                }
            }
            : te(function() {
                I(t)
            }, true);
            return function(e) {
                var t;
                if (e = e === true) {
                    n = 33
                }
                if (a) {
                    return
                }
                a = true;
                t = r - (f.now() - i);
                if (t < 0) {
                    t = 0
                }
                if (e || t < 9) {
                    s()
                } else {
                    I(s, t)
                }
            }
        }
          , ie = function(e) {
            var t, a;
            var i = 99;
            var r = function() {
                t = null;
                e()
            };
            var n = function() {
                var e = f.now() - a;
                if (e < i) {
                    I(n, i - e)
                } else {
                    (o || r)(r)
                }
            };
            return function() {
                a = f.now();
                if (!t) {
                    t = I(n, i)
                }
            }
        }
          , e = function() {
            var v, m, c, h, e;
            var y, z, g, p, C, b, A;
            var n = /^img$/i;
            var d = /^iframe$/i;
            var E = "onscroll"in u && !/(gle|ing)bot/.test(navigator.userAgent);
            var _ = 0;
            var w = 0;
            var M = 0;
            var N = -1;
            var L = function(e) {
                M--;
                if (!e || M < 0 || !e.target) {
                    M = 0
                }
            };
            var x = function(e) {
                if (A == null) {
                    A = Z(D.body, "visibility") == "hidden"
                }
                return A || !(Z(e.parentNode, "visibility") == "hidden" && Z(e, "visibility") == "hidden")
            };
            var W = function(e, t) {
                var a;
                var i = e;
                var r = x(e);
                g -= t;
                b += t;
                p -= t;
                C += t;
                while (r && (i = i.offsetParent) && i != D.body && i != O) {
                    r = (Z(i, "opacity") || 1) > 0;
                    if (r && Z(i, "overflow") != "visible") {
                        a = i.getBoundingClientRect();
                        r = C > a.left && p < a.right && b > a.top - 1 && g < a.bottom + 1
                    }
                }
                return r
            };
            var t = function() {
                var e, t, a, i, r, n, s, o, l, u, f, c;
                var d = k.elements;
                if ((h = H.loadMode) && M < 8 && (e = d.length)) {
                    t = 0;
                    N++;
                    for (; t < e; t++) {
                        if (!d[t] || d[t]._lazyRace) {
                            continue
                        }
                        if (!E || k.prematureUnveil && k.prematureUnveil(d[t])) {
                            R(d[t]);
                            continue
                        }
                        if (!(o = d[t][$]("data-expand")) || !(n = o * 1)) {
                            n = w
                        }
                        if (!u) {
                            u = !H.expand || H.expand < 1 ? O.clientHeight > 500 && O.clientWidth > 500 ? 500 : 370 : H.expand;
                            k._defEx = u;
                            f = u * H.expFactor;
                            c = H.hFac;
                            A = null;
                            if (w < f && M < 1 && N > 2 && h > 2 && !D.hidden) {
                                w = f;
                                N = 0
                            } else if (h > 1 && N > 1 && M < 6) {
                                w = u
                            } else {
                                w = _
                            }
                        }
                        if (l !== n) {
                            y = innerWidth + n * c;
                            z = innerHeight + n;
                            s = n * -1;
                            l = n
                        }
                        a = d[t].getBoundingClientRect();
                        if ((b = a.bottom) >= s && (g = a.top) <= z && (C = a.right) >= s * c && (p = a.left) <= y && (b || C || p || g) && (H.loadHidden || x(d[t])) && (m && M < 3 && !o && (h < 3 || N < 4) || W(d[t], n))) {
                            R(d[t]);
                            r = true;
                            if (M > 9) {
                                break
                            }
                        } else if (!r && m && !i && M < 4 && N < 4 && h > 2 && (v[0] || H.preloadAfterLoad) && (v[0] || !o && (b || C || p || g || d[t][$](H.sizesAttr) != "auto"))) {
                            i = v[0] || d[t]
                        }
                    }
                    if (i && !r) {
                        R(i)
                    }
                }
            };
            var a = ae(t);
            var S = function(e) {
                var t = e.target;
                if (t._lazyCache) {
                    delete t._lazyCache;
                    return
                }
                L(e);
                K(t, H.loadedClass);
                Q(t, H.loadingClass);
                V(t, B);
                X(t, "lazyloaded")
            };
            var i = te(S);
            var B = function(e) {
                i({
                    target: e.target
                })
            };
            var T = function(e, t) {
                var a = e.getAttribute("data-load-mode") || H.iframeLoadMode;
                if (a == 0) {
                    e.contentWindow.location.replace(t)
                } else if (a == 1) {
                    e.src = t
                }
            };
            var F = function(e) {
                var t;
                var a = e[$](H.srcsetAttr);
                if (t = H.customMedia[e[$]("data-media") || e[$]("media")]) {
                    e.setAttribute("media", t)
                }
                if (a) {
                    e.setAttribute("srcset", a)
                }
            };
            var s = te(function(t, e, a, i, r) {
                var n, s, o, l, u, f;
                if (!(u = X(t, "lazybeforeunveil", e)).defaultPrevented) {
                    if (i) {
                        if (a) {
                            K(t, H.autosizesClass)
                        } else {
                            t.setAttribute("sizes", i)
                        }
                    }
                    s = t[$](H.srcsetAttr);
                    n = t[$](H.srcAttr);
                    if (r) {
                        o = t.parentNode;
                        l = o && j.test(o.nodeName || "")
                    }
                    f = e.firesLoad || "src"in t && (s || n || l);
                    u = {
                        target: t
                    };
                    K(t, H.loadingClass);
                    if (f) {
                        clearTimeout(c);
                        c = I(L, 2500);
                        V(t, B, true)
                    }
                    if (l) {
                        G.call(o.getElementsByTagName("source"), F)
                    }
                    if (s) {
                        t.setAttribute("srcset", s)
                    } else if (n && !l) {
                        if (d.test(t.nodeName)) {
                            T(t, n)
                        } else {
                            t.src = n
                        }
                    }
                    if (r && (s || l)) {
                        Y(t, {
                            src: n
                        })
                    }
                }
                if (t._lazyRace) {
                    delete t._lazyRace
                }
                Q(t, H.lazyClass);
                ee(function() {
                    var e = t.complete && t.naturalWidth > 1;
                    if (!f || e) {
                        if (e) {
                            K(t, H.fastLoadedClass)
                        }
                        S(u);
                        t._lazyCache = true;
                        I(function() {
                            if ("_lazyCache"in t) {
                                delete t._lazyCache
                            }
                        }, 9)
                    }
                    if (t.loading == "lazy") {
                        M--
                    }
                }, true)
            });
            var R = function(e) {
                if (e._lazyRace) {
                    return
                }
                var t;
                var a = n.test(e.nodeName);
                var i = a && (e[$](H.sizesAttr) || e[$]("sizes"));
                var r = i == "auto";
                if ((r || !m) && a && (e[$]("src") || e.srcset) && !e.complete && !J(e, H.errorClass) && J(e, H.lazyClass)) {
                    return
                }
                t = X(e, "lazyunveilread").detail;
                if (r) {
                    re.updateElem(e, true, e.offsetWidth)
                }
                e._lazyRace = true;
                M++;
                s(e, t, r, i, a)
            };
            var r = ie(function() {
                H.loadMode = 3;
                a()
            });
            var o = function() {
                if (H.loadMode == 3) {
                    H.loadMode = 2
                }
                r()
            };
            var l = function() {
                if (m) {
                    return
                }
                if (f.now() - e < 999) {
                    I(l, 999);
                    return
                }
                m = true;
                H.loadMode = 3;
                a();
                q("scroll", o, true)
            };
            return {
                _: function() {
                    e = f.now();
                    k.elements = D.getElementsByClassName(H.lazyClass);
                    v = D.getElementsByClassName(H.lazyClass + " " + H.preloadClass);
                    q("scroll", a, true);
                    q("resize", a, true);
                    q("pageshow", function(e) {
                        if (e.persisted) {
                            var t = D.querySelectorAll("." + H.loadingClass);
                            if (t.length && t.forEach) {
                                U(function() {
                                    t.forEach(function(e) {
                                        if (e.complete) {
                                            R(e)
                                        }
                                    })
                                })
                            }
                        }
                    });
                    if (u.MutationObserver) {
                        new MutationObserver(a).observe(O, {
                            childList: true,
                            subtree: true,
                            attributes: true
                        })
                    } else {
                        O[P]("DOMNodeInserted", a, true);
                        O[P]("DOMAttrModified", a, true);
                        setInterval(a, 999)
                    }
                    q("hashchange", a, true);
                    ["focus", "mouseover", "click", "load", "transitionend", "animationend"].forEach(function(e) {
                        D[P](e, a, true)
                    });
                    if (/d$|^c/.test(D.readyState)) {
                        l()
                    } else {
                        q("load", l);
                        D[P]("DOMContentLoaded", a);
                        I(l, 2e4)
                    }
                    if (k.elements.length) {
                        t();
                        ee._lsFlush()
                    } else {
                        a()
                    }
                },
                checkElems: a,
                unveil: R,
                _aLSL: o
            }
        }()
          , re = function() {
            var a;
            var n = te(function(e, t, a, i) {
                var r, n, s;
                e._lazysizesWidth = i;
                i += "px";
                e.setAttribute("sizes", i);
                if (j.test(t.nodeName || "")) {
                    r = t.getElementsByTagName("source");
                    for (n = 0,
                    s = r.length; n < s; n++) {
                        r[n].setAttribute("sizes", i)
                    }
                }
                if (!a.detail.dataAttr) {
                    Y(e, a.detail)
                }
            });
            var i = function(e, t, a) {
                var i;
                var r = e.parentNode;
                if (r) {
                    a = s(e, r, a);
                    i = X(e, "lazybeforesizes", {
                        width: a,
                        dataAttr: !!t
                    });
                    if (!i.defaultPrevented) {
                        a = i.detail.width;
                        if (a && a !== e._lazysizesWidth) {
                            n(e, r, i, a)
                        }
                    }
                }
            };
            var e = function() {
                var e;
                var t = a.length;
                if (t) {
                    e = 0;
                    for (; e < t; e++) {
                        i(a[e])
                    }
                }
            };
            var t = ie(e);
            return {
                _: function() {
                    a = D.getElementsByClassName(H.autosizesClass);
                    q("resize", t)
                },
                checkElems: t,
                updateElem: i
            }
        }()
          , t = function() {
            if (!t.i && D.getElementsByClassName) {
                t.i = true;
                re._();
                e._()
            }
        };
        return I(function() {
            H.init && t()
        }),
        k = {
            cfg: H,
            autoSizer: re,
            loader: e,
            init: t,
            uP: Y,
            aC: K,
            rC: Q,
            hC: J,
            fire: X,
            gW: s,
            rAF: ee
        }
    }(e, e.document, Date);
    e.lazySizes = t,
    "object" == typeof module && module.exports && (module.exports = t)
}("undefined" != typeof window ? window : {});
/*!
 * GSAP 3.10.4
 * https://greensock.com
 *
 * @license Copyright 2022, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
!function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? e(exports) : "function" == typeof define && define.amd ? define(["exports"], e) : e((t = t || self).window = t.window || {})
}(this, function(e) {
    "use strict";
    function _inheritsLoose(t, e) {
        t.prototype = Object.create(e.prototype),
        (t.prototype.constructor = t).__proto__ = e
    }
    function _assertThisInitialized(t) {
        if (void 0 === t)
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return t
    }
    function o(t) {
        return "string" == typeof t
    }
    function p(t) {
        return "function" == typeof t
    }
    function q(t) {
        return "number" == typeof t
    }
    function r(t) {
        return void 0 === t
    }
    function s(t) {
        return "object" == typeof t
    }
    function t(t) {
        return !1 !== t
    }
    function u() {
        return "undefined" != typeof window
    }
    function v(t) {
        return p(t) || o(t)
    }
    function M(t) {
        return (h = mt(t, ot)) && he
    }
    function N(t, e) {
        return console.warn("Invalid property", t, "set to", e, "Missing plugin? gsap.registerPlugin()")
    }
    function O(t, e) {
        return !e && console.warn(t)
    }
    function P(t, e) {
        return t && (ot[t] = e) && h && (h[t] = e) || ot
    }
    function Q() {
        return 0
    }
    function $(t) {
        var e, r, i = t[0];
        if (s(i) || p(i) || (t = [t]),
        !(e = (i._gsap || {}).harness)) {
            for (r = pt.length; r-- && !pt[r].targetTest(i); )
                ;
            e = pt[r]
        }
        for (r = t.length; r--; )
            t[r] && (t[r]._gsap || (t[r]._gsap = new Lt(t[r],e))) || t.splice(r, 1);
        return t
    }
    function _(t) {
        return t._gsap || $(xt(t))[0]._gsap
    }
    function aa(t, e, i) {
        return (i = t[e]) && p(i) ? t[e]() : r(i) && t.getAttribute && t.getAttribute(e) || i
    }
    function ba(t, e) {
        return (t = t.split(",")).forEach(e) || t
    }
    function ca(t) {
        return Math.round(1e5 * t) / 1e5 || 0
    }
    function da(t) {
        return Math.round(1e7 * t) / 1e7 || 0
    }
    function ea(t, e) {
        var r = e.charAt(0)
          , i = parseFloat(e.substr(2));
        return t = parseFloat(t),
        "+" === r ? t + i : "-" === r ? t - i : "*" === r ? t * i : t / i
    }
    function fa(t, e) {
        for (var r = e.length, i = 0; t.indexOf(e[i]) < 0 && ++i < r; )
            ;
        return i < r
    }
    function ga() {
        var t, e, r = ht.length, i = ht.slice(0);
        for (lt = {},
        t = ht.length = 0; t < r; t++)
            (e = i[t]) && e._lazy && (e.render(e._lazy[0], e._lazy[1], !0)._lazy = 0)
    }
    function ha(t, e, r, i) {
        ht.length && ga(),
        t.render(e, r, i),
        ht.length && ga()
    }
    function ia(t) {
        var e = parseFloat(t);
        return (e || 0 === e) && (t + "").match(at).length < 2 ? e : o(t) ? t.trim() : t
    }
    function ja(t) {
        return t
    }
    function ka(t, e) {
        for (var r in e)
            r in t || (t[r] = e[r]);
        return t
    }
    function na(t, e) {
        for (var r in e)
            "__proto__" !== r && "constructor" !== r && "prototype" !== r && (t[r] = s(e[r]) ? na(t[r] || (t[r] = {}), e[r]) : e[r]);
        return t
    }
    function oa(t, e) {
        var r, i = {};
        for (r in t)
            r in e || (i[r] = t[r]);
        return i
    }
    function pa(e) {
        var r = e.parent || I
          , i = e.keyframes ? function _setKeyframeDefaults(i) {
            return function(t, e) {
                for (var r in e)
                    r in t || "duration" === r && i || "ease" === r || (t[r] = e[r])
            }
        }(J(e.keyframes)) : ka;
        if (t(e.inherit))
            for (; r; )
                i(e, r.vars.defaults),
                r = r.parent || r._dp;
        return e
    }
    function ra(t, e, r, i, n) {
        void 0 === r && (r = "_first"),
        void 0 === i && (i = "_last");
        var a, s = t[i];
        if (n)
            for (a = e[n]; s && s[n] > a; )
                s = s._prev;
        return s ? (e._next = s._next,
        s._next = e) : (e._next = t[r],
        t[r] = e),
        e._next ? e._next._prev = e : t[i] = e,
        e._prev = s,
        e.parent = e._dp = t,
        e
    }
    function sa(t, e, r, i) {
        void 0 === r && (r = "_first"),
        void 0 === i && (i = "_last");
        var n = e._prev
          , a = e._next;
        n ? n._next = a : t[r] === e && (t[r] = a),
        a ? a._prev = n : t[i] === e && (t[i] = n),
        e._next = e._prev = e.parent = null
    }
    function ta(t, e) {
        !t.parent || e && !t.parent.autoRemoveChildren || t.parent.remove(t),
        t._act = 0
    }
    function ua(t, e) {
        if (t && (!e || e._end > t._dur || e._start < 0))
            for (var r = t; r; )
                r._dirty = 1,
                r = r.parent;
        return t
    }
    function xa(t) {
        return t._repeat ? gt(t._tTime, t = t.duration() + t._rDelay) * t : 0
    }
    function za(t, e) {
        return (t - e._start) * e._ts + (0 <= e._ts ? 0 : e._dirty ? e.totalDuration() : e._tDur)
    }
    function Aa(t) {
        return t._end = da(t._start + (t._tDur / Math.abs(t._ts || t._rts || V) || 0))
    }
    function Ba(t, e) {
        var r = t._dp;
        return r && r.smoothChildTiming && t._ts && (t._start = da(r._time - (0 < t._ts ? e / t._ts : ((t._dirty ? t.totalDuration() : t._tDur) - e) / -t._ts)),
        Aa(t),
        r._dirty || ua(r, t)),
        t
    }
    function Ca(t, e) {
        var r;
        if ((e._time || e._initted && !e._dur) && (r = za(t.rawTime(), e),
        (!e._dur || bt(0, e.totalDuration(), r) - e._tTime > V) && e.render(r, !0)),
        ua(t, e)._dp && t._initted && t._time >= t._dur && t._ts) {
            if (t._dur < t.duration())
                for (r = t; r._dp; )
                    0 <= r.rawTime() && r.totalTime(r._tTime),
                    r = r._dp;
            t._zTime = -V
        }
    }
    function Da(t, e, r, i) {
        return e.parent && ta(e),
        e._start = da((q(r) ? r : r || t !== I ? Tt(t, r, e) : t._time) + e._delay),
        e._end = da(e._start + (e.totalDuration() / Math.abs(e.timeScale()) || 0)),
        ra(t, e, "_first", "_last", t._sort ? "_start" : 0),
        vt(e) || (t._recent = e),
        i || Ca(t, e),
        t
    }
    function Ea(t, e) {
        return (ot.ScrollTrigger || N("scrollTrigger", e)) && ot.ScrollTrigger.create(e, t)
    }
    function Fa(t, e, r, i) {
        return Xt(t, e),
        t._initted ? !r && t._pt && (t._dur && !1 !== t.vars.lazy || !t._dur && t.vars.lazy) && f !== Dt.frame ? (ht.push(t),
        t._lazy = [e, i],
        1) : void 0 : 1
    }
    function Ka(t, e, r, i) {
        var n = t._repeat
          , a = da(e) || 0
          , s = t._tTime / t._tDur;
        return s && !i && (t._time *= a / t._dur),
        t._dur = a,
        t._tDur = n ? n < 0 ? 1e10 : da(a * (n + 1) + t._rDelay * n) : a,
        0 < s && !i ? Ba(t, t._tTime = t._tDur * s) : t.parent && Aa(t),
        r || ua(t.parent, t),
        t
    }
    function La(t) {
        return t instanceof Ut ? ua(t) : Ka(t, t._dur)
    }
    function Oa(e, r, i) {
        var n, a, s = q(r[1]), o = (s ? 2 : 1) + (e < 2 ? 0 : 1), u = r[o];
        if (s && (u.duration = r[1]),
        u.parent = i,
        e) {
            for (n = u,
            a = i; a && !("immediateRender"in n); )
                n = a.vars.defaults || {},
                a = t(a.vars.inherit) && a.parent;
            u.immediateRender = t(n.immediateRender),
            e < 2 ? u.runBackwards = 1 : u.startAt = r[o - 1]
        }
        return new $t(r[0],u,r[1 + o])
    }
    function Pa(t, e) {
        return t || 0 === t ? e(t) : e
    }
    function Ra(t, e) {
        return o(t) && (e = st.exec(t)) ? e[1] : ""
    }
    function Ua(t, e) {
        return t && s(t) && "length"in t && (!e && !t.length || t.length - 1 in t && s(t[0])) && !t.nodeType && t !== i
    }
    function Ya(t) {
        return t.sort(function() {
            return .5 - Math.random()
        })
    }
    function Za(t) {
        if (p(t))
            return t;
        var c = s(t) ? t : {
            each: t
        }
          , m = Bt(c.ease)
          , g = c.from || 0
          , v = parseFloat(c.base) || 0
          , y = {}
          , e = 0 < g && g < 1
          , T = isNaN(g) || e
          , b = c.axis
          , w = g
          , x = g;
        return o(g) ? w = x = {
            center: .5,
            edges: .5,
            end: 1
        }[g] || 0 : !e && T && (w = g[0],
        x = g[1]),
        function(t, e, r) {
            var i, n, a, s, o, u, h, l, f, d = (r || c).length, _ = y[d];
            if (!_) {
                if (!(f = "auto" === c.grid ? 0 : (c.grid || [1, Y])[1])) {
                    for (h = -Y; h < (h = r[f++].getBoundingClientRect().left) && f < d; )
                        ;
                    f--
                }
                for (_ = y[d] = [],
                i = T ? Math.min(f, d) * w - .5 : g % f,
                n = f === Y ? 0 : T ? d * x / f - .5 : g / f | 0,
                l = Y,
                u = h = 0; u < d; u++)
                    a = u % f - i,
                    s = n - (u / f | 0),
                    _[u] = o = b ? Math.abs("y" === b ? s : a) : G(a * a + s * s),
                    h < o && (h = o),
                    o < l && (l = o);
                "random" === g && Ya(_),
                _.max = h - l,
                _.min = l,
                _.v = d = (parseFloat(c.amount) || parseFloat(c.each) * (d < f ? d - 1 : b ? "y" === b ? d / f : f : Math.max(f, d / f)) || 0) * ("edges" === g ? -1 : 1),
                _.b = d < 0 ? v - d : v,
                _.u = Ra(c.amount || c.each) || 0,
                m = m && d < 0 ? Ft(m) : m
            }
            return d = (_[t] - _.min) / _.max || 0,
            da(_.b + (m ? m(d) : d) * _.v) + _.u
        }
    }
    function $a(r) {
        var i = Math.pow(10, ((r + "").split(".")[1] || "").length);
        return function(t) {
            var e = Math.round(parseFloat(t) / r) * r * i;
            return (e - e % 1) / i + (q(t) ? 0 : Ra(t))
        }
    }
    function _a(u, t) {
        var h, l, e = J(u);
        return !e && s(u) && (h = e = u.radius || Y,
        u.values ? (u = xt(u.values),
        (l = !q(u[0])) && (h *= h)) : u = $a(u.increment)),
        Pa(t, e ? p(u) ? function(t) {
            return l = u(t),
            Math.abs(l - t) <= h ? l : t
        }
        : function(t) {
            for (var e, r, i = parseFloat(l ? t.x : t), n = parseFloat(l ? t.y : 0), a = Y, s = 0, o = u.length; o--; )
                (e = l ? (e = u[o].x - i) * e + (r = u[o].y - n) * r : Math.abs(u[o] - i)) < a && (a = e,
                s = o);
            return s = !h || a <= h ? u[s] : t,
            l || s === t || q(t) ? s : s + Ra(t)
        }
        : $a(u))
    }
    function ab(t, e, r, i) {
        return Pa(J(t) ? !e : !0 === r ? !!(r = 0) : !i, function() {
            return J(t) ? t[~~(Math.random() * t.length)] : (r = r || 1e-5) && (i = r < 1 ? Math.pow(10, (r + "").length - 2) : 1) && Math.floor(Math.round((t - r / 2 + Math.random() * (e - t + .99 * r)) / r) * r * i) / i
        })
    }
    function eb(e, r, t) {
        return Pa(t, function(t) {
            return e[~~r(t)]
        })
    }
    function hb(t) {
        for (var e, r, i, n, a = 0, s = ""; ~(e = t.indexOf("random(", a)); )
            i = t.indexOf(")", e),
            n = "[" === t.charAt(e + 7),
            r = t.substr(e + 7, i - e - 7).match(n ? at : tt),
            s += t.substr(a, e - a) + ab(n ? r : +r[0], n ? 0 : +r[1], +r[2] || 1e-5),
            a = i + 1;
        return s + t.substr(a, t.length - a)
    }
    function kb(t, e, r) {
        var i, n, a, s = t.labels, o = Y;
        for (i in s)
            (n = s[i] - e) < 0 == !!r && n && o > (n = Math.abs(n)) && (a = i,
            o = n);
        return a
    }
    function mb(t) {
        return ta(t),
        t.scrollTrigger && t.scrollTrigger.kill(!1),
        t.progress() < 1 && Ot(t, "onInterrupt"),
        t
    }
    function rb(t, e, r) {
        return (6 * (t += t < 0 ? 1 : 1 < t ? -1 : 0) < 1 ? e + (r - e) * t * 6 : t < .5 ? r : 3 * t < 2 ? e + (r - e) * (2 / 3 - t) * 6 : e) * Pt + .5 | 0
    }
    function sb(t, e, r) {
        var i, n, a, s, o, u, h, l, f, d, _ = t ? q(t) ? [t >> 16, t >> 8 & Pt, t & Pt] : 0 : Mt.black;
        if (!_) {
            if ("," === t.substr(-1) && (t = t.substr(0, t.length - 1)),
            Mt[t])
                _ = Mt[t];
            else if ("#" === t.charAt(0)) {
                if (t.length < 6 && (t = "#" + (i = t.charAt(1)) + i + (n = t.charAt(2)) + n + (a = t.charAt(3)) + a + (5 === t.length ? t.charAt(4) + t.charAt(4) : "")),
                9 === t.length)
                    return [(_ = parseInt(t.substr(1, 6), 16)) >> 16, _ >> 8 & Pt, _ & Pt, parseInt(t.substr(7), 16) / 255];
                _ = [(t = parseInt(t.substr(1), 16)) >> 16, t >> 8 & Pt, t & Pt]
            } else if ("hsl" === t.substr(0, 3))
                if (_ = d = t.match(tt),
                e) {
                    if (~t.indexOf("="))
                        return _ = t.match(et),
                        r && _.length < 4 && (_[3] = 1),
                        _
                } else
                    s = +_[0] % 360 / 360,
                    o = _[1] / 100,
                    i = 2 * (u = _[2] / 100) - (n = u <= .5 ? u * (o + 1) : u + o - u * o),
                    3 < _.length && (_[3] *= 1),
                    _[0] = rb(s + 1 / 3, i, n),
                    _[1] = rb(s, i, n),
                    _[2] = rb(s - 1 / 3, i, n);
            else
                _ = t.match(tt) || Mt.transparent;
            _ = _.map(Number)
        }
        return e && !d && (i = _[0] / Pt,
        n = _[1] / Pt,
        a = _[2] / Pt,
        u = ((h = Math.max(i, n, a)) + (l = Math.min(i, n, a))) / 2,
        h === l ? s = o = 0 : (f = h - l,
        o = .5 < u ? f / (2 - h - l) : f / (h + l),
        s = h === i ? (n - a) / f + (n < a ? 6 : 0) : h === n ? (a - i) / f + 2 : (i - n) / f + 4,
        s *= 60),
        _[0] = ~~(s + .5),
        _[1] = ~~(100 * o + .5),
        _[2] = ~~(100 * u + .5)),
        r && _.length < 4 && (_[3] = 1),
        _
    }
    function tb(t) {
        var r = []
          , i = []
          , n = -1;
        return t.split(Ct).forEach(function(t) {
            var e = t.match(rt) || [];
            r.push.apply(r, e),
            i.push(n += e.length + 1)
        }),
        r.c = i,
        r
    }
    function ub(t, e, r) {
        var i, n, a, s, o = "", u = (t + o).match(Ct), h = e ? "hsla(" : "rgba(", l = 0;
        if (!u)
            return t;
        if (u = u.map(function(t) {
            return (t = sb(t, e, 1)) && h + (e ? t[0] + "," + t[1] + "%," + t[2] + "%," + t[3] : t.join(",")) + ")"
        }),
        r && (a = tb(t),
        (i = r.c).join(o) !== a.c.join(o)))
            for (s = (n = t.replace(Ct, "1").split(rt)).length - 1; l < s; l++)
                o += n[l] + (~i.indexOf(l) ? u.shift() || h + "0,0,0,0)" : (a.length ? a : u.length ? u : r).shift());
        if (!n)
            for (s = (n = t.split(Ct)).length - 1; l < s; l++)
                o += n[l] + u[l];
        return o + n[s]
    }
    function xb(t) {
        var e, r = t.join(" ");
        if (Ct.lastIndex = 0,
        Ct.test(r))
            return e = At.test(r),
            t[1] = ub(t[1], e),
            t[0] = ub(t[0], e, tb(t[1])),
            !0
    }
    function Gb(t) {
        var e = (t + "").split("(")
          , r = zt[e[0]];
        return r && 1 < e.length && r.config ? r.config.apply(null, ~t.indexOf("{") ? [function _parseObjectInString(t) {
            for (var e, r, i, n = {}, a = t.substr(1, t.length - 3).split(":"), s = a[0], o = 1, u = a.length; o < u; o++)
                r = a[o],
                e = o !== u - 1 ? r.lastIndexOf(",") : r.length,
                i = r.substr(0, e),
                n[s] = isNaN(i) ? i.replace(Et, "").trim() : +i,
                s = r.substr(e + 1).trim();
            return n
        }(e[1])] : function _valueInParentheses(t) {
            var e = t.indexOf("(") + 1
              , r = t.indexOf(")")
              , i = t.indexOf("(", e);
            return t.substring(e, ~i && i < r ? t.indexOf(")", r + 1) : r)
        }(t).split(",").map(ia)) : zt._CE && Rt.test(t) ? zt._CE("", t) : r
    }
    function Ib(t, e) {
        for (var r, i = t._first; i; )
            i instanceof Ut ? Ib(i, e) : !i.vars.yoyoEase || i._yoyo && i._repeat || i._yoyo === e || (i.timeline ? Ib(i.timeline, e) : (r = i._ease,
            i._ease = i._yEase,
            i._yEase = r,
            i._yoyo = e)),
            i = i._next
    }
    function Kb(t, e, r, i) {
        void 0 === r && (r = function easeOut(t) {
            return 1 - e(1 - t)
        }
        ),
        void 0 === i && (i = function easeInOut(t) {
            return t < .5 ? e(2 * t) / 2 : 1 - e(2 * (1 - t)) / 2
        }
        );
        var n, a = {
            easeIn: e,
            easeOut: r,
            easeInOut: i
        };
        return ba(t, function(t) {
            for (var e in zt[t] = ot[t] = a,
            zt[n = t.toLowerCase()] = r,
            a)
                zt[n + ("easeIn" === e ? ".in" : "easeOut" === e ? ".out" : ".inOut")] = zt[t + "." + e] = a[e]
        }),
        a
    }
    function Lb(e) {
        return function(t) {
            return t < .5 ? (1 - e(1 - 2 * t)) / 2 : .5 + e(2 * (t - .5)) / 2
        }
    }
    function Mb(r, t, e) {
        function em(t) {
            return 1 === t ? 1 : i * Math.pow(2, -10 * t) * Z((t - a) * n) + 1
        }
        var i = 1 <= t ? t : 1
          , n = (e || (r ? .3 : .45)) / (t < 1 ? t : 1)
          , a = n / X * (Math.asin(1 / i) || 0)
          , s = "out" === r ? em : "in" === r ? function(t) {
            return 1 - em(1 - t)
        }
        : Lb(em);
        return n = X / n,
        s.config = function(t, e) {
            return Mb(r, t, e)
        }
        ,
        s
    }
    function Nb(e, r) {
        function mm(t) {
            return t ? --t * t * ((r + 1) * t + r) + 1 : 0
        }
        void 0 === r && (r = 1.70158);
        var t = "out" === e ? mm : "in" === e ? function(t) {
            return 1 - mm(1 - t)
        }
        : Lb(mm);
        return t.config = function(t) {
            return Nb(e, t)
        }
        ,
        t
    }
    var B, I, i, n, a, h, l, f, d, c, m, g, y, T, b, w, x, k, C, A, D, S, z, R, E, F, U = {
        autoSleep: 120,
        force3D: "auto",
        nullTargetWarn: 1,
        units: {
            lineHeight: ""
        }
    }, L = {
        duration: .5,
        overwrite: !1,
        delay: 0
    }, Y = 1e8, V = 1 / Y, X = 2 * Math.PI, j = X / 4, K = 0, G = Math.sqrt, W = Math.cos, Z = Math.sin, H = "function" == typeof ArrayBuffer && ArrayBuffer.isView || function() {}
    , J = Array.isArray, tt = /(?:-?\.?\d|\.)+/gi, et = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g, rt = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g, it = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi, nt = /[+-]=-?[.\d]+/, at = /[^,'"\[\]\s]+/gi, st = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i, ot = {}, ut = {}, ht = [], lt = {}, ft = {}, dt = {}, _t = 30, pt = [], ct = "", mt = function _merge(t, e) {
        for (var r in e)
            t[r] = e[r];
        return t
    }, gt = function _animationCycle(t, e) {
        var r = Math.floor(t /= e);
        return t && r === t ? r - 1 : r
    }, vt = function _isFromOrFromStart(t) {
        var e = t.data;
        return "isFromStart" === e || "isStart" === e
    }, yt = {
        _start: 0,
        endTime: Q,
        totalDuration: Q
    }, Tt = function _parsePosition(t, e, r) {
        var i, n, a, s = t.labels, u = t._recent || yt, h = t.duration() >= Y ? u.endTime(!1) : t._dur;
        return o(e) && (isNaN(e) || e in s) ? (n = e.charAt(0),
        a = "%" === e.substr(-1),
        i = e.indexOf("="),
        "<" === n || ">" === n ? (0 <= i && (e = e.replace(/=/, "")),
        ("<" === n ? u._start : u.endTime(0 <= u._repeat)) + (parseFloat(e.substr(1)) || 0) * (a ? (i < 0 ? u : r).totalDuration() / 100 : 1)) : i < 0 ? (e in s || (s[e] = h),
        s[e]) : (n = parseFloat(e.charAt(i - 1) + e.substr(i + 1)),
        a && r && (n = n / 100 * (J(r) ? r[0] : r).totalDuration()),
        1 < i ? _parsePosition(t, e.substr(0, i - 1), r) + n : h + n)) : null == e ? h : +e
    }, bt = function _clamp(t, e, r) {
        return r < t ? t : e < r ? e : r
    }, wt = [].slice, xt = function toArray(t, e, r) {
        return !o(t) || r || !n && St() ? J(t) ? function _flatten(t, e, r) {
            return void 0 === r && (r = []),
            t.forEach(function(t) {
                return o(t) && !e || Ua(t, 1) ? r.push.apply(r, xt(t)) : r.push(t)
            }) || r
        }(t, r) : Ua(t) ? wt.call(t, 0) : t ? [t] : [] : wt.call((e || a).querySelectorAll(t), 0)
    }, kt = function mapRange(e, t, r, i, n) {
        var a = t - e
          , s = i - r;
        return Pa(n, function(t) {
            return r + ((t - e) / a * s || 0)
        })
    }, Ot = function _callback(t, e, r) {
        var i, n, a = t.vars, s = a[e];
        if (s)
            return i = a[e + "Params"],
            n = a.callbackScope || t,
            r && ht.length && ga(),
            i ? s.apply(n, i) : s.call(n)
    }, Pt = 255, Mt = {
        aqua: [0, Pt, Pt],
        lime: [0, Pt, 0],
        silver: [192, 192, 192],
        black: [0, 0, 0],
        maroon: [128, 0, 0],
        teal: [0, 128, 128],
        blue: [0, 0, Pt],
        navy: [0, 0, 128],
        white: [Pt, Pt, Pt],
        olive: [128, 128, 0],
        yellow: [Pt, Pt, 0],
        orange: [Pt, 165, 0],
        gray: [128, 128, 128],
        purple: [128, 0, 128],
        green: [0, 128, 0],
        red: [Pt, 0, 0],
        pink: [Pt, 192, 203],
        cyan: [0, Pt, Pt],
        transparent: [Pt, Pt, Pt, 0]
    }, Ct = function() {
        var t, e = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b";
        for (t in Mt)
            e += "|" + t + "\\b";
        return new RegExp(e + ")","gi")
    }(), At = /hsl[a]?\(/, Dt = (x = Date.now,
    k = 500,
    C = 33,
    A = x(),
    D = A,
    z = S = 1e3 / 240,
    T = {
        time: 0,
        frame: 0,
        tick: function tick() {
            Vk(!0)
        },
        deltaRatio: function deltaRatio(t) {
            return b / (1e3 / (t || 60))
        },
        wake: function wake() {
            l && (!n && u() && (i = n = window,
            a = i.document || {},
            ot.gsap = he,
            (i.gsapVersions || (i.gsapVersions = [])).push(he.version),
            M(h || i.GreenSockGlobals || !i.gsap && i || {}),
            y = i.requestAnimationFrame),
            m && T.sleep(),
            g = y || function(t) {
                return setTimeout(t, z - 1e3 * T.time + 1 | 0)
            }
            ,
            c = 1,
            Vk(2))
        },
        sleep: function sleep() {
            (y ? i.cancelAnimationFrame : clearTimeout)(m),
            c = 0,
            g = Q
        },
        lagSmoothing: function lagSmoothing(t, e) {
            k = t || 1e8,
            C = Math.min(e, k, 0)
        },
        fps: function fps(t) {
            S = 1e3 / (t || 240),
            z = 1e3 * T.time + S
        },
        add: function add(n, t, e) {
            var a = t ? function(t, e, r, i) {
                n(t, e, r, i),
                T.remove(a)
            }
            : n;
            return T.remove(n),
            R[e ? "unshift" : "push"](a),
            St(),
            a
        },
        remove: function remove(t, e) {
            ~(e = R.indexOf(t)) && R.splice(e, 1) && e <= w && w--
        },
        _listeners: R = []
    }), St = function _wake() {
        return !c && Dt.wake()
    }, zt = {}, Rt = /^[\d.\-M][\d.\-,\s]/, Et = /["']/g, Ft = function _invertEase(e) {
        return function(t) {
            return 1 - e(1 - t)
        }
    }, Bt = function _parseEase(t, e) {
        return t && (p(t) ? t : zt[t] || Gb(t)) || e
    };
    function Vk(t) {
        var e, r, i, n, a = x() - D, s = !0 === t;
        if (k < a && (A += a - C),
        (0 < (e = (i = (D += a) - A) - z) || s) && (n = ++T.frame,
        b = i - 1e3 * T.time,
        T.time = i /= 1e3,
        z += e + (S <= e ? 4 : S - e),
        r = 1),
        s || (m = g(Vk)),
        r)
            for (w = 0; w < R.length; w++)
                R[w](i, b, n, t)
    }
    function Dm(t) {
        return t < F ? E * t * t : t < .7272727272727273 ? E * Math.pow(t - 1.5 / 2.75, 2) + .75 : t < .9090909090909092 ? E * (t -= 2.25 / 2.75) * t + .9375 : E * Math.pow(t - 2.625 / 2.75, 2) + .984375
    }
    ba("Linear,Quad,Cubic,Quart,Quint,Strong", function(t, e) {
        var r = e < 5 ? e + 1 : e;
        Kb(t + ",Power" + (r - 1), e ? function(t) {
            return Math.pow(t, r)
        }
        : function(t) {
            return t
        }
        , function(t) {
            return 1 - Math.pow(1 - t, r)
        }, function(t) {
            return t < .5 ? Math.pow(2 * t, r) / 2 : 1 - Math.pow(2 * (1 - t), r) / 2
        })
    }),
    zt.Linear.easeNone = zt.none = zt.Linear.easeIn,
    Kb("Elastic", Mb("in"), Mb("out"), Mb()),
    E = 7.5625,
    F = 1 / 2.75,
    Kb("Bounce", function(t) {
        return 1 - Dm(1 - t)
    }, Dm),
    Kb("Expo", function(t) {
        return t ? Math.pow(2, 10 * (t - 1)) : 0
    }),
    Kb("Circ", function(t) {
        return -(G(1 - t * t) - 1)
    }),
    Kb("Sine", function(t) {
        return 1 === t ? 1 : 1 - W(t * j)
    }),
    Kb("Back", Nb("in"), Nb("out"), Nb()),
    zt.SteppedEase = zt.steps = ot.SteppedEase = {
        config: function config(t, e) {
            void 0 === t && (t = 1);
            var r = 1 / t
              , i = t + (e ? 0 : 1)
              , n = e ? 1 : 0;
            return function(t) {
                return ((i * bt(0, .99999999, t) | 0) + n) * r
            }
        }
    },
    L.ease = zt["quad.out"],
    ba("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(t) {
        return ct += t + "," + t + "Params,"
    });
    var It, Lt = function GSCache(t, e) {
        this.id = K++,
        (t._gsap = this).target = t,
        this.harness = e,
        this.get = e ? e.get : aa,
        this.set = e ? e.getSetter : Ht
    }, Nt = ((It = Animation.prototype).delay = function delay(t) {
        return t || 0 === t ? (this.parent && this.parent.smoothChildTiming && this.startTime(this._start + t - this._delay),
        this._delay = t,
        this) : this._delay
    }
    ,
    It.duration = function duration(t) {
        return arguments.length ? this.totalDuration(0 < this._repeat ? t + (t + this._rDelay) * this._repeat : t) : this.totalDuration() && this._dur
    }
    ,
    It.totalDuration = function totalDuration(t) {
        return arguments.length ? (this._dirty = 0,
        Ka(this, this._repeat < 0 ? t : (t - this._repeat * this._rDelay) / (this._repeat + 1))) : this._tDur
    }
    ,
    It.totalTime = function totalTime(t, e) {
        if (St(),
        !arguments.length)
            return this._tTime;
        var r = this._dp;
        if (r && r.smoothChildTiming && this._ts) {
            for (Ba(this, t),
            !r._dp || r.parent || Ca(r, this); r && r.parent; )
                r.parent._time !== r._start + (0 <= r._ts ? r._tTime / r._ts : (r.totalDuration() - r._tTime) / -r._ts) && r.totalTime(r._tTime, !0),
                r = r.parent;
            !this.parent && this._dp.autoRemoveChildren && (0 < this._ts && t < this._tDur || this._ts < 0 && 0 < t || !this._tDur && !t) && Da(this._dp, this, this._start - this._delay)
        }
        return (this._tTime !== t || !this._dur && !e || this._initted && Math.abs(this._zTime) === V || !t && !this._initted && (this.add || this._ptLookup)) && (this._ts || (this._pTime = t),
        ha(this, t, e)),
        this
    }
    ,
    It.time = function time(t, e) {
        return arguments.length ? this.totalTime(Math.min(this.totalDuration(), t + xa(this)) % (this._dur + this._rDelay) || (t ? this._dur : 0), e) : this._time
    }
    ,
    It.totalProgress = function totalProgress(t, e) {
        return arguments.length ? this.totalTime(this.totalDuration() * t, e) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.ratio
    }
    ,
    It.progress = function progress(t, e) {
        return arguments.length ? this.totalTime(this.duration() * (!this._yoyo || 1 & this.iteration() ? t : 1 - t) + xa(this), e) : this.duration() ? Math.min(1, this._time / this._dur) : this.ratio
    }
    ,
    It.iteration = function iteration(t, e) {
        var r = this.duration() + this._rDelay;
        return arguments.length ? this.totalTime(this._time + (t - 1) * r, e) : this._repeat ? gt(this._tTime, r) + 1 : 1
    }
    ,
    It.timeScale = function timeScale(t) {
        if (!arguments.length)
            return this._rts === -V ? 0 : this._rts;
        if (this._rts === t)
            return this;
        var e = this.parent && this._ts ? za(this.parent._time, this) : this._tTime;
        return this._rts = +t || 0,
        this._ts = this._ps || t === -V ? 0 : this._rts,
        this.totalTime(bt(-this._delay, this._tDur, e), !0),
        Aa(this),
        function _recacheAncestors(t) {
            for (var e = t.parent; e && e.parent; )
                e._dirty = 1,
                e.totalDuration(),
                e = e.parent;
            return t
        }(this)
    }
    ,
    It.paused = function paused(t) {
        return arguments.length ? (this._ps !== t && ((this._ps = t) ? (this._pTime = this._tTime || Math.max(-this._delay, this.rawTime()),
        this._ts = this._act = 0) : (St(),
        this._ts = this._rts,
        this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, 1 === this.progress() && Math.abs(this._zTime) !== V && (this._tTime -= V)))),
        this) : this._ps
    }
    ,
    It.startTime = function startTime(t) {
        if (arguments.length) {
            this._start = t;
            var e = this.parent || this._dp;
            return !e || !e._sort && this.parent || Da(e, this, t - this._delay),
            this
        }
        return this._start
    }
    ,
    It.endTime = function endTime(e) {
        return this._start + (t(e) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1)
    }
    ,
    It.rawTime = function rawTime(t) {
        var e = this.parent || this._dp;
        return e ? t && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : this._ts ? za(e.rawTime(t), this) : this._tTime : this._tTime
    }
    ,
    It.globalTime = function globalTime(t) {
        for (var e = this, r = arguments.length ? t : e.rawTime(); e; )
            r = e._start + r / (e._ts || 1),
            e = e._dp;
        return r
    }
    ,
    It.repeat = function repeat(t) {
        return arguments.length ? (this._repeat = t === 1 / 0 ? -2 : t,
        La(this)) : -2 === this._repeat ? 1 / 0 : this._repeat
    }
    ,
    It.repeatDelay = function repeatDelay(t) {
        if (arguments.length) {
            var e = this._time;
            return this._rDelay = t,
            La(this),
            e ? this.time(e) : this
        }
        return this._rDelay
    }
    ,
    It.yoyo = function yoyo(t) {
        return arguments.length ? (this._yoyo = t,
        this) : this._yoyo
    }
    ,
    It.seek = function seek(e, r) {
        return this.totalTime(Tt(this, e), t(r))
    }
    ,
    It.restart = function restart(e, r) {
        return this.play().totalTime(e ? -this._delay : 0, t(r))
    }
    ,
    It.play = function play(t, e) {
        return null != t && this.seek(t, e),
        this.reversed(!1).paused(!1)
    }
    ,
    It.reverse = function reverse(t, e) {
        return null != t && this.seek(t || this.totalDuration(), e),
        this.reversed(!0).paused(!1)
    }
    ,
    It.pause = function pause(t, e) {
        return null != t && this.seek(t, e),
        this.paused(!0)
    }
    ,
    It.resume = function resume() {
        return this.paused(!1)
    }
    ,
    It.reversed = function reversed(t) {
        return arguments.length ? (!!t !== this.reversed() && this.timeScale(-this._rts || (t ? -V : 0)),
        this) : this._rts < 0
    }
    ,
    It.invalidate = function invalidate() {
        return this._initted = this._act = 0,
        this._zTime = -V,
        this
    }
    ,
    It.isActive = function isActive() {
        var t, e = this.parent || this._dp, r = this._start;
        return !(e && !(this._ts && this._initted && e.isActive() && (t = e.rawTime(!0)) >= r && t < this.endTime(!0) - V))
    }
    ,
    It.eventCallback = function eventCallback(t, e, r) {
        var i = this.vars;
        return 1 < arguments.length ? (e ? (i[t] = e,
        r && (i[t + "Params"] = r),
        "onUpdate" === t && (this._onUpdate = e)) : delete i[t],
        this) : i[t]
    }
    ,
    It.then = function then(t) {
        var i = this;
        return new Promise(function(e) {
            function Un() {
                var t = i.then;
                i.then = null,
                p(r) && (r = r(i)) && (r.then || r === i) && (i.then = t),
                e(r),
                i.then = t
            }
            var r = p(t) ? t : ja;
            i._initted && 1 === i.totalProgress() && 0 <= i._ts || !i._tTime && i._ts < 0 ? Un() : i._prom = Un
        }
        )
    }
    ,
    It.kill = function kill() {
        mb(this)
    }
    ,
    Animation);
    function Animation(t) {
        this.vars = t,
        this._delay = +t.delay || 0,
        (this._repeat = t.repeat === 1 / 0 ? -2 : t.repeat || 0) && (this._rDelay = t.repeatDelay || 0,
        this._yoyo = !!t.yoyo || !!t.yoyoEase),
        this._ts = 1,
        Ka(this, +t.duration, 1, 1),
        this.data = t.data,
        c || Dt.wake()
    }
    ka(Nt.prototype, {
        _time: 0,
        _start: 0,
        _end: 0,
        _tTime: 0,
        _tDur: 0,
        _dirty: 0,
        _repeat: 0,
        _yoyo: !1,
        parent: null,
        _initted: !1,
        _rDelay: 0,
        _ts: 1,
        _dp: 0,
        ratio: 0,
        _zTime: -V,
        _prom: 0,
        _ps: !1,
        _rts: 1
    });
    var Ut = function(n) {
        function Timeline(e, r) {
            var i;
            return void 0 === e && (e = {}),
            (i = n.call(this, e) || this).labels = {},
            i.smoothChildTiming = !!e.smoothChildTiming,
            i.autoRemoveChildren = !!e.autoRemoveChildren,
            i._sort = t(e.sortChildren),
            I && Da(e.parent || I, _assertThisInitialized(i), r),
            e.reversed && i.reverse(),
            e.paused && i.paused(!0),
            e.scrollTrigger && Ea(_assertThisInitialized(i), e.scrollTrigger),
            i
        }
        _inheritsLoose(Timeline, n);
        var e = Timeline.prototype;
        return e.to = function to(t, e, r) {
            return Oa(0, arguments, this),
            this
        }
        ,
        e.from = function from(t, e, r) {
            return Oa(1, arguments, this),
            this
        }
        ,
        e.fromTo = function fromTo(t, e, r, i) {
            return Oa(2, arguments, this),
            this
        }
        ,
        e.set = function set(t, e, r) {
            return e.duration = 0,
            e.parent = this,
            pa(e).repeatDelay || (e.repeat = 0),
            e.immediateRender = !!e.immediateRender,
            new $t(t,e,Tt(this, r),1),
            this
        }
        ,
        e.call = function call(t, e, r) {
            return Da(this, $t.delayedCall(0, t, e), r)
        }
        ,
        e.staggerTo = function staggerTo(t, e, r, i, n, a, s) {
            return r.duration = e,
            r.stagger = r.stagger || i,
            r.onComplete = a,
            r.onCompleteParams = s,
            r.parent = this,
            new $t(t,r,Tt(this, n)),
            this
        }
        ,
        e.staggerFrom = function staggerFrom(e, r, i, n, a, s, o) {
            return i.runBackwards = 1,
            pa(i).immediateRender = t(i.immediateRender),
            this.staggerTo(e, r, i, n, a, s, o)
        }
        ,
        e.staggerFromTo = function staggerFromTo(e, r, i, n, a, s, o, u) {
            return n.startAt = i,
            pa(n).immediateRender = t(n.immediateRender),
            this.staggerTo(e, r, n, a, s, o, u)
        }
        ,
        e.render = function render(t, e, r) {
            var i, n, a, s, o, u, h, l, f, d, _, p, c = this._time, m = this._dirty ? this.totalDuration() : this._tDur, g = this._dur, v = t <= 0 ? 0 : da(t), y = this._zTime < 0 != t < 0 && (this._initted || !g);
            if (this !== I && m < v && 0 <= t && (v = m),
            v !== this._tTime || r || y) {
                if (c !== this._time && g && (v += this._time - c,
                t += this._time - c),
                i = v,
                f = this._start,
                u = !(l = this._ts),
                y && (g || (c = this._zTime),
                !t && e || (this._zTime = t)),
                this._repeat) {
                    if (_ = this._yoyo,
                    o = g + this._rDelay,
                    this._repeat < -1 && t < 0)
                        return this.totalTime(100 * o + t, e, r);
                    if (i = da(v % o),
                    v === m ? (s = this._repeat,
                    i = g) : ((s = ~~(v / o)) && s === v / o && (i = g,
                    s--),
                    g < i && (i = g)),
                    d = gt(this._tTime, o),
                    !c && this._tTime && d !== s && (d = s),
                    _ && 1 & s && (i = g - i,
                    p = 1),
                    s !== d && !this._lock) {
                        var T = _ && 1 & d
                          , b = T === (_ && 1 & s);
                        if (s < d && (T = !T),
                        c = T ? 0 : g,
                        this._lock = 1,
                        this.render(c || (p ? 0 : da(s * o)), e, !g)._lock = 0,
                        this._tTime = v,
                        !e && this.parent && Ot(this, "onRepeat"),
                        this.vars.repeatRefresh && !p && (this.invalidate()._lock = 1),
                        c && c !== this._time || u != !this._ts || this.vars.onRepeat && !this.parent && !this._act)
                            return this;
                        if (g = this._dur,
                        m = this._tDur,
                        b && (this._lock = 2,
                        c = T ? g : -1e-4,
                        this.render(c, !0),
                        this.vars.repeatRefresh && !p && this.invalidate()),
                        this._lock = 0,
                        !this._ts && !u)
                            return this;
                        Ib(this, p)
                    }
                }
                if (this._hasPause && !this._forcing && this._lock < 2 && (h = function _findNextPauseTween(t, e, r) {
                    var i;
                    if (e < r)
                        for (i = t._first; i && i._start <= r; ) {
                            if ("isPause" === i.data && i._start > e)
                                return i;
                            i = i._next
                        }
                    else
                        for (i = t._last; i && i._start >= r; ) {
                            if ("isPause" === i.data && i._start < e)
                                return i;
                            i = i._prev
                        }
                }(this, da(c), da(i))) && (v -= i - (i = h._start)),
                this._tTime = v,
                this._time = i,
                this._act = !l,
                this._initted || (this._onUpdate = this.vars.onUpdate,
                this._initted = 1,
                this._zTime = t,
                c = 0),
                !c && i && !e && (Ot(this, "onStart"),
                this._tTime !== v))
                    return this;
                if (c <= i && 0 <= t)
                    for (n = this._first; n; ) {
                        if (a = n._next,
                        (n._act || i >= n._start) && n._ts && h !== n) {
                            if (n.parent !== this)
                                return this.render(t, e, r);
                            if (n.render(0 < n._ts ? (i - n._start) * n._ts : (n._dirty ? n.totalDuration() : n._tDur) + (i - n._start) * n._ts, e, r),
                            i !== this._time || !this._ts && !u) {
                                h = 0,
                                a && (v += this._zTime = -V);
                                break
                            }
                        }
                        n = a
                    }
                else {
                    n = this._last;
                    for (var w = t < 0 ? t : i; n; ) {
                        if (a = n._prev,
                        (n._act || w <= n._end) && n._ts && h !== n) {
                            if (n.parent !== this)
                                return this.render(t, e, r);
                            if (n.render(0 < n._ts ? (w - n._start) * n._ts : (n._dirty ? n.totalDuration() : n._tDur) + (w - n._start) * n._ts, e, r),
                            i !== this._time || !this._ts && !u) {
                                h = 0,
                                a && (v += this._zTime = w ? -V : V);
                                break
                            }
                        }
                        n = a
                    }
                }
                if (h && !e && (this.pause(),
                h.render(c <= i ? 0 : -V)._zTime = c <= i ? 1 : -1,
                this._ts))
                    return this._start = f,
                    Aa(this),
                    this.render(t, e, r);
                this._onUpdate && !e && Ot(this, "onUpdate", !0),
                (v === m && this._tTime >= this.totalDuration() || !v && c) && (f !== this._start && Math.abs(l) === Math.abs(this._ts) || this._lock || (!t && g || !(v === m && 0 < this._ts || !v && this._ts < 0) || ta(this, 1),
                e || t < 0 && !c || !v && !c && m || (Ot(this, v === m && 0 <= t ? "onComplete" : "onReverseComplete", !0),
                !this._prom || v < m && 0 < this.timeScale() || this._prom())))
            }
            return this
        }
        ,
        e.add = function add(t, e) {
            var r = this;
            if (q(e) || (e = Tt(this, e, t)),
            !(t instanceof Nt)) {
                if (J(t))
                    return t.forEach(function(t) {
                        return r.add(t, e)
                    }),
                    this;
                if (o(t))
                    return this.addLabel(t, e);
                if (!p(t))
                    return this;
                t = $t.delayedCall(0, t)
            }
            return this !== t ? Da(this, t, e) : this
        }
        ,
        e.getChildren = function getChildren(t, e, r, i) {
            void 0 === t && (t = !0),
            void 0 === e && (e = !0),
            void 0 === r && (r = !0),
            void 0 === i && (i = -Y);
            for (var n = [], a = this._first; a; )
                a._start >= i && (a instanceof $t ? e && n.push(a) : (r && n.push(a),
                t && n.push.apply(n, a.getChildren(!0, e, r)))),
                a = a._next;
            return n
        }
        ,
        e.getById = function getById(t) {
            for (var e = this.getChildren(1, 1, 1), r = e.length; r--; )
                if (e[r].vars.id === t)
                    return e[r]
        }
        ,
        e.remove = function remove(t) {
            return o(t) ? this.removeLabel(t) : p(t) ? this.killTweensOf(t) : (sa(this, t),
            t === this._recent && (this._recent = this._last),
            ua(this))
        }
        ,
        e.totalTime = function totalTime(t, e) {
            return arguments.length ? (this._forcing = 1,
            !this._dp && this._ts && (this._start = da(Dt.time - (0 < this._ts ? t / this._ts : (this.totalDuration() - t) / -this._ts))),
            n.prototype.totalTime.call(this, t, e),
            this._forcing = 0,
            this) : this._tTime
        }
        ,
        e.addLabel = function addLabel(t, e) {
            return this.labels[t] = Tt(this, e),
            this
        }
        ,
        e.removeLabel = function removeLabel(t) {
            return delete this.labels[t],
            this
        }
        ,
        e.addPause = function addPause(t, e, r) {
            var i = $t.delayedCall(0, e || Q, r);
            return i.data = "isPause",
            this._hasPause = 1,
            Da(this, i, Tt(this, t))
        }
        ,
        e.removePause = function removePause(t) {
            var e = this._first;
            for (t = Tt(this, t); e; )
                e._start === t && "isPause" === e.data && ta(e),
                e = e._next
        }
        ,
        e.killTweensOf = function killTweensOf(t, e, r) {
            for (var i = this.getTweensOf(t, r), n = i.length; n--; )
                Yt !== i[n] && i[n].kill(t, e);
            return this
        }
        ,
        e.getTweensOf = function getTweensOf(t, e) {
            for (var r, i = [], n = xt(t), a = this._first, s = q(e); a; )
                a instanceof $t ? fa(a._targets, n) && (s ? (!Yt || a._initted && a._ts) && a.globalTime(0) <= e && a.globalTime(a.totalDuration()) > e : !e || a.isActive()) && i.push(a) : (r = a.getTweensOf(n, e)).length && i.push.apply(i, r),
                a = a._next;
            return i
        }
        ,
        e.tweenTo = function tweenTo(t, e) {
            e = e || {};
            var r, i = this, n = Tt(i, t), a = e.startAt, s = e.onStart, o = e.onStartParams, u = e.immediateRender, h = $t.to(i, ka({
                ease: e.ease || "none",
                lazy: !1,
                immediateRender: !1,
                time: n,
                overwrite: "auto",
                duration: e.duration || Math.abs((n - (a && "time"in a ? a.time : i._time)) / i.timeScale()) || V,
                onStart: function onStart() {
                    if (i.pause(),
                    !r) {
                        var t = e.duration || Math.abs((n - (a && "time"in a ? a.time : i._time)) / i.timeScale());
                        h._dur !== t && Ka(h, t, 0, 1).render(h._time, !0, !0),
                        r = 1
                    }
                    s && s.apply(h, o || [])
                }
            }, e));
            return u ? h.render(0) : h
        }
        ,
        e.tweenFromTo = function tweenFromTo(t, e, r) {
            return this.tweenTo(e, ka({
                startAt: {
                    time: Tt(this, t)
                }
            }, r))
        }
        ,
        e.recent = function recent() {
            return this._recent
        }
        ,
        e.nextLabel = function nextLabel(t) {
            return void 0 === t && (t = this._time),
            kb(this, Tt(this, t))
        }
        ,
        e.previousLabel = function previousLabel(t) {
            return void 0 === t && (t = this._time),
            kb(this, Tt(this, t), 1)
        }
        ,
        e.currentLabel = function currentLabel(t) {
            return arguments.length ? this.seek(t, !0) : this.previousLabel(this._time + V)
        }
        ,
        e.shiftChildren = function shiftChildren(t, e, r) {
            void 0 === r && (r = 0);
            for (var i, n = this._first, a = this.labels; n; )
                n._start >= r && (n._start += t,
                n._end += t),
                n = n._next;
            if (e)
                for (i in a)
                    a[i] >= r && (a[i] += t);
            return ua(this)
        }
        ,
        e.invalidate = function invalidate() {
            var t = this._first;
            for (this._lock = 0; t; )
                t.invalidate(),
                t = t._next;
            return n.prototype.invalidate.call(this)
        }
        ,
        e.clear = function clear(t) {
            void 0 === t && (t = !0);
            for (var e, r = this._first; r; )
                e = r._next,
                this.remove(r),
                r = e;
            return this._dp && (this._time = this._tTime = this._pTime = 0),
            t && (this.labels = {}),
            ua(this)
        }
        ,
        e.totalDuration = function totalDuration(t) {
            var e, r, i, n = 0, a = this, s = a._last, o = Y;
            if (arguments.length)
                return a.timeScale((a._repeat < 0 ? a.duration() : a.totalDuration()) / (a.reversed() ? -t : t));
            if (a._dirty) {
                for (i = a.parent; s; )
                    e = s._prev,
                    s._dirty && s.totalDuration(),
                    o < (r = s._start) && a._sort && s._ts && !a._lock ? (a._lock = 1,
                    Da(a, s, r - s._delay, 1)._lock = 0) : o = r,
                    r < 0 && s._ts && (n -= r,
                    (!i && !a._dp || i && i.smoothChildTiming) && (a._start += r / a._ts,
                    a._time -= r,
                    a._tTime -= r),
                    a.shiftChildren(-r, !1, -Infinity),
                    o = 0),
                    s._end > n && s._ts && (n = s._end),
                    s = e;
                Ka(a, a === I && a._time > n ? a._time : n, 1, 1),
                a._dirty = 0
            }
            return a._tDur
        }
        ,
        Timeline.updateRoot = function updateRoot(t) {
            if (I._ts && (ha(I, za(t, I)),
            f = Dt.frame),
            Dt.frame >= _t) {
                _t += U.autoSleep || 120;
                var e = I._first;
                if ((!e || !e._ts) && U.autoSleep && Dt._listeners.length < 2) {
                    for (; e && !e._ts; )
                        e = e._next;
                    e || Dt.sleep()
                }
            }
        }
        ,
        Timeline
    }(Nt);
    ka(Ut.prototype, {
        _lock: 0,
        _hasPause: 0,
        _forcing: 0
    });
    function Ub(t, e, r, i, n, a) {
        var u, h, l, f;
        if (ft[t] && !1 !== (u = new ft[t]).init(n, u.rawVars ? e[t] : function _processVars(t, e, r, i, n) {
            if (p(t) && (t = Qt(t, n, e, r, i)),
            !s(t) || t.style && t.nodeType || J(t) || H(t))
                return o(t) ? Qt(t, n, e, r, i) : t;
            var a, u = {};
            for (a in t)
                u[a] = Qt(t[a], n, e, r, i);
            return u
        }(e[t], i, n, a, r), r, i, a) && (r._pt = h = new oe(r._pt,n,t,0,1,u.render,u,0,u.priority),
        r !== d))
            for (l = r._ptLookup[r._targets.indexOf(n)],
            f = u._props.length; f--; )
                l[u._props[f]] = h;
        return u
    }
    function $b(t, r, e, i) {
        var n, a, s = r.ease || i || "power1.inOut";
        if (J(r))
            a = e[t] || (e[t] = []),
            r.forEach(function(t, e) {
                return a.push({
                    t: e / (r.length - 1) * 100,
                    v: t,
                    e: s
                })
            });
        else
            for (n in r)
                a = e[n] || (e[n] = []),
                "ease" === n || a.push({
                    t: parseFloat(t),
                    v: r[n],
                    e: s
                })
    }
    var Yt, qt, Vt = function _addPropTween(t, e, r, i, n, a, s, u, h) {
        p(i) && (i = i(n || 0, t, a));
        var l, f = t[e], d = "get" !== r ? r : p(f) ? h ? t[e.indexOf("set") || !p(t["get" + e.substr(3)]) ? e : "get" + e.substr(3)](h) : t[e]() : f, _ = p(f) ? h ? Zt : Wt : Gt;
        if (o(i) && (~i.indexOf("random(") && (i = hb(i)),
        "=" === i.charAt(1) && (!(l = ea(d, i) + (Ra(d) || 0)) && 0 !== l || (i = l))),
        d !== i || qt)
            return isNaN(d * i) || "" === i ? (f || e in t || N(e, i),
            function _addComplexStringPropTween(t, e, r, i, n, a, s) {
                var o, u, h, l, f, d, _, p, c = new oe(this._pt,t,e,0,1,ee,null,n), m = 0, g = 0;
                for (c.b = r,
                c.e = i,
                r += "",
                (_ = ~(i += "").indexOf("random(")) && (i = hb(i)),
                a && (a(p = [r, i], t, e),
                r = p[0],
                i = p[1]),
                u = r.match(it) || []; o = it.exec(i); )
                    l = o[0],
                    f = i.substring(m, o.index),
                    h ? h = (h + 1) % 5 : "rgba(" === f.substr(-5) && (h = 1),
                    l !== u[g++] && (d = parseFloat(u[g - 1]) || 0,
                    c._pt = {
                        _next: c._pt,
                        p: f || 1 === g ? f : ",",
                        s: d,
                        c: "=" === l.charAt(1) ? ea(d, l) - d : parseFloat(l) - d,
                        m: h && h < 4 ? Math.round : 0
                    },
                    m = it.lastIndex);
                return c.c = m < i.length ? i.substring(m, i.length) : "",
                c.fp = s,
                (nt.test(i) || _) && (c.e = 0),
                this._pt = c
            }
            .call(this, t, e, d, i, _, u || U.stringFilter, h)) : (l = new oe(this._pt,t,e,+d || 0,i - (d || 0),"boolean" == typeof f ? te : Jt,0,_),
            h && (l.fp = h),
            s && l.modifier(s, this, t),
            this._pt = l)
    }, Xt = function _initTween(e, r) {
        var i, n, a, s, o, u, h, l, f, d, p, c, m, g = e.vars, v = g.ease, y = g.startAt, T = g.immediateRender, b = g.lazy, w = g.onUpdate, x = g.onUpdateParams, k = g.callbackScope, O = g.runBackwards, P = g.yoyoEase, M = g.keyframes, C = g.autoRevert, A = e._dur, D = e._startAt, S = e._targets, z = e.parent, R = z && "nested" === z.data ? z.parent._targets : S, E = "auto" === e._overwrite && !B, F = e.timeline;
        if (!F || M && v || (v = "none"),
        e._ease = Bt(v, L.ease),
        e._yEase = P ? Ft(Bt(!0 === P ? v : P, L.ease)) : 0,
        P && e._yoyo && !e._repeat && (P = e._yEase,
        e._yEase = e._ease,
        e._ease = P),
        e._from = !F && !!g.runBackwards,
        !F || M && !g.stagger) {
            if (c = (l = S[0] ? _(S[0]).harness : 0) && g[l.prop],
            i = oa(g, ut),
            D && (ta(D.render(-1, !0)),
            D._lazy = 0),
            y)
                if (ta(e._startAt = $t.set(S, ka({
                    data: "isStart",
                    overwrite: !1,
                    parent: z,
                    immediateRender: !0,
                    lazy: t(b),
                    startAt: null,
                    delay: 0,
                    onUpdate: w,
                    onUpdateParams: x,
                    callbackScope: k,
                    stagger: 0
                }, y))),
                r < 0 && !T && !C && e._startAt.render(-1, !0),
                T) {
                    if (0 < r && !C && (e._startAt = 0),
                    A && r <= 0)
                        return void (r && (e._zTime = r))
                } else
                    !1 === C && (e._startAt = 0);
            else if (O && A)
                if (D)
                    C || (e._startAt = 0);
                else if (r && (T = !1),
                a = ka({
                    overwrite: !1,
                    data: "isFromStart",
                    lazy: T && t(b),
                    immediateRender: T,
                    stagger: 0,
                    parent: z
                }, i),
                c && (a[l.prop] = c),
                ta(e._startAt = $t.set(S, a)),
                r < 0 && e._startAt.render(-1, !0),
                e._zTime = r,
                T) {
                    if (!r)
                        return
                } else
                    _initTween(e._startAt, V);
            for (e._pt = e._ptCache = 0,
            b = A && t(b) || b && !A,
            n = 0; n < S.length; n++) {
                if (h = (o = S[n])._gsap || $(S)[n]._gsap,
                e._ptLookup[n] = d = {},
                lt[h.id] && ht.length && ga(),
                p = R === S ? n : R.indexOf(o),
                l && !1 !== (f = new l).init(o, c || i, e, p, R) && (e._pt = s = new oe(e._pt,o,f.name,0,1,f.render,f,0,f.priority),
                f._props.forEach(function(t) {
                    d[t] = s
                }),
                f.priority && (u = 1)),
                !l || c)
                    for (a in i)
                        ft[a] && (f = Ub(a, i, e, p, o, R)) ? f.priority && (u = 1) : d[a] = s = Vt.call(e, o, a, "get", i[a], p, R, 0, g.stringFilter);
                e._op && e._op[n] && e.kill(o, e._op[n]),
                E && e._pt && (Yt = e,
                I.killTweensOf(o, d, e.globalTime(r)),
                m = !e.parent,
                Yt = 0),
                e._pt && b && (lt[h.id] = 1)
            }
            u && se(e),
            e._onInit && e._onInit(e)
        }
        e._onUpdate = w,
        e._initted = (!e._op || e._pt) && !m,
        M && r <= 0 && F.render(Y, !0, !0)
    }, Qt = function _parseFuncOrString(t, e, r, i, n) {
        return p(t) ? t.call(e, r, i, n) : o(t) && ~t.indexOf("random(") ? hb(t) : t
    }, jt = ct + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,autoRevert", Kt = {};
    ba(jt + ",id,stagger,delay,duration,paused,scrollTrigger", function(t) {
        return Kt[t] = 1
    });
    var $t = function(R) {
        function Tween(e, r, i, n) {
            var a;
            "number" == typeof r && (i.duration = r,
            r = i,
            i = null);
            var o, u, h, l, f, d, _, p, c = (a = R.call(this, n ? r : pa(r)) || this).vars, m = c.duration, g = c.delay, y = c.immediateRender, T = c.stagger, b = c.overwrite, w = c.keyframes, x = c.defaults, k = c.scrollTrigger, P = c.yoyoEase, M = r.parent || I, C = (J(e) || H(e) ? q(e[0]) : "length"in r) ? [e] : xt(e);
            if (a._targets = C.length ? $(C) : O("GSAP target " + e + " not found. https://greensock.com", !U.nullTargetWarn) || [],
            a._ptLookup = [],
            a._overwrite = b,
            w || T || v(m) || v(g)) {
                if (r = a.vars,
                (o = a.timeline = new Ut({
                    data: "nested",
                    defaults: x || {}
                })).kill(),
                o.parent = o._dp = _assertThisInitialized(a),
                o._start = 0,
                T || v(m) || v(g)) {
                    if (l = C.length,
                    _ = T && Za(T),
                    s(T))
                        for (f in T)
                            ~jt.indexOf(f) && ((p = p || {})[f] = T[f]);
                    for (u = 0; u < l; u++)
                        (h = oa(r, Kt)).stagger = 0,
                        P && (h.yoyoEase = P),
                        p && mt(h, p),
                        d = C[u],
                        h.duration = +Qt(m, _assertThisInitialized(a), u, d, C),
                        h.delay = (+Qt(g, _assertThisInitialized(a), u, d, C) || 0) - a._delay,
                        !T && 1 === l && h.delay && (a._delay = g = h.delay,
                        a._start += g,
                        h.delay = 0),
                        o.to(d, h, _ ? _(u, d, C) : 0),
                        o._ease = zt.none;
                    o.duration() ? m = g = 0 : a.timeline = 0
                } else if (w) {
                    pa(ka(o.vars.defaults, {
                        ease: "none"
                    })),
                    o._ease = Bt(w.ease || r.ease || "none");
                    var A, D, S, z = 0;
                    if (J(w))
                        w.forEach(function(t) {
                            return o.to(C, t, ">")
                        });
                    else {
                        for (f in h = {},
                        w)
                            "ease" === f || "easeEach" === f || $b(f, w[f], h, w.easeEach);
                        for (f in h)
                            for (A = h[f].sort(function(t, e) {
                                return t.t - e.t
                            }),
                            u = z = 0; u < A.length; u++)
                                (S = {
                                    ease: (D = A[u]).e,
                                    duration: (D.t - (u ? A[u - 1].t : 0)) / 100 * m
                                })[f] = D.v,
                                o.to(C, S, z),
                                z += S.duration;
                        o.duration() < m && o.to({}, {
                            duration: m - o.duration()
                        })
                    }
                }
                m || a.duration(m = o.duration())
            } else
                a.timeline = 0;
            return !0 !== b || B || (Yt = _assertThisInitialized(a),
            I.killTweensOf(C),
            Yt = 0),
            Da(M, _assertThisInitialized(a), i),
            r.reversed && a.reverse(),
            r.paused && a.paused(!0),
            (y || !m && !w && a._start === da(M._time) && t(y) && function _hasNoPausedAncestors(t) {
                return !t || t._ts && _hasNoPausedAncestors(t.parent)
            }(_assertThisInitialized(a)) && "nested" !== M.data) && (a._tTime = -V,
            a.render(Math.max(0, -g))),
            k && Ea(_assertThisInitialized(a), k),
            a
        }
        _inheritsLoose(Tween, R);
        var e = Tween.prototype;
        return e.render = function render(t, e, r) {
            var i, n, a, s, o, u, h, l, f, d = this._time, _ = this._tDur, p = this._dur, c = _ - V < t && 0 <= t ? _ : t < V ? 0 : t;
            if (p) {
                if (c !== this._tTime || !t || r || !this._initted && this._tTime || this._startAt && this._zTime < 0 != t < 0) {
                    if (i = c,
                    l = this.timeline,
                    this._repeat) {
                        if (s = p + this._rDelay,
                        this._repeat < -1 && t < 0)
                            return this.totalTime(100 * s + t, e, r);
                        if (i = da(c % s),
                        c === _ ? (a = this._repeat,
                        i = p) : ((a = ~~(c / s)) && a === c / s && (i = p,
                        a--),
                        p < i && (i = p)),
                        (u = this._yoyo && 1 & a) && (f = this._yEase,
                        i = p - i),
                        o = gt(this._tTime, s),
                        i === d && !r && this._initted)
                            return this._tTime = c,
                            this;
                        a !== o && (l && this._yEase && Ib(l, u),
                        !this.vars.repeatRefresh || u || this._lock || (this._lock = r = 1,
                        this.render(da(s * a), !0).invalidate()._lock = 0))
                    }
                    if (!this._initted) {
                        if (Fa(this, t < 0 ? t : i, r, e))
                            return this._tTime = 0,
                            this;
                        if (d !== this._time)
                            return this;
                        if (p !== this._dur)
                            return this.render(t, e, r)
                    }
                    if (this._tTime = c,
                    this._time = i,
                    !this._act && this._ts && (this._act = 1,
                    this._lazy = 0),
                    this.ratio = h = (f || this._ease)(i / p),
                    this._from && (this.ratio = h = 1 - h),
                    i && !d && !e && (Ot(this, "onStart"),
                    this._tTime !== c))
                        return this;
                    for (n = this._pt; n; )
                        n.r(h, n.d),
                        n = n._next;
                    l && l.render(t < 0 ? t : !i && u ? -V : l._dur * l._ease(i / this._dur), e, r) || this._startAt && (this._zTime = t),
                    this._onUpdate && !e && (t < 0 && this._startAt && this._startAt.render(t, !0, r),
                    Ot(this, "onUpdate")),
                    this._repeat && a !== o && this.vars.onRepeat && !e && this.parent && Ot(this, "onRepeat"),
                    c !== this._tDur && c || this._tTime !== c || (t < 0 && this._startAt && !this._onUpdate && this._startAt.render(t, !0, !0),
                    !t && p || !(c === this._tDur && 0 < this._ts || !c && this._ts < 0) || ta(this, 1),
                    e || t < 0 && !d || !c && !d || (Ot(this, c === _ ? "onComplete" : "onReverseComplete", !0),
                    !this._prom || c < _ && 0 < this.timeScale() || this._prom()))
                }
            } else
                !function _renderZeroDurationTween(t, e, r, i) {
                    var n, a, s, o = t.ratio, u = e < 0 || !e && (!t._start && function _parentPlayheadIsBeforeStart(t) {
                        var e = t.parent;
                        return e && e._ts && e._initted && !e._lock && (e.rawTime() < 0 || _parentPlayheadIsBeforeStart(e))
                    }(t) && (t._initted || !vt(t)) || (t._ts < 0 || t._dp._ts < 0) && !vt(t)) ? 0 : 1, h = t._rDelay, l = 0;
                    if (h && t._repeat && (l = bt(0, t._tDur, e),
                    a = gt(l, h),
                    t._yoyo && 1 & a && (u = 1 - u),
                    a !== gt(t._tTime, h) && (o = 1 - u,
                    t.vars.repeatRefresh && t._initted && t.invalidate())),
                    u !== o || i || t._zTime === V || !e && t._zTime) {
                        if (!t._initted && Fa(t, e, i, r))
                            return;
                        for (s = t._zTime,
                        t._zTime = e || (r ? V : 0),
                        r = r || e && !s,
                        t.ratio = u,
                        t._from && (u = 1 - u),
                        t._time = 0,
                        t._tTime = l,
                        n = t._pt; n; )
                            n.r(u, n.d),
                            n = n._next;
                        t._startAt && e < 0 && t._startAt.render(e, !0, !0),
                        t._onUpdate && !r && Ot(t, "onUpdate"),
                        l && t._repeat && !r && t.parent && Ot(t, "onRepeat"),
                        (e >= t._tDur || e < 0) && t.ratio === u && (u && ta(t, 1),
                        r || (Ot(t, u ? "onComplete" : "onReverseComplete", !0),
                        t._prom && t._prom()))
                    } else
                        t._zTime || (t._zTime = e)
                }(this, t, e, r);
            return this
        }
        ,
        e.targets = function targets() {
            return this._targets
        }
        ,
        e.invalidate = function invalidate() {
            return this._pt = this._op = this._startAt = this._onUpdate = this._lazy = this.ratio = 0,
            this._ptLookup = [],
            this.timeline && this.timeline.invalidate(),
            R.prototype.invalidate.call(this)
        }
        ,
        e.resetTo = function resetTo(t, e, r, i) {
            c || Dt.wake(),
            this._ts || this.play();
            var n, a = Math.min(this._dur, (this._dp._time - this._start) * this._ts);
            return this._initted || Xt(this, a),
            n = this._ease(a / this._dur),
            function _updatePropTweens(t, e, r, i, n, a, s) {
                var o, u, h, l = (t._pt && t._ptCache || (t._ptCache = {}))[e];
                if (!l)
                    for (l = t._ptCache[e] = [],
                    u = t._ptLookup,
                    h = t._targets.length; h--; ) {
                        if ((o = u[h][e]) && o.d && o.d._pt)
                            for (o = o.d._pt; o && o.p !== e; )
                                o = o._next;
                        if (!o)
                            return qt = 1,
                            t.vars[e] = "+=0",
                            Xt(t, s),
                            qt = 0,
                            1;
                        l.push(o)
                    }
                for (h = l.length; h--; )
                    (o = l[h]).s = !i && 0 !== i || n ? o.s + (i || 0) + a * o.c : i,
                    o.c = r - o.s,
                    o.e && (o.e = ca(r) + Ra(o.e)),
                    o.b && (o.b = o.s + Ra(o.b))
            }(this, t, e, r, i, n, a) ? this.resetTo(t, e, r, i) : (Ba(this, 0),
            this.parent || ra(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0),
            this.render(0))
        }
        ,
        e.kill = function kill(t, e) {
            if (void 0 === e && (e = "all"),
            !(t || e && "all" !== e))
                return this._lazy = this._pt = 0,
                this.parent ? mb(this) : this;
            if (this.timeline) {
                var r = this.timeline.totalDuration();
                return this.timeline.killTweensOf(t, e, Yt && !0 !== Yt.vars.overwrite)._first || mb(this),
                this.parent && r !== this.timeline.totalDuration() && Ka(this, this._dur * this.timeline._tDur / r, 0, 1),
                this
            }
            var i, n, a, s, u, h, l, f = this._targets, d = t ? xt(t) : f, p = this._ptLookup, c = this._pt;
            if ((!e || "all" === e) && function _arraysMatch(t, e) {
                for (var r = t.length, i = r === e.length; i && r-- && t[r] === e[r]; )
                    ;
                return r < 0
            }(f, d))
                return "all" === e && (this._pt = 0),
                mb(this);
            for (i = this._op = this._op || [],
            "all" !== e && (o(e) && (u = {},
            ba(e, function(t) {
                return u[t] = 1
            }),
            e = u),
            e = function _addAliasesToVars(t, e) {
                var r, i, n, a, s = t[0] ? _(t[0]).harness : 0, o = s && s.aliases;
                if (!o)
                    return e;
                for (i in r = mt({}, e),
                o)
                    if (i in r)
                        for (n = (a = o[i].split(",")).length; n--; )
                            r[a[n]] = r[i];
                return r
            }(f, e)),
            l = f.length; l--; )
                if (~d.indexOf(f[l]))
                    for (u in n = p[l],
                    "all" === e ? (i[l] = e,
                    s = n,
                    a = {}) : (a = i[l] = i[l] || {},
                    s = e),
                    s)
                        (h = n && n[u]) && ("kill"in h.d && !0 !== h.d.kill(u) || sa(this, h, "_pt"),
                        delete n[u]),
                        "all" !== a && (a[u] = 1);
            return this._initted && !this._pt && c && mb(this),
            this
        }
        ,
        Tween.to = function to(t, e, r) {
            return new Tween(t,e,r)
        }
        ,
        Tween.from = function from(t, e) {
            return Oa(1, arguments)
        }
        ,
        Tween.delayedCall = function delayedCall(t, e, r, i) {
            return new Tween(e,0,{
                immediateRender: !1,
                lazy: !1,
                overwrite: !1,
                delay: t,
                onComplete: e,
                onReverseComplete: e,
                onCompleteParams: r,
                onReverseCompleteParams: r,
                callbackScope: i
            })
        }
        ,
        Tween.fromTo = function fromTo(t, e, r) {
            return Oa(2, arguments)
        }
        ,
        Tween.set = function set(t, e) {
            return e.duration = 0,
            e.repeatDelay || (e.repeat = 0),
            new Tween(t,e)
        }
        ,
        Tween.killTweensOf = function killTweensOf(t, e, r) {
            return I.killTweensOf(t, e, r)
        }
        ,
        Tween
    }(Nt);
    ka($t.prototype, {
        _targets: [],
        _lazy: 0,
        _startAt: 0,
        _op: 0,
        _onInit: 0
    }),
    ba("staggerTo,staggerFrom,staggerFromTo", function(r) {
        $t[r] = function() {
            var t = new Ut
              , e = wt.call(arguments, 0);
            return e.splice("staggerFromTo" === r ? 5 : 4, 0, 0),
            t[r].apply(t, e)
        }
    });
    function gc(t, e, r) {
        return t.setAttribute(e, r)
    }
    function oc(t, e, r, i) {
        i.mSet(t, e, i.m.call(i.tween, r, i.mt), i)
    }
    var Gt = function _setterPlain(t, e, r) {
        return t[e] = r
    }
      , Wt = function _setterFunc(t, e, r) {
        return t[e](r)
    }
      , Zt = function _setterFuncWithParam(t, e, r, i) {
        return t[e](i.fp, r)
    }
      , Ht = function _getSetter(t, e) {
        return p(t[e]) ? Wt : r(t[e]) && t.setAttribute ? gc : Gt
    }
      , Jt = function _renderPlain(t, e) {
        return e.set(e.t, e.p, Math.round(1e6 * (e.s + e.c * t)) / 1e6, e)
    }
      , te = function _renderBoolean(t, e) {
        return e.set(e.t, e.p, !!(e.s + e.c * t), e)
    }
      , ee = function _renderComplexString(t, e) {
        var r = e._pt
          , i = "";
        if (!t && e.b)
            i = e.b;
        else if (1 === t && e.e)
            i = e.e;
        else {
            for (; r; )
                i = r.p + (r.m ? r.m(r.s + r.c * t) : Math.round(1e4 * (r.s + r.c * t)) / 1e4) + i,
                r = r._next;
            i += e.c
        }
        e.set(e.t, e.p, i, e)
    }
      , re = function _renderPropTweens(t, e) {
        for (var r = e._pt; r; )
            r.r(t, r.d),
            r = r._next
    }
      , ie = function _addPluginModifier(t, e, r, i) {
        for (var n, a = this._pt; a; )
            n = a._next,
            a.p === i && a.modifier(t, e, r),
            a = n
    }
      , ne = function _killPropTweensOf(t) {
        for (var e, r, i = this._pt; i; )
            r = i._next,
            i.p === t && !i.op || i.op === t ? sa(this, i, "_pt") : i.dep || (e = 1),
            i = r;
        return !e
    }
      , se = function _sortPropTweensByPriority(t) {
        for (var e, r, i, n, a = t._pt; a; ) {
            for (e = a._next,
            r = i; r && r.pr > a.pr; )
                r = r._next;
            (a._prev = r ? r._prev : n) ? a._prev._next = a : i = a,
            (a._next = r) ? r._prev = a : n = a,
            a = e
        }
        t._pt = i
    }
      , oe = (PropTween.prototype.modifier = function modifier(t, e, r) {
        this.mSet = this.mSet || this.set,
        this.set = oc,
        this.m = t,
        this.mt = r,
        this.tween = e
    }
    ,
    PropTween);
    function PropTween(t, e, r, i, n, a, s, o, u) {
        this.t = e,
        this.s = i,
        this.c = n,
        this.p = r,
        this.r = a || Jt,
        this.d = s || this,
        this.set = o || Gt,
        this.pr = u || 0,
        (this._next = t) && (t._prev = this)
    }
    ba(ct + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger", function(t) {
        return ut[t] = 1
    }),
    ot.TweenMax = ot.TweenLite = $t,
    ot.TimelineLite = ot.TimelineMax = Ut,
    I = new Ut({
        sortChildren: !1,
        defaults: L,
        autoRemoveChildren: !0,
        id: "root",
        smoothChildTiming: !0
    }),
    U.stringFilter = xb;
    var ue = {
        registerPlugin: function registerPlugin() {
            for (var t = arguments.length, e = new Array(t), r = 0; r < t; r++)
                e[r] = arguments[r];
            e.forEach(function(t) {
                return function _createPlugin(t) {
                    var e = (t = !t.name && t.default || t).name
                      , r = p(t)
                      , i = e && !r && t.init ? function() {
                        this._props = []
                    }
                    : t
                      , n = {
                        init: Q,
                        render: re,
                        add: Vt,
                        kill: ne,
                        modifier: ie,
                        rawVars: 0
                    }
                      , a = {
                        targetTest: 0,
                        get: 0,
                        getSetter: Ht,
                        aliases: {},
                        register: 0
                    };
                    if (St(),
                    t !== i) {
                        if (ft[e])
                            return;
                        ka(i, ka(oa(t, n), a)),
                        mt(i.prototype, mt(n, oa(t, a))),
                        ft[i.prop = e] = i,
                        t.targetTest && (pt.push(i),
                        ut[e] = 1),
                        e = ("css" === e ? "CSS" : e.charAt(0).toUpperCase() + e.substr(1)) + "Plugin"
                    }
                    P(e, i),
                    t.register && t.register(he, i, oe)
                }(t)
            })
        },
        timeline: function timeline(t) {
            return new Ut(t)
        },
        getTweensOf: function getTweensOf(t, e) {
            return I.getTweensOf(t, e)
        },
        getProperty: function getProperty(i, t, e, r) {
            o(i) && (i = xt(i)[0]);
            var n = _(i || {}).get
              , a = e ? ja : ia;
            return "native" === e && (e = ""),
            i ? t ? a((ft[t] && ft[t].get || n)(i, t, e, r)) : function(t, e, r) {
                return a((ft[t] && ft[t].get || n)(i, t, e, r))
            }
            : i
        },
        quickSetter: function quickSetter(r, e, i) {
            if (1 < (r = xt(r)).length) {
                var n = r.map(function(t) {
                    return he.quickSetter(t, e, i)
                })
                  , a = n.length;
                return function(t) {
                    for (var e = a; e--; )
                        n[e](t)
                }
            }
            r = r[0] || {};
            var s = ft[e]
              , o = _(r)
              , u = o.harness && (o.harness.aliases || {})[e] || e
              , h = s ? function(t) {
                var e = new s;
                d._pt = 0,
                e.init(r, i ? t + i : t, d, 0, [r]),
                e.render(1, e),
                d._pt && re(1, d)
            }
            : o.set(r, u);
            return s ? h : function(t) {
                return h(r, u, i ? t + i : t, o, 1)
            }
        },
        quickTo: function quickTo(t, i, e) {
            function iw(t, e, r) {
                return n.resetTo(i, t, e, r)
            }
            var r, n = he.to(t, mt(((r = {})[i] = "+=0.1",
            r.paused = !0,
            r), e || {}));
            return iw.tween = n,
            iw
        },
        isTweening: function isTweening(t) {
            return 0 < I.getTweensOf(t, !0).length
        },
        defaults: function defaults(t) {
            return t && t.ease && (t.ease = Bt(t.ease, L.ease)),
            na(L, t || {})
        },
        config: function config(t) {
            return na(U, t || {})
        },
        registerEffect: function registerEffect(t) {
            var i = t.name
              , n = t.effect
              , e = t.plugins
              , a = t.defaults
              , r = t.extendTimeline;
            (e || "").split(",").forEach(function(t) {
                return t && !ft[t] && !ot[t] && O(i + " effect requires " + t + " plugin.")
            }),
            dt[i] = function(t, e, r) {
                return n(xt(t), ka(e || {}, a), r)
            }
            ,
            r && (Ut.prototype[i] = function(t, e, r) {
                return this.add(dt[i](t, s(e) ? e : (r = e) && {}, this), r)
            }
            )
        },
        registerEase: function registerEase(t, e) {
            zt[t] = Bt(e)
        },
        parseEase: function parseEase(t, e) {
            return arguments.length ? Bt(t, e) : zt
        },
        getById: function getById(t) {
            return I.getById(t)
        },
        exportRoot: function exportRoot(e, r) {
            void 0 === e && (e = {});
            var i, n, a = new Ut(e);
            for (a.smoothChildTiming = t(e.smoothChildTiming),
            I.remove(a),
            a._dp = 0,
            a._time = a._tTime = I._time,
            i = I._first; i; )
                n = i._next,
                !r && !i._dur && i instanceof $t && i.vars.onComplete === i._targets[0] || Da(a, i, i._start - i._delay),
                i = n;
            return Da(I, a, 0),
            a
        },
        utils: {
            wrap: function wrap(e, t, r) {
                var i = t - e;
                return J(e) ? eb(e, wrap(0, e.length), t) : Pa(r, function(t) {
                    return (i + (t - e) % i) % i + e
                })
            },
            wrapYoyo: function wrapYoyo(e, t, r) {
                var i = t - e
                  , n = 2 * i;
                return J(e) ? eb(e, wrapYoyo(0, e.length - 1), t) : Pa(r, function(t) {
                    return e + (i < (t = (n + (t - e) % n) % n || 0) ? n - t : t)
                })
            },
            distribute: Za,
            random: ab,
            snap: _a,
            normalize: function normalize(t, e, r) {
                return kt(t, e, 0, 1, r)
            },
            getUnit: Ra,
            clamp: function clamp(e, r, t) {
                return Pa(t, function(t) {
                    return bt(e, r, t)
                })
            },
            splitColor: sb,
            toArray: xt,
            selector: function selector(r) {
                return r = xt(r)[0] || O("Invalid scope") || {},
                function(t) {
                    var e = r.current || r.nativeElement || r;
                    return xt(t, e.querySelectorAll ? e : e === r ? O("Invalid scope") || a.createElement("div") : r)
                }
            },
            mapRange: kt,
            pipe: function pipe() {
                for (var t = arguments.length, e = new Array(t), r = 0; r < t; r++)
                    e[r] = arguments[r];
                return function(t) {
                    return e.reduce(function(t, e) {
                        return e(t)
                    }, t)
                }
            },
            unitize: function unitize(e, r) {
                return function(t) {
                    return e(parseFloat(t)) + (r || Ra(t))
                }
            },
            interpolate: function interpolate(e, r, t, i) {
                var n = isNaN(e + r) ? 0 : function(t) {
                    return (1 - t) * e + t * r
                }
                ;
                if (!n) {
                    var a, s, u, h, l, f = o(e), d = {};
                    if (!0 === t && (i = 1) && (t = null),
                    f)
                        e = {
                            p: e
                        },
                        r = {
                            p: r
                        };
                    else if (J(e) && !J(r)) {
                        for (u = [],
                        h = e.length,
                        l = h - 2,
                        s = 1; s < h; s++)
                            u.push(interpolate(e[s - 1], e[s]));
                        h--,
                        n = function func(t) {
                            t *= h;
                            var e = Math.min(l, ~~t);
                            return u[e](t - e)
                        }
                        ,
                        t = r
                    } else
                        i || (e = mt(J(e) ? [] : {}, e));
                    if (!u) {
                        for (a in r)
                            Vt.call(d, e, a, "get", r[a]);
                        n = function func(t) {
                            return re(t, d) || (f ? e.p : e)
                        }
                    }
                }
                return Pa(t, n)
            },
            shuffle: Ya
        },
        install: M,
        effects: dt,
        ticker: Dt,
        updateRoot: Ut.updateRoot,
        plugins: ft,
        globalTimeline: I,
        core: {
            PropTween: oe,
            globals: P,
            Tween: $t,
            Timeline: Ut,
            Animation: Nt,
            getCache: _,
            _removeLinkedListItem: sa,
            suppressOverwrites: function suppressOverwrites(t) {
                return B = t
            }
        }
    };
    ba("to,from,fromTo,delayedCall,set,killTweensOf", function(t) {
        return ue[t] = $t[t]
    }),
    Dt.add(Ut.updateRoot),
    d = ue.to({}, {
        duration: 0
    });
    function sc(t, e) {
        for (var r = t._pt; r && r.p !== e && r.op !== e && r.fp !== e; )
            r = r._next;
        return r
    }
    function uc(t, n) {
        return {
            name: t,
            rawVars: 1,
            init: function init(t, i, e) {
                e._onInit = function(t) {
                    var e, r;
                    if (o(i) && (e = {},
                    ba(i, function(t) {
                        return e[t] = 1
                    }),
                    i = e),
                    n) {
                        for (r in e = {},
                        i)
                            e[r] = n(i[r]);
                        i = e
                    }
                    !function _addModifiers(t, e) {
                        var r, i, n, a = t._targets;
                        for (r in e)
                            for (i = a.length; i--; )
                                (n = (n = t._ptLookup[i][r]) && n.d) && (n._pt && (n = sc(n, r)),
                                n && n.modifier && n.modifier(e[r], t, a[i], r))
                    }(t, i)
                }
            }
        }
    }
    var he = ue.registerPlugin({
        name: "attr",
        init: function init(t, e, r, i, n) {
            var a, s;
            for (a in e)
                (s = this.add(t, "setAttribute", (t.getAttribute(a) || 0) + "", e[a], i, n, 0, 0, a)) && (s.op = a),
                this._props.push(a)
        }
    }, {
        name: "endArray",
        init: function init(t, e) {
            for (var r = e.length; r--; )
                this.add(t, r, t[r] || 0, e[r])
        }
    }, uc("roundProps", $a), uc("modifiers"), uc("snap", _a)) || ue;
    $t.version = Ut.version = he.version = "3.10.4",
    l = 1,
    u() && St();
    function dd(t, e) {
        return e.set(e.t, e.p, Math.round(1e4 * (e.s + e.c * t)) / 1e4 + e.u, e)
    }
    function ed(t, e) {
        return e.set(e.t, e.p, 1 === t ? e.e : Math.round(1e4 * (e.s + e.c * t)) / 1e4 + e.u, e)
    }
    function fd(t, e) {
        return e.set(e.t, e.p, t ? Math.round(1e4 * (e.s + e.c * t)) / 1e4 + e.u : e.b, e)
    }
    function gd(t, e) {
        var r = e.s + e.c * t;
        e.set(e.t, e.p, ~~(r + (r < 0 ? -.5 : .5)) + e.u, e)
    }
    function hd(t, e) {
        return e.set(e.t, e.p, t ? e.e : e.b, e)
    }
    function id(t, e) {
        return e.set(e.t, e.p, 1 !== t ? e.b : e.e, e)
    }
    function jd(t, e, r) {
        return t.style[e] = r
    }
    function kd(t, e, r) {
        return t.style.setProperty(e, r)
    }
    function ld(t, e, r) {
        return t._gsap[e] = r
    }
    function md(t, e, r) {
        return t._gsap.scaleX = t._gsap.scaleY = r
    }
    function nd(t, e, r, i, n) {
        var a = t._gsap;
        a.scaleX = a.scaleY = r,
        a.renderTransform(n, a)
    }
    function od(t, e, r, i, n) {
        var a = t._gsap;
        a[e] = r,
        a.renderTransform(n, a)
    }
    function sd(t, e) {
        var r = fe.createElementNS ? fe.createElementNS((e || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), t) : fe.createElement(t);
        return r.style ? r : fe.createElement(t)
    }
    function td(t, e, r) {
        var i = getComputedStyle(t);
        return i[e] || i.getPropertyValue(e.replace(Ne, "-$1").toLowerCase()) || i.getPropertyValue(e) || !r && td(t, je(e) || e, 1) || ""
    }
    function wd() {
        (function _windowExists() {
            return "undefined" != typeof window
        }
        )() && window.document && (le = window,
        fe = le.document,
        de = fe.documentElement,
        pe = sd("div") || {
            style: {}
        },
        sd("div"),
        Ve = je(Ve),
        Xe = Ve + "Origin",
        pe.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0",
        me = !!je("perspective"),
        _e = 1)
    }
    function xd(t) {
        var e, r = sd("svg", this.ownerSVGElement && this.ownerSVGElement.getAttribute("xmlns") || "http://www.w3.org/2000/svg"), i = this.parentNode, n = this.nextSibling, a = this.style.cssText;
        if (de.appendChild(r),
        r.appendChild(this),
        this.style.display = "block",
        t)
            try {
                e = this.getBBox(),
                this._gsapBBox = this.getBBox,
                this.getBBox = xd
            } catch (t) {}
        else
            this._gsapBBox && (e = this._gsapBBox());
        return i && (n ? i.insertBefore(this, n) : i.appendChild(this)),
        de.removeChild(r),
        this.style.cssText = a,
        e
    }
    function yd(t, e) {
        for (var r = e.length; r--; )
            if (t.hasAttribute(e[r]))
                return t.getAttribute(e[r])
    }
    function zd(e) {
        var r;
        try {
            r = e.getBBox()
        } catch (t) {
            r = xd.call(e, !0)
        }
        return r && (r.width || r.height) || e.getBBox === xd || (r = xd.call(e, !0)),
        !r || r.width || r.x || r.y ? r : {
            x: +yd(e, ["x", "cx", "x1"]) || 0,
            y: +yd(e, ["y", "cy", "y1"]) || 0,
            width: 0,
            height: 0
        }
    }
    function Ad(t) {
        return !(!t.getCTM || t.parentNode && !t.ownerSVGElement || !zd(t))
    }
    function Bd(t, e) {
        if (e) {
            var r = t.style;
            e in Fe && e !== Xe && (e = Ve),
            r.removeProperty ? ("ms" !== e.substr(0, 2) && "webkit" !== e.substr(0, 6) || (e = "-" + e),
            r.removeProperty(e.replace(Ne, "-$1").toLowerCase())) : r.removeAttribute(e)
        }
    }
    function Cd(t, e, r, i, n, a) {
        var s = new oe(t._pt,e,r,0,1,a ? id : hd);
        return (t._pt = s).b = i,
        s.e = n,
        t._props.push(r),
        s
    }
    function Ed(t, e, r, i) {
        var n, a, s, o, u = parseFloat(r) || 0, h = (r + "").trim().substr((u + "").length) || "px", l = pe.style, f = Ue.test(e), d = "svg" === t.tagName.toLowerCase(), p = (d ? "client" : "offset") + (f ? "Width" : "Height"), c = "px" === i, m = "%" === i;
        return i === h || !u || Ke[i] || Ke[h] ? u : ("px" === h || c || (u = Ed(t, e, r, "px")),
        o = t.getCTM && Ad(t),
        !m && "%" !== h || !Fe[e] && !~e.indexOf("adius") ? (l[f ? "width" : "height"] = 100 + (c ? h : i),
        a = ~e.indexOf("adius") || "em" === i && t.appendChild && !d ? t : t.parentNode,
        o && (a = (t.ownerSVGElement || {}).parentNode),
        a && a !== fe && a.appendChild || (a = fe.body),
        (s = a._gsap) && m && s.width && f && s.time === Dt.time ? ca(u / s.width * 100) : (!m && "%" !== h || (l.position = td(t, "position")),
        a === t && (l.position = "static"),
        a.appendChild(pe),
        n = pe[p],
        a.removeChild(pe),
        l.position = "absolute",
        f && m && ((s = _(a)).time = Dt.time,
        s.width = a[p]),
        ca(c ? n * u / 100 : n && u ? 100 / n * u : 0))) : (n = o ? t.getBBox()[f ? "width" : "height"] : t[p],
        ca(m ? u / n * 100 : u / 100 * n)))
    }
    function Fd(t, e, r, i) {
        var n;
        return _e || wd(),
        e in qe && "transform" !== e && ~(e = qe[e]).indexOf(",") && (e = e.split(",")[0]),
        Fe[e] && "transform" !== e ? (n = He(t, i),
        n = "transformOrigin" !== e ? n[e] : n.svg ? n.origin : Je(td(t, Xe)) + " " + n.zOrigin + "px") : (n = t.style[e]) && "auto" !== n && !i && !~(n + "").indexOf("calc(") || (n = Ge[e] && Ge[e](t, e, r) || td(t, e) || aa(t, e) || ("opacity" === e ? 1 : 0)),
        r && !~(n + "").trim().indexOf(" ") ? Ed(t, e, n, r) + r : n
    }
    function Gd(t, e, r, i) {
        if (!r || "none" === r) {
            var n = je(e, t, 1)
              , a = n && td(t, n, 1);
            a && a !== r ? (e = n,
            r = a) : "borderColor" === e && (r = td(t, "borderTopColor"))
        }
        var s, o, u, h, l, f, d, _, p, c, m, g = new oe(this._pt,t.style,e,0,1,ee), v = 0, y = 0;
        if (g.b = r,
        g.e = i,
        r += "",
        "auto" === (i += "") && (t.style[e] = i,
        i = td(t, e) || i,
        t.style[e] = r),
        xb(s = [r, i]),
        i = s[1],
        u = (r = s[0]).match(rt) || [],
        (i.match(rt) || []).length) {
            for (; o = rt.exec(i); )
                d = o[0],
                p = i.substring(v, o.index),
                l ? l = (l + 1) % 5 : "rgba(" !== p.substr(-5) && "hsla(" !== p.substr(-5) || (l = 1),
                d !== (f = u[y++] || "") && (h = parseFloat(f) || 0,
                m = f.substr((h + "").length),
                "=" === d.charAt(1) && (d = ea(h, d) + m),
                _ = parseFloat(d),
                c = d.substr((_ + "").length),
                v = rt.lastIndex - c.length,
                c || (c = c || U.units[e] || m,
                v === i.length && (i += c,
                g.e += c)),
                m !== c && (h = Ed(t, e, f, c) || 0),
                g._pt = {
                    _next: g._pt,
                    p: p || 1 === y ? p : ",",
                    s: h,
                    c: _ - h,
                    m: l && l < 4 || "zIndex" === e ? Math.round : 0
                });
            g.c = v < i.length ? i.substring(v, i.length) : ""
        } else
            g.r = "display" === e && "none" === i ? id : hd;
        return nt.test(i) && (g.e = 0),
        this._pt = g
    }
    function Id(t) {
        var e = t.split(" ")
          , r = e[0]
          , i = e[1] || "50%";
        return "top" !== r && "bottom" !== r && "left" !== i && "right" !== i || (t = r,
        r = i,
        i = t),
        e[0] = $e[r] || r,
        e[1] = $e[i] || i,
        e.join(" ")
    }
    function Jd(t, e) {
        if (e.tween && e.tween._time === e.tween._dur) {
            var r, i, n, a = e.t, s = a.style, o = e.u, u = a._gsap;
            if ("all" === o || !0 === o)
                s.cssText = "",
                i = 1;
            else
                for (n = (o = o.split(",")).length; -1 < --n; )
                    r = o[n],
                    Fe[r] && (i = 1,
                    r = "transformOrigin" === r ? Xe : Ve),
                    Bd(a, r);
            i && (Bd(a, Ve),
            u && (u.svg && a.removeAttribute("transform"),
            He(a, 1),
            u.uncache = 1))
        }
    }
    function Nd(t) {
        return "matrix(1, 0, 0, 1, 0, 0)" === t || "none" === t || !t
    }
    function Od(t) {
        var e = td(t, Ve);
        return Nd(e) ? We : e.substr(7).match(et).map(ca)
    }
    function Pd(t, e) {
        var r, i, n, a, s = t._gsap || _(t), o = t.style, u = Od(t);
        return s.svg && t.getAttribute("transform") ? "1,0,0,1,0,0" === (u = [(n = t.transform.baseVal.consolidate().matrix).a, n.b, n.c, n.d, n.e, n.f]).join(",") ? We : u : (u !== We || t.offsetParent || t === de || s.svg || (n = o.display,
        o.display = "block",
        (r = t.parentNode) && t.offsetParent || (a = 1,
        i = t.nextSibling,
        de.appendChild(t)),
        u = Od(t),
        n ? o.display = n : Bd(t, "display"),
        a && (i ? r.insertBefore(t, i) : r ? r.appendChild(t) : de.removeChild(t))),
        e && 6 < u.length ? [u[0], u[1], u[4], u[5], u[12], u[13]] : u)
    }
    function Qd(t, e, r, i, n, a) {
        var s, o, u, h = t._gsap, l = n || Pd(t, !0), f = h.xOrigin || 0, d = h.yOrigin || 0, _ = h.xOffset || 0, p = h.yOffset || 0, c = l[0], m = l[1], g = l[2], v = l[3], y = l[4], T = l[5], b = e.split(" "), w = parseFloat(b[0]) || 0, x = parseFloat(b[1]) || 0;
        r ? l !== We && (o = c * v - m * g) && (u = w * (-m / o) + x * (c / o) - (c * T - m * y) / o,
        w = w * (v / o) + x * (-g / o) + (g * T - v * y) / o,
        x = u) : (w = (s = zd(t)).x + (~b[0].indexOf("%") ? w / 100 * s.width : w),
        x = s.y + (~(b[1] || b[0]).indexOf("%") ? x / 100 * s.height : x)),
        i || !1 !== i && h.smooth ? (y = w - f,
        T = x - d,
        h.xOffset = _ + (y * c + T * g) - y,
        h.yOffset = p + (y * m + T * v) - T) : h.xOffset = h.yOffset = 0,
        h.xOrigin = w,
        h.yOrigin = x,
        h.smooth = !!i,
        h.origin = e,
        h.originIsAbsolute = !!r,
        t.style[Xe] = "0px 0px",
        a && (Cd(a, h, "xOrigin", f, w),
        Cd(a, h, "yOrigin", d, x),
        Cd(a, h, "xOffset", _, h.xOffset),
        Cd(a, h, "yOffset", p, h.yOffset)),
        t.setAttribute("data-svg-origin", w + " " + x)
    }
    function Td(t, e, r) {
        var i = Ra(e);
        return ca(parseFloat(e) + parseFloat(Ed(t, "x", r + "px", i))) + i
    }
    function $d(t, e, r, i, n) {
        var a, s, u = 360, h = o(n), l = parseFloat(n) * (h && ~n.indexOf("rad") ? Be : 1) - i, f = i + l + "deg";
        return h && ("short" === (a = n.split("_")[1]) && (l %= u) !== l % 180 && (l += l < 0 ? u : -u),
        "cw" === a && l < 0 ? l = (l + 36e9) % u - ~~(l / u) * u : "ccw" === a && 0 < l && (l = (l - 36e9) % u - ~~(l / u) * u)),
        t._pt = s = new oe(t._pt,e,r,i,l,ed),
        s.e = f,
        s.u = "deg",
        t._props.push(r),
        s
    }
    function _d(t, e) {
        for (var r in e)
            t[r] = e[r];
        return t
    }
    function ae(t, e, r) {
        var i, n, a, s, o, u, h, l = _d({}, r._gsap), f = r.style;
        for (n in l.svg ? (a = r.getAttribute("transform"),
        r.setAttribute("transform", ""),
        f[Ve] = e,
        i = He(r, 1),
        Bd(r, Ve),
        r.setAttribute("transform", a)) : (a = getComputedStyle(r)[Ve],
        f[Ve] = e,
        i = He(r, 1),
        f[Ve] = a),
        Fe)
            (a = l[n]) !== (s = i[n]) && "perspective,force3D,transformOrigin,svgOrigin".indexOf(n) < 0 && (o = Ra(a) !== (h = Ra(s)) ? Ed(r, n, a, h) : parseFloat(a),
            u = parseFloat(s),
            t._pt = new oe(t._pt,i,n,o,u - o,dd),
            t._pt.u = h || 0,
            t._props.push(n));
        _d(i, l)
    }
    var le, fe, de, _e, pe, ce, me, ge = zt.Power0, ve = zt.Power1, ye = zt.Power2, Te = zt.Power3, be = zt.Power4, we = zt.Linear, xe = zt.Quad, ke = zt.Cubic, Oe = zt.Quart, Pe = zt.Quint, Me = zt.Strong, Ce = zt.Elastic, Ae = zt.Back, De = zt.SteppedEase, Se = zt.Bounce, ze = zt.Sine, Re = zt.Expo, Ee = zt.Circ, Fe = {}, Be = 180 / Math.PI, Ie = Math.PI / 180, Le = Math.atan2, Ne = /([A-Z])/g, Ue = /(left|right|width|margin|padding|x)/i, Ye = /[\s,\(]\S/, qe = {
        autoAlpha: "opacity,visibility",
        scale: "scaleX,scaleY",
        alpha: "opacity"
    }, Ve = "transform", Xe = Ve + "Origin", Qe = "O,Moz,ms,Ms,Webkit".split(","), je = function _checkPropPrefix(t, e, r) {
        var i = (e || pe).style
          , n = 5;
        if (t in i && !r)
            return t;
        for (t = t.charAt(0).toUpperCase() + t.substr(1); n-- && !(Qe[n] + t in i); )
            ;
        return n < 0 ? null : (3 === n ? "ms" : 0 <= n ? Qe[n] : "") + t
    }, Ke = {
        deg: 1,
        rad: 1,
        turn: 1
    }, $e = {
        top: "0%",
        bottom: "100%",
        left: "0%",
        right: "100%",
        center: "50%"
    }, Ge = {
        clearProps: function clearProps(t, e, r, i, n) {
            if ("isFromStart" !== n.data) {
                var a = t._pt = new oe(t._pt,e,r,0,0,Jd);
                return a.u = i,
                a.pr = -10,
                a.tween = n,
                t._props.push(r),
                1
            }
        }
    }, We = [1, 0, 0, 1, 0, 0], Ze = {}, He = function _parseTransform(t, e) {
        var r = t._gsap || new Lt(t);
        if ("x"in r && !e && !r.uncache)
            return r;
        var i, n, a, s, o, u, h, l, f, d, _, p, c, m, g, v, y, T, b, w, x, k, O, P, M, C, A, D, S, z, R, E, F = t.style, B = r.scaleX < 0, I = "deg", L = td(t, Xe) || "0";
        return i = n = a = u = h = l = f = d = _ = 0,
        s = o = 1,
        r.svg = !(!t.getCTM || !Ad(t)),
        m = Pd(t, r.svg),
        r.svg && (P = (!r.uncache || "0px 0px" === L) && !e && t.getAttribute("data-svg-origin"),
        Qd(t, P || L, !!P || r.originIsAbsolute, !1 !== r.smooth, m)),
        p = r.xOrigin || 0,
        c = r.yOrigin || 0,
        m !== We && (T = m[0],
        b = m[1],
        w = m[2],
        x = m[3],
        i = k = m[4],
        n = O = m[5],
        6 === m.length ? (s = Math.sqrt(T * T + b * b),
        o = Math.sqrt(x * x + w * w),
        u = T || b ? Le(b, T) * Be : 0,
        (f = w || x ? Le(w, x) * Be + u : 0) && (o *= Math.abs(Math.cos(f * Ie))),
        r.svg && (i -= p - (p * T + c * w),
        n -= c - (p * b + c * x))) : (E = m[6],
        z = m[7],
        A = m[8],
        D = m[9],
        S = m[10],
        R = m[11],
        i = m[12],
        n = m[13],
        a = m[14],
        h = (g = Le(E, S)) * Be,
        g && (P = k * (v = Math.cos(-g)) + A * (y = Math.sin(-g)),
        M = O * v + D * y,
        C = E * v + S * y,
        A = k * -y + A * v,
        D = O * -y + D * v,
        S = E * -y + S * v,
        R = z * -y + R * v,
        k = P,
        O = M,
        E = C),
        l = (g = Le(-w, S)) * Be,
        g && (v = Math.cos(-g),
        R = x * (y = Math.sin(-g)) + R * v,
        T = P = T * v - A * y,
        b = M = b * v - D * y,
        w = C = w * v - S * y),
        u = (g = Le(b, T)) * Be,
        g && (P = T * (v = Math.cos(g)) + b * (y = Math.sin(g)),
        M = k * v + O * y,
        b = b * v - T * y,
        O = O * v - k * y,
        T = P,
        k = M),
        h && 359.9 < Math.abs(h) + Math.abs(u) && (h = u = 0,
        l = 180 - l),
        s = ca(Math.sqrt(T * T + b * b + w * w)),
        o = ca(Math.sqrt(O * O + E * E)),
        g = Le(k, O),
        f = 2e-4 < Math.abs(g) ? g * Be : 0,
        _ = R ? 1 / (R < 0 ? -R : R) : 0),
        r.svg && (P = t.getAttribute("transform"),
        r.forceCSS = t.setAttribute("transform", "") || !Nd(td(t, Ve)),
        P && t.setAttribute("transform", P))),
        90 < Math.abs(f) && Math.abs(f) < 270 && (B ? (s *= -1,
        f += u <= 0 ? 180 : -180,
        u += u <= 0 ? 180 : -180) : (o *= -1,
        f += f <= 0 ? 180 : -180)),
        e = e || r.uncache,
        r.x = i - ((r.xPercent = i && (!e && r.xPercent || (Math.round(t.offsetWidth / 2) === Math.round(-i) ? -50 : 0))) ? t.offsetWidth * r.xPercent / 100 : 0) + "px",
        r.y = n - ((r.yPercent = n && (!e && r.yPercent || (Math.round(t.offsetHeight / 2) === Math.round(-n) ? -50 : 0))) ? t.offsetHeight * r.yPercent / 100 : 0) + "px",
        r.z = a + "px",
        r.scaleX = ca(s),
        r.scaleY = ca(o),
        r.rotation = ca(u) + I,
        r.rotationX = ca(h) + I,
        r.rotationY = ca(l) + I,
        r.skewX = f + I,
        r.skewY = d + I,
        r.transformPerspective = _ + "px",
        (r.zOrigin = parseFloat(L.split(" ")[2]) || 0) && (F[Xe] = Je(L)),
        r.xOffset = r.yOffset = 0,
        r.force3D = U.force3D,
        r.renderTransform = r.svg ? ar : me ? nr : tr,
        r.uncache = 0,
        r
    }, Je = function _firstTwoOnly(t) {
        return (t = t.split(" "))[0] + " " + t[1]
    }, tr = function _renderNon3DTransforms(t, e) {
        e.z = "0px",
        e.rotationY = e.rotationX = "0deg",
        e.force3D = 0,
        nr(t, e)
    }, er = "0deg", rr = "0px", ir = ") ", nr = function _renderCSSTransforms(t, e) {
        var r = e || this
          , i = r.xPercent
          , n = r.yPercent
          , a = r.x
          , s = r.y
          , o = r.z
          , u = r.rotation
          , h = r.rotationY
          , l = r.rotationX
          , f = r.skewX
          , d = r.skewY
          , _ = r.scaleX
          , p = r.scaleY
          , c = r.transformPerspective
          , m = r.force3D
          , g = r.target
          , v = r.zOrigin
          , y = ""
          , T = "auto" === m && t && 1 !== t || !0 === m;
        if (v && (l !== er || h !== er)) {
            var b, w = parseFloat(h) * Ie, x = Math.sin(w), k = Math.cos(w);
            w = parseFloat(l) * Ie,
            b = Math.cos(w),
            a = Td(g, a, x * b * -v),
            s = Td(g, s, -Math.sin(w) * -v),
            o = Td(g, o, k * b * -v + v)
        }
        c !== rr && (y += "perspective(" + c + ir),
        (i || n) && (y += "translate(" + i + "%, " + n + "%) "),
        !T && a === rr && s === rr && o === rr || (y += o !== rr || T ? "translate3d(" + a + ", " + s + ", " + o + ") " : "translate(" + a + ", " + s + ir),
        u !== er && (y += "rotate(" + u + ir),
        h !== er && (y += "rotateY(" + h + ir),
        l !== er && (y += "rotateX(" + l + ir),
        f === er && d === er || (y += "skew(" + f + ", " + d + ir),
        1 === _ && 1 === p || (y += "scale(" + _ + ", " + p + ir),
        g.style[Ve] = y || "translate(0, 0)"
    }, ar = function _renderSVGTransforms(t, e) {
        var r, i, n, a, s, o = e || this, u = o.xPercent, h = o.yPercent, l = o.x, f = o.y, d = o.rotation, _ = o.skewX, p = o.skewY, c = o.scaleX, m = o.scaleY, g = o.target, v = o.xOrigin, y = o.yOrigin, T = o.xOffset, b = o.yOffset, w = o.forceCSS, x = parseFloat(l), k = parseFloat(f);
        d = parseFloat(d),
        _ = parseFloat(_),
        (p = parseFloat(p)) && (_ += p = parseFloat(p),
        d += p),
        d || _ ? (d *= Ie,
        _ *= Ie,
        r = Math.cos(d) * c,
        i = Math.sin(d) * c,
        n = Math.sin(d - _) * -m,
        a = Math.cos(d - _) * m,
        _ && (p *= Ie,
        s = Math.tan(_ - p),
        n *= s = Math.sqrt(1 + s * s),
        a *= s,
        p && (s = Math.tan(p),
        r *= s = Math.sqrt(1 + s * s),
        i *= s)),
        r = ca(r),
        i = ca(i),
        n = ca(n),
        a = ca(a)) : (r = c,
        a = m,
        i = n = 0),
        (x && !~(l + "").indexOf("px") || k && !~(f + "").indexOf("px")) && (x = Ed(g, "x", l, "px"),
        k = Ed(g, "y", f, "px")),
        (v || y || T || b) && (x = ca(x + v - (v * r + y * n) + T),
        k = ca(k + y - (v * i + y * a) + b)),
        (u || h) && (s = g.getBBox(),
        x = ca(x + u / 100 * s.width),
        k = ca(k + h / 100 * s.height)),
        s = "matrix(" + r + "," + i + "," + n + "," + a + "," + x + "," + k + ")",
        g.setAttribute("transform", s),
        w && (g.style[Ve] = s)
    };
    ba("padding,margin,Width,Radius", function(e, r) {
        var t = "Right"
          , i = "Bottom"
          , n = "Left"
          , o = (r < 3 ? ["Top", t, i, n] : ["Top" + n, "Top" + t, i + t, i + n]).map(function(t) {
            return r < 2 ? e + t : "border" + t + e
        });
        Ge[1 < r ? "border" + e : e] = function(e, t, r, i, n) {
            var a, s;
            if (arguments.length < 4)
                return a = o.map(function(t) {
                    return Fd(e, t, r)
                }),
                5 === (s = a.join(" ")).split(a[0]).length ? a[0] : s;
            a = (i + "").split(" "),
            s = {},
            o.forEach(function(t, e) {
                return s[t] = a[e] = a[e] || a[(e - 1) / 2 | 0]
            }),
            e.init(t, s, n)
        }
    });
    var sr, or, ur, hr = {
        name: "css",
        register: wd,
        targetTest: function targetTest(t) {
            return t.style && t.nodeType
        },
        init: function init(t, e, r, i, n) {
            var a, s, u, h, l, f, d, _, p, c, m, g, v, y, T, b = this._props, w = t.style, x = r.vars.startAt;
            for (d in _e || wd(),
            e)
                if ("autoRound" !== d && (s = e[d],
                !ft[d] || !Ub(d, e, r, i, t, n)))
                    if (l = typeof s,
                    f = Ge[d],
                    "function" === l && (l = typeof (s = s.call(r, i, t, n))),
                    "string" === l && ~s.indexOf("random(") && (s = hb(s)),
                    f)
                        f(this, t, d, s, r) && (T = 1);
                    else if ("--" === d.substr(0, 2))
                        a = (getComputedStyle(t).getPropertyValue(d) + "").trim(),
                        s += "",
                        Ct.lastIndex = 0,
                        Ct.test(a) || (_ = Ra(a),
                        p = Ra(s)),
                        p ? _ !== p && (a = Ed(t, d, a, p) + p) : _ && (s += _),
                        this.add(w, "setProperty", a, s, i, n, 0, 0, d),
                        b.push(d);
                    else if ("undefined" !== l) {
                        if (x && d in x ? (a = "function" == typeof x[d] ? x[d].call(r, i, t, n) : x[d],
                        o(a) && ~a.indexOf("random(") && (a = hb(a)),
                        Ra(a + "") || (a += U.units[d] || Ra(Fd(t, d)) || ""),
                        "=" === (a + "").charAt(1) && (a = Fd(t, d))) : a = Fd(t, d),
                        h = parseFloat(a),
                        (c = "string" === l && "=" === s.charAt(1) && s.substr(0, 2)) && (s = s.substr(2)),
                        u = parseFloat(s),
                        d in qe && ("autoAlpha" === d && (1 === h && "hidden" === Fd(t, "visibility") && u && (h = 0),
                        Cd(this, w, "visibility", h ? "inherit" : "hidden", u ? "inherit" : "hidden", !u)),
                        "scale" !== d && "transform" !== d && ~(d = qe[d]).indexOf(",") && (d = d.split(",")[0])),
                        m = d in Fe)
                            if (g || ((v = t._gsap).renderTransform && !e.parseTransform || He(t, e.parseTransform),
                            y = !1 !== e.smoothOrigin && v.smooth,
                            (g = this._pt = new oe(this._pt,w,Ve,0,1,v.renderTransform,v,0,-1)).dep = 1),
                            "scale" === d)
                                this._pt = new oe(this._pt,v,"scaleY",v.scaleY,(c ? ea(v.scaleY, c + u) : u) - v.scaleY || 0),
                                b.push("scaleY", d),
                                d += "X";
                            else {
                                if ("transformOrigin" === d) {
                                    s = Id(s),
                                    v.svg ? Qd(t, s, 0, y, 0, this) : ((p = parseFloat(s.split(" ")[2]) || 0) !== v.zOrigin && Cd(this, v, "zOrigin", v.zOrigin, p),
                                    Cd(this, w, d, Je(a), Je(s)));
                                    continue
                                }
                                if ("svgOrigin" === d) {
                                    Qd(t, s, 1, y, 0, this);
                                    continue
                                }
                                if (d in Ze) {
                                    $d(this, v, d, h, c ? ea(h, c + s) : s);
                                    continue
                                }
                                if ("smoothOrigin" === d) {
                                    Cd(this, v, "smooth", v.smooth, s);
                                    continue
                                }
                                if ("force3D" === d) {
                                    v[d] = s;
                                    continue
                                }
                                if ("transform" === d) {
                                    ae(this, s, t);
                                    continue
                                }
                            }
                        else
                            d in w || (d = je(d) || d);
                        if (m || (u || 0 === u) && (h || 0 === h) && !Ye.test(s) && d in w)
                            u = u || 0,
                            (_ = (a + "").substr((h + "").length)) !== (p = Ra(s) || (d in U.units ? U.units[d] : _)) && (h = Ed(t, d, a, p)),
                            this._pt = new oe(this._pt,m ? v : w,d,h,(c ? ea(h, c + u) : u) - h,m || "px" !== p && "zIndex" !== d || !1 === e.autoRound ? dd : gd),
                            this._pt.u = p || 0,
                            _ !== p && "%" !== p && (this._pt.b = a,
                            this._pt.r = fd);
                        else if (d in w)
                            Gd.call(this, t, d, a, c ? c + s : s);
                        else {
                            if (!(d in t)) {
                                N(d, s);
                                continue
                            }
                            this.add(t, d, a || t[d], c ? c + s : s, i, n)
                        }
                        b.push(d)
                    }
            T && se(this)
        },
        get: Fd,
        aliases: qe,
        getSetter: function getSetter(t, e, i) {
            var n = qe[e];
            return n && n.indexOf(",") < 0 && (e = n),
            e in Fe && e !== Xe && (t._gsap.x || Fd(t, "x")) ? i && ce === i ? "scale" === e ? md : ld : (ce = i || {}) && ("scale" === e ? nd : od) : t.style && !r(t.style[e]) ? jd : ~e.indexOf("-") ? kd : Ht(t, e)
        },
        core: {
            _removeProperty: Bd,
            _getMatrix: Pd
        }
    };
    he.utils.checkPrefix = je,
    ur = ba((sr = "x,y,z,scale,scaleX,scaleY,xPercent,yPercent") + "," + (or = "rotation,rotationX,rotationY,skewX,skewY") + ",transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", function(t) {
        Fe[t] = 1
    }),
    ba(or, function(t) {
        U.units[t] = "deg",
        Ze[t] = 1
    }),
    qe[ur[13]] = sr + "," + or,
    ba("0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY", function(t) {
        var e = t.split(":");
        qe[e[1]] = ur[e[0]]
    }),
    ba("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(t) {
        U.units[t] = "px"
    }),
    he.registerPlugin(hr);
    var lr = he.registerPlugin(hr) || he
      , fr = lr.core.Tween;
    e.Back = Ae,
    e.Bounce = Se,
    e.CSSPlugin = hr,
    e.Circ = Ee,
    e.Cubic = ke,
    e.Elastic = Ce,
    e.Expo = Re,
    e.Linear = we,
    e.Power0 = ge,
    e.Power1 = ve,
    e.Power2 = ye,
    e.Power3 = Te,
    e.Power4 = be,
    e.Quad = xe,
    e.Quart = Oe,
    e.Quint = Pe,
    e.Sine = ze,
    e.SteppedEase = De,
    e.Strong = Me,
    e.TimelineLite = Ut,
    e.TimelineMax = Ut,
    e.TweenLite = $t,
    e.TweenMax = fr,
    e.default = lr,
    e.gsap = lr;
    if (typeof (window) === "undefined" || window !== e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        })
    } else {
        delete e.default
    }
});
/*!
 * ScrollTrigger 3.10.4
 * https://greensock.com
 *
 * @license Copyright 2022, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
!function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? t(exports) : "function" == typeof define && define.amd ? define(["exports"], t) : t((e = e || self).window = e.window || {})
}(this, function(e) {
    "use strict";
    function _defineProperties(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1,
            n.configurable = !0,
            "value"in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n)
        }
    }
    function q() {
        return we || "undefined" != typeof window && (we = window.gsap) && we.registerPlugin && we
    }
    function y(e, t) {
        return ~Le.indexOf(e) && Le[Le.indexOf(e) + 1][t]
    }
    function z(e) {
        return !!~t.indexOf(e)
    }
    function A(e, t, r, n, i) {
        return e.addEventListener(t, r, {
            passive: !n,
            capture: !!i
        })
    }
    function B(e, t, r, n) {
        return e.removeEventListener(t, r, !!n)
    }
    function E() {
        return De && De.isPressed || T.cache++
    }
    function F(r, n) {
        function Uc(e) {
            if (e || 0 === e) {
                i && (Me.history.scrollRestoration = "manual");
                var t = De && De.isPressed;
                e = Uc.v = Math.round(e) || (De && De.iOS ? 1 : 0),
                r(e),
                Uc.cacheID = T.cache,
                t && o("ss", e)
            } else
                (n || T.cache !== Uc.cacheID || o("ref")) && (Uc.cacheID = T.cache,
                Uc.v = r());
            return Uc.v + Uc.offset
        }
        return Uc.offset = 0,
        r && Uc
    }
    function I(e) {
        return we.utils.toArray(e)[0] || ("string" == typeof e && !1 !== we.config().nullTargetWarn ? console.warn("Element not found:", e) : null)
    }
    function J(t, e) {
        var r = e.s
          , n = e.sc
          , i = T.indexOf(t)
          , o = n === Ne.sc ? 1 : 2;
        return ~i || (i = T.push(t) - 1),
        T[i + o] || (T[i + o] = F(y(t, r), !0) || (z(t) ? n : F(function(e) {
            return arguments.length ? t[r] = e : t[r]
        })))
    }
    function K(e, t, i) {
        function od(e, t) {
            var r = He();
            t || n < r - s ? (a = o,
            o = e,
            l = s,
            s = r) : i ? o += e : o = a + (e - a) / (r - l) * (s - l)
        }
        var o = e
          , a = e
          , s = He()
          , l = s
          , n = t || 50
          , c = Math.max(500, 3 * n);
        return {
            update: od,
            reset: function reset() {
                a = o = i ? 0 : o,
                l = s = 0
            },
            getVelocity: function getVelocity(e) {
                var t = l
                  , r = a
                  , n = He();
                return !e && 0 !== e || e === o || od(e),
                s === l || c < n - l ? 0 : (o + (i ? r : -r)) / ((i ? n : s) - t) * 1e3
            }
        }
    }
    function L(e, t) {
        return t && !e._gsapAllow && e.preventDefault(),
        e.changedTouches ? e.changedTouches[0] : e
    }
    function M(e) {
        var t = Math.max.apply(Math, e)
          , r = Math.min.apply(Math, e);
        return Math.abs(t) >= Math.abs(r) ? t : r
    }
    function N() {
        (Be = we.core.globals().ScrollTrigger) && Be.core && function _integrate() {
            var e = Be.core
              , r = e.bridge || {}
              , t = e._scrollers
              , n = e._proxies;
            t.push.apply(t, T),
            n.push.apply(n, Le),
            T = t,
            Le = n,
            o = function _bridge(e, t) {
                return r[e](t)
            }
        }()
    }
    function O(e) {
        return (we = e || q()) && "undefined" != typeof document && document.body && (Me = window,
        Ce = (Ae = document).documentElement,
        Oe = Ae.body,
        t = [Me, Ae, Ce, Oe],
        we.utils.clamp,
        Ie = "onpointerenter"in Oe ? "pointer" : "mouse",
        Ee = k.isTouch = Me.matchMedia && Me.matchMedia("(hover: none), (pointer: coarse)").matches ? 1 : "ontouchstart"in Me || 0 < navigator.maxTouchPoints || 0 < navigator.msMaxTouchPoints ? 2 : 0,
        ze = k.eventTypes = ("ontouchstart"in Ce ? "touchstart,touchmove,touchcancel,touchend" : "onpointerdown"in Ce ? "pointerdown,pointermove,pointercancel,pointerup" : "mousedown,mousemove,mouseup,mouseup").split(","),
        setTimeout(function() {
            return i = 0
        }, 500),
        N(),
        ke = 1),
        ke
    }
    var we, ke, Me, Ae, Ce, Oe, Ee, Ie, Be, t, De, ze, i = 1, Fe = [], T = [], Le = [], He = Date.now, o = function _bridge(e, t) {
        return t
    }, r = "scrollLeft", n = "scrollTop", Re = {
        s: r,
        p: "left",
        p2: "Left",
        os: "right",
        os2: "Right",
        d: "width",
        d2: "Width",
        a: "x",
        sc: F(function(e) {
            return arguments.length ? Me.scrollTo(e, Ne.sc()) : Me.pageXOffset || Ae[r] || Ce[r] || Oe[r] || 0
        })
    }, Ne = {
        s: n,
        p: "top",
        p2: "Top",
        os: "bottom",
        os2: "Bottom",
        d: "height",
        d2: "Height",
        a: "y",
        op: Re,
        sc: F(function(e) {
            return arguments.length ? Me.scrollTo(Re.sc(), e) : Me.pageYOffset || Ae[n] || Ce[n] || Oe[n] || 0
        })
    };
    Re.op = Ne,
    T.cache = 0;
    var k = (Observer.prototype.init = function init(e) {
        ke || O(we) || console.warn("Please gsap.registerPlugin(Observer)"),
        Be || N();
        var i = e.tolerance
          , a = e.dragMinimum
          , t = e.type
          , n = e.target
          , r = e.lineHeight
          , o = e.debounce
          , s = e.preventDefault
          , l = e.onStop
          , c = e.onStopDelay
          , u = e.ignore
          , f = e.wheelSpeed
          , d = e.event
          , p = e.onDragStart
          , g = e.onDragEnd
          , h = e.onDrag
          , v = e.onPress
          , b = e.onRelease
          , m = e.onRight
          , y = e.onLeft
          , x = e.onUp
          , w = e.onDown
          , S = e.onChangeX
          , _ = e.onChangeY
          , T = e.onChange
          , k = e.onToggleX
          , C = e.onToggleY
          , P = e.onHover
          , D = e.onHoverEnd
          , Y = e.onMove
          , X = e.ignoreCheck
          , F = e.isNormalizer
          , H = e.onGestureStart
          , R = e.onGestureEnd
          , U = e.onWheel
          , V = e.onEnable
          , W = e.onDisable
          , j = e.onClick
          , Q = e.scrollSpeed
          , q = e.capture
          , G = e.allowClicks
          , Z = e.lockAxis
          , $ = e.onLockAxis;
        function Pe() {
            return ye = He()
        }
        function Qe(e, t) {
            return (se.event = e) && u && ~u.indexOf(e.target) || t && ge && "touch" !== e.pointerType || X && X(e, t)
        }
        function Se() {
            var e = se.deltaX = M(be)
              , t = se.deltaY = M(me)
              , r = Math.abs(e) >= i
              , n = Math.abs(t) >= i;
            T && (r || n) && T(se, e, t, be, me),
            r && (m && 0 < se.deltaX && m(se),
            y && se.deltaX < 0 && y(se),
            S && S(se),
            k && se.deltaX < 0 != le < 0 && k(se),
            le = se.deltaX,
            be[0] = be[1] = be[2] = 0),
            n && (w && 0 < se.deltaY && w(se),
            x && se.deltaY < 0 && x(se),
            _ && _(se),
            C && se.deltaY < 0 != ce < 0 && C(se),
            ce = se.deltaY,
            me[0] = me[1] = me[2] = 0),
            (ne || re) && (Y && Y(se),
            $ && oe && $(se),
            re && (h(se),
            re = !1),
            ne = oe = !1),
            ie && (U(se),
            ie = !1),
            ee = 0
        }
        function Te(e, t, r) {
            be[r] += e,
            me[r] += t,
            se._vx.update(e),
            se._vy.update(t),
            o ? ee = ee || requestAnimationFrame(Se) : Se()
        }
        function Ue(e, t) {
            "y" !== ae && (be[2] += e,
            se._vx.update(e, !0)),
            "x" !== ae && (me[2] += t,
            se._vy.update(t, !0)),
            Z && !ae && (se.axis = ae = Math.abs(e) > Math.abs(t) ? "x" : "y",
            oe = !0),
            o ? ee = ee || requestAnimationFrame(Se) : Se()
        }
        function Ve(e) {
            if (!Qe(e, 1)) {
                var t = (e = L(e, s)).clientX
                  , r = e.clientY
                  , n = t - se.x
                  , i = r - se.y
                  , o = se.isDragging;
                se.x = t,
                se.y = r,
                (o || Math.abs(se.startX - t) >= a || Math.abs(se.startY - r) >= a) && (h && (re = !0),
                o || (se.isDragging = !0),
                Ue(n, i),
                o || p && p(se))
            }
        }
        function Xe(t) {
            if (!Qe(t, 1)) {
                B(F ? n : ve, ze[1], Ve, !0);
                var e = se.isDragging && (3 < Math.abs(se.x - se.startX) || 3 < Math.abs(se.y - se.startY))
                  , r = L(t);
                e || (se._vx.reset(),
                se._vy.reset(),
                s && G && we.delayedCall(.08, function() {
                    if (300 < He() - ye && !t.defaultPrevented)
                        if (t.target.click)
                            t.target.click();
                        else if (ve.createEvent) {
                            var e = ve.createEvent("MouseEvents");
                            e.initMouseEvent("click", !0, !0, Me, 1, r.screenX, r.screenY, r.clientX, r.clientY, !1, !1, !1, !1, 0, null),
                            t.target.dispatchEvent(e)
                        }
                })),
                se.isDragging = se.isGesturing = se.isPressed = !1,
                l && !F && te.restart(!0),
                g && e && g(se),
                b && b(se, e)
            }
        }
        function Ye(e) {
            return e.touches && 1 < e.touches.length && (se.isGesturing = !0) && H(e, se.isDragging)
        }
        function Ze() {
            return (se.isGesturing = !1) || R(se)
        }
        function $e(e) {
            if (!Qe(e)) {
                var t = ue()
                  , r = fe();
                Te((t - de) * Q, (r - pe) * Q, 1),
                de = t,
                pe = r,
                l && te.restart(!0)
            }
        }
        function _e(e) {
            if (!Qe(e)) {
                e = L(e, s),
                U && (ie = !0);
                var t = (1 === e.deltaMode ? r : 2 === e.deltaMode ? Me.innerHeight : 1) * f;
                Te(e.deltaX * t, e.deltaY * t, 0),
                l && !F && te.restart(!0)
            }
        }
        function af(e) {
            if (!Qe(e)) {
                var t = e.clientX
                  , r = e.clientY
                  , n = t - se.x
                  , i = r - se.y;
                se.x = t,
                se.y = r,
                ne = !0,
                (n || i) && Ue(n, i)
            }
        }
        function bf(e) {
            se.event = e,
            P(se)
        }
        function cf(e) {
            se.event = e,
            D(se)
        }
        function df(e) {
            return Qe(e) || L(e, s) && j(se)
        }
        this.target = n = I(n) || Ce,
        this.vars = e,
        u = u && we.utils.toArray(u),
        i = i || 0,
        a = a || 0,
        f = f || 1,
        Q = Q || 1,
        t = t || "wheel,touch,pointer",
        o = !1 !== o,
        r = r || parseFloat(Me.getComputedStyle(Oe).lineHeight) || 22;
        var ee, te, re, ne, ie, oe, ae, se = this, le = 0, ce = 0, ue = J(n, Re), fe = J(n, Ne), de = ue(), pe = fe(), ge = ~t.indexOf("touch") && !~t.indexOf("pointer") && "pointerdown" === ze[0], he = z(n), ve = n.ownerDocument || Ae, be = [0, 0, 0], me = [0, 0, 0], ye = 0, xe = se.onPress = function(e) {
            Qe(e, 1) || (se.axis = ae = null,
            te.pause(),
            se.isPressed = !0,
            e = L(e),
            le = ce = 0,
            se.startX = se.x = e.clientX,
            se.startY = se.y = e.clientY,
            se._vx.reset(),
            se._vy.reset(),
            A(F ? n : ve, ze[1], Ve, s, !0),
            se.deltaX = se.deltaY = 0,
            v && v(se))
        }
        ;
        te = se._dc = we.delayedCall(c || .25, function onStopFunc() {
            se._vx.reset(),
            se._vy.reset(),
            te.pause(),
            l && l(se)
        }).pause(),
        se.deltaX = se.deltaY = 0,
        se._vx = K(0, 50, !0),
        se._vy = K(0, 50, !0),
        se.scrollX = ue,
        se.scrollY = fe,
        se.isDragging = se.isGesturing = se.isPressed = !1,
        se.enable = function(e) {
            return se.isEnabled || (A(he ? ve : n, "scroll", E),
            0 <= t.indexOf("scroll") && A(he ? ve : n, "scroll", $e, s, q),
            0 <= t.indexOf("wheel") && A(n, "wheel", _e, s, q),
            (0 <= t.indexOf("touch") && Ee || 0 <= t.indexOf("pointer")) && (A(n, ze[0], xe, s, q),
            A(ve, ze[2], Xe),
            A(ve, ze[3], Xe),
            G && A(n, "click", Pe, !1, !0),
            j && A(n, "click", df),
            H && A(ve, "gesturestart", Ye),
            R && A(ve, "gestureend", Ze),
            P && A(n, Ie + "enter", bf),
            D && A(n, Ie + "leave", cf),
            Y && A(n, Ie + "move", af)),
            se.isEnabled = !0,
            e && e.type && xe(e),
            V && V(se)),
            se
        }
        ,
        se.disable = function() {
            se.isEnabled && (Fe.filter(function(e) {
                return e !== se && z(e.target)
            }).length || B(he ? ve : n, "scroll", E),
            se.isPressed && (se._vx.reset(),
            se._vy.reset(),
            B(F ? n : ve, ze[1], Ve, !0)),
            B(he ? ve : n, "scroll", $e, q),
            B(n, "wheel", _e, q),
            B(n, ze[0], xe, q),
            B(ve, ze[2], Xe),
            B(ve, ze[3], Xe),
            B(n, "click", Pe, !0),
            B(n, "click", df),
            B(ve, "gesturestart", Ye),
            B(ve, "gestureend", Ze),
            B(n, Ie + "enter", bf),
            B(n, Ie + "leave", cf),
            B(n, Ie + "move", af),
            se.isEnabled = se.isPressed = se.isDragging = !1,
            W && W(se))
        }
        ,
        se.kill = function() {
            se.disable();
            var e = Fe.indexOf(se);
            0 <= e && Fe.splice(e, 1),
            De === se && (De = 0)
        }
        ,
        Fe.push(se),
        F && z(n) && (De = se),
        se.enable(d)
    }
    ,
    function _createClass(e, t, r) {
        return t && _defineProperties(e.prototype, t),
        r && _defineProperties(e, r),
        e
    }(Observer, [{
        key: "velocityX",
        get: function get() {
            return this._vx.getVelocity()
        }
    }, {
        key: "velocityY",
        get: function get() {
            return this._vy.getVelocity()
        }
    }]),
    Observer);
    function Observer(e) {
        this.init(e)
    }
    k.version = "3.10.4",
    k.create = function(e) {
        return new k(e)
    }
    ,
    k.register = O,
    k.getAll = function() {
        return Fe.slice()
    }
    ,
    k.getById = function(t) {
        return Fe.filter(function(e) {
            return e.vars.id === t
        })[0]
    }
    ,
    q() && we.registerPlugin(k);
    function va() {
        return nt = 1
    }
    function wa() {
        return nt = 0
    }
    function xa(e) {
        return e
    }
    function ya(e) {
        return Math.round(1e5 * e) / 1e5 || 0
    }
    function za() {
        return "undefined" != typeof window
    }
    function Aa() {
        return We || za() && (We = window.gsap) && We.registerPlugin && We
    }
    function Ba(e) {
        return !!~s.indexOf(e)
    }
    function Ca(e) {
        return y(e, "getBoundingClientRect") || (Ba(e) ? function() {
            return Bt.width = je.innerWidth,
            Bt.height = je.innerHeight,
            Bt
        }
        : function() {
            return Mt(e)
        }
        )
    }
    function Fa(e, t) {
        var r = t.s
          , n = t.d2
          , i = t.d
          , o = t.a;
        return (r = "scroll" + n) && (o = y(e, r)) ? o() - Ca(e)()[i] : Ba(e) ? (qe[r] || Ge[r]) - (je["inner" + n] || qe["client" + n] || Ge["client" + n]) : e[r] - e["offset" + n]
    }
    function Ga(e, t) {
        for (var r = 0; r < p.length; r += 3)
            t && !~t.indexOf(p[r + 1]) || e(p[r], p[r + 1], p[r + 2])
    }
    function Ha(e) {
        return "string" == typeof e
    }
    function Ia(e) {
        return "function" == typeof e
    }
    function Ja(e) {
        return "number" == typeof e
    }
    function Ka(e) {
        return "object" == typeof e
    }
    function La(e) {
        return Ia(e) && e()
    }
    function Ma(r, n) {
        return function() {
            var e = La(r)
              , t = La(n);
            return function() {
                La(e),
                La(t)
            }
        }
    }
    function Na(e, t, r) {
        return e && e.progress(t ? 0 : 1) && r && e.pause()
    }
    function Oa(e, t) {
        if (e.enabled) {
            var r = t(e);
            r && r.totalTime && (e.callbackAnimation = r)
        }
    }
    function db(e) {
        return je.getComputedStyle(e)
    }
    function fb(e, t) {
        for (var r in t)
            r in e || (e[r] = t[r]);
        return e
    }
    function hb(e, t) {
        var r = t.d2;
        return e["offset" + r] || e["client" + r] || 0
    }
    function ib(e) {
        var t, r = [], n = e.labels, i = e.duration();
        for (t in n)
            r.push(n[t] / i);
        return r
    }
    function kb(i) {
        var o = We.utils.snap(i)
          , a = Array.isArray(i) && i.slice(0).sort(function(e, t) {
            return e - t
        });
        return a ? function(e, t, r) {
            var n;
            if (void 0 === r && (r = .001),
            !t)
                return o(e);
            if (0 < t) {
                for (e -= r,
                n = 0; n < a.length; n++)
                    if (a[n] >= e)
                        return a[n];
                return a[n - 1]
            }
            for (n = a.length,
            e += r; n--; )
                if (a[n] <= e)
                    return a[n];
            return a[0]
        }
        : function(e, t, r) {
            void 0 === r && (r = .001);
            var n = o(e);
            return !t || Math.abs(n - e) < r || n - e < 0 == t < 0 ? n : o(t < 0 ? e - i : e + i)
        }
    }
    function mb(t, r, e, n) {
        return e.split(",").forEach(function(e) {
            return t(r, e, n)
        })
    }
    function nb(e, t, r, n, i) {
        return e.addEventListener(t, r, {
            passive: !n,
            capture: !!i
        })
    }
    function ob(e, t, r, n) {
        return e.removeEventListener(t, r, !!n)
    }
    function pb(e, t, r) {
        return r && r.wheelHandler && e(t, "wheel", r)
    }
    function tb(e, t) {
        if (Ha(e)) {
            var r = e.indexOf("=")
              , n = ~r ? (e.charAt(r - 1) + 1) * parseFloat(e.substr(r + 1)) : 0;
            ~r && (e.indexOf("%") > r && (n *= t / 100),
            e = e.substr(0, r - 1)),
            e = n + (e in Y ? Y[e] * t : ~e.indexOf("%") ? parseFloat(e) * t / 100 : parseFloat(e) || 0)
        }
        return e
    }
    function ub(e, t, r, n, i, o, a, s) {
        var l = i.startColor
          , c = i.endColor
          , u = i.fontSize
          , f = i.indent
          , d = i.fontWeight
          , p = Je.createElement("div")
          , g = Ba(r) || "fixed" === y(r, "pinType")
          , h = -1 !== e.indexOf("scroller")
          , v = g ? Ge : r
          , b = -1 !== e.indexOf("start")
          , m = b ? l : c
          , x = "border-color:" + m + ";font-size:" + u + ";color:" + m + ";font-weight:" + d + ";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";
        return x += "position:" + ((h || s) && g ? "fixed;" : "absolute;"),
        !h && !s && g || (x += (n === Ne ? _ : P) + ":" + (o + parseFloat(f)) + "px;"),
        a && (x += "box-sizing:border-box;text-align:left;width:" + a.offsetWidth + "px;"),
        p._isStart = b,
        p.setAttribute("class", "gsap-marker-" + e + (t ? " marker-" + t : "")),
        p.style.cssText = x,
        p.innerText = t || 0 === t ? e + "-" + t : e,
        v.children[0] ? v.insertBefore(p, v.children[0]) : v.appendChild(p),
        p._offset = p["offset" + n.op.d2],
        X(p, 0, n, b),
        p
    }
    function zb() {
        return 34 < dt() - pt && ee()
    }
    function Ab() {
        h && h.isPressed && !(h.startX > Ge.clientWidth) || (T.cache++,
        x = x || requestAnimationFrame(ee),
        pt || V("scrollStart"),
        pt = dt())
    }
    function Bb() {
        m = je.innerWidth,
        b = je.innerHeight
    }
    function Cb() {
        T.cache++,
        rt || g || Je.fullscreenElement || Je.webkitFullscreenElement || v && m === je.innerWidth && !(Math.abs(je.innerHeight - b) > .25 * je.innerHeight) || l.restart(!0)
    }
    function Ib(e) {
        var t, r = We.ticker.frame, n = [], i = 0;
        if (w !== r || ft) {
            for (Q(); i < U.length; i += 4)
                (t = je.matchMedia(U[i]).matches) !== U[i + 3] && ((U[i + 3] = t) ? n.push(i) : Q(1, U[i]) || Ia(U[i + 2]) && U[i + 2]());
            for (j(),
            i = 0; i < n.length; i++)
                t = n[i],
                lt = U[t],
                U[t + 2] = U[t + 1](e);
            lt = 0,
            a && Z(0, 1),
            w = r,
            V("matchMedia")
        }
    }
    function Jb() {
        return ob(oe, "scrollEnd", Jb) || Z(!0)
    }
    function Ob() {
        return T.cache++ && T.forEach(function(e) {
            return "function" == typeof e && (e.rec = 0)
        })
    }
    function Zb(e, t, r, n) {
        if (e.parentNode !== t) {
            for (var i, o = te.length, a = t.style, s = e.style; o--; )
                a[i = te[o]] = r[i];
            a.position = "absolute" === r.position ? "absolute" : "relative",
            "inline" === r.display && (a.display = "inline-block"),
            s[P] = s[_] = a.flexBasis = "auto",
            a.overflow = "visible",
            a.boxSizing = "border-box",
            a[vt] = hb(e, Re) + kt,
            a[bt] = hb(e, Ne) + kt,
            a[St] = s[_t] = s.top = s.left = "0",
            It(n),
            s[vt] = s.maxWidth = r[vt],
            s[bt] = s.maxHeight = r[bt],
            s[St] = r[St],
            e.parentNode.insertBefore(t, e),
            t.appendChild(e)
        }
    }
    function ac(e) {
        for (var t = re.length, r = e.style, n = [], i = 0; i < t; i++)
            n.push(re[i], r[re[i]]);
        return n.t = e,
        n
    }
    function dc(e, t, r, n, i, o, a, s, l, c, u, f, d) {
        Ia(e) && (e = e(s)),
        Ha(e) && "max" === e.substr(0, 3) && (e = f + ("=" === e.charAt(4) ? tb("0" + e.substr(3), r) : 0));
        var p, g, h, v = d ? d.time() : 0;
        if (d && d.seek(0),
        Ja(e))
            a && X(a, r, n, !0);
        else {
            Ia(t) && (t = t(s));
            var b, m, y, x, w = e.split(" ");
            h = I(t) || Ge,
            (b = Mt(h) || {}) && (b.left || b.top) || "none" !== db(h).display || (x = h.style.display,
            h.style.display = "block",
            b = Mt(h),
            x ? h.style.display = x : h.style.removeProperty("display")),
            m = tb(w[0], b[n.d]),
            y = tb(w[1] || "0", r),
            e = b[n.p] - l[n.p] - c + m + i - y,
            a && X(a, y, n, r - y < 20 || a._isStart && 20 < y),
            r -= r - y
        }
        if (o) {
            var S = e + r
              , _ = o._isStart;
            p = "scroll" + n.d2,
            X(o, S, n, _ && 20 < S || !_ && (u ? Math.max(Ge[p], qe[p]) : o.parentNode[p]) <= S + 1),
            u && (l = Mt(a),
            u && (o.style[n.op.p] = l[n.op.p] - n.op.m - o._offset + kt))
        }
        return d && h && (p = Mt(h),
        d.seek(f),
        g = Mt(h),
        d._caScrollDist = p[n.p] - g[n.p],
        e = e / d._caScrollDist * f),
        d && d.seek(v),
        d ? e : Math.round(e)
    }
    function fc(e, t, r, n) {
        if (e.parentNode !== t) {
            var i, o, a = e.style;
            if (t === Ge) {
                for (i in e._stOrig = a.cssText,
                o = db(e))
                    +i || ie.test(i) || !o[i] || "string" != typeof a[i] || "0" === i || (a[i] = o[i]);
                a.top = r,
                a.left = n
            } else
                a.cssText = e._stOrig;
            We.core.getCache(e).uncache = 1,
            t.appendChild(e)
        }
    }
    function gc(l, e) {
        function Qj(e, t, r, n, i) {
            var o = Qj.tween
              , a = t.onComplete
              , s = {};
            return r = r || f(),
            i = n && i || 0,
            n = n || e - r,
            o && o.kill(),
            c = Math.round(r),
            t[d] = e,
            (t.modifiers = s)[d] = function(e) {
                return (e = ya(f())) !== c && e !== u && 2 < Math.abs(e - c) && 2 < Math.abs(e - u) ? (o.kill(),
                Qj.tween = 0) : e = r + n * o.ratio + i * o.ratio * o.ratio,
                u = c,
                c = ya(e)
            }
            ,
            t.onComplete = function() {
                Qj.tween = 0,
                a && a.call(o)
            }
            ,
            o = Qj.tween = We.to(l, t)
        }
        var c, u, f = J(l, e), d = "_scroll" + e.p2;
        return (l[d] = f).wheelHandler = function() {
            return Qj.tween && Qj.tween.kill() && (Qj.tween = 0)
        }
        ,
        nb(l, "wheel", f.wheelHandler),
        Qj
    }
    var We, a, je, Je, qe, Ge, s, l, Ke, et, tt, c, rt, nt, u, it, f, d, p, ot, at, g, h, v, b, m, C, st, x, lt, w, ct, ut, ft = 1, dt = Date.now, S = dt(), pt = 0, gt = 0, ht = Math.abs, _ = "right", P = "bottom", vt = "width", bt = "height", mt = "Right", yt = "Left", xt = "Top", wt = "Bottom", St = "padding", _t = "margin", Tt = "Width", D = "Height", kt = "px", Mt = function _getBounds(e, t) {
        var r = t && "matrix(1, 0, 0, 1, 0, 0)" !== db(e)[u] && We.to(e, {
            x: 0,
            y: 0,
            xPercent: 0,
            yPercent: 0,
            rotation: 0,
            rotationX: 0,
            rotationY: 0,
            scale: 1,
            skewX: 0,
            skewY: 0
        }).progress(1)
          , n = e.getBoundingClientRect();
        return r && r.progress(0).kill(),
        n
    }, At = {
        startColor: "green",
        endColor: "red",
        indent: 0,
        fontSize: "16px",
        fontWeight: "normal"
    }, Ct = {
        toggleActions: "play",
        anticipatePin: 0
    }, Y = {
        top: 0,
        left: 0,
        center: .5,
        bottom: 1,
        right: 1
    }, X = function _positionMarker(e, t, r, n) {
        var i = {
            display: "block"
        }
          , o = r[n ? "os2" : "p2"]
          , a = r[n ? "p2" : "os2"];
        e._isFlipped = n,
        i[r.a + "Percent"] = n ? -100 : 0,
        i[r.a] = n ? "1px" : 0,
        i["border" + o + Tt] = 1,
        i["border" + a + Tt] = 0,
        i[r.p] = t + "px",
        We.set(e, i)
    }, Ot = [], Pt = {}, H = {}, R = [], U = [], V = function _dispatch(e) {
        return H[e] && H[e].map(function(e) {
            return e()
        }) || R
    }, W = [], j = function _revertRecorded(e) {
        for (var t = 0; t < W.length; t += 5)
            e && W[t + 4] !== e || (W[t].style.cssText = W[t + 1],
            W[t].getBBox && W[t].setAttribute("transform", W[t + 2] || ""),
            W[t + 3].uncache = 1)
    }, Q = function _revertAll(e, t) {
        var r;
        for (it = 0; it < Ot.length; it++)
            r = Ot[it],
            t && r.media !== t || (e ? r.kill(1) : r.revert());
        t && j(t),
        t || V("revert")
    }, G = 0, Z = function _refreshAll(e, t) {
        if (!pt || e) {
            ct = !0;
            var r = V("refreshInit");
            ot && oe.sort(),
            t || Q(),
            Ot.slice(0).forEach(function(e) {
                return e.refresh()
            }),
            Ot.forEach(function(e) {
                return "max" === e.vars.end && e.setPositions(e.start, Fa(e.scroller, e._dir))
            }),
            r.forEach(function(e) {
                return e && e.render && e.render(-1)
            }),
            Ob(),
            l.pause(),
            G++,
            ct = !1,
            V("refresh")
        } else
            nb(oe, "scrollEnd", Jb)
    }, $ = 0, Et = 1, ee = function _updateAll() {
        if (!ct) {
            oe.isUpdating = !0,
            ut && ut.update(0);
            var e = Ot.length
              , t = dt()
              , r = 50 <= t - S
              , n = e && Ot[0].scroll();
            if (Et = n < $ ? -1 : 1,
            $ = n,
            r && (pt && !nt && 200 < t - pt && (pt = 0,
            V("scrollEnd")),
            tt = S,
            S = t),
            Et < 0) {
                for (it = e; 0 < it--; )
                    Ot[it] && Ot[it].update(0, r);
                Et = 1
            } else
                for (it = 0; it < e; it++)
                    Ot[it] && Ot[it].update(0, r);
            oe.isUpdating = !1
        }
        x = 0
    }, te = ["left", "top", P, _, _t + wt, _t + mt, _t + xt, _t + yt, "display", "flexShrink", "float", "zIndex", "gridColumnStart", "gridColumnEnd", "gridRowStart", "gridRowEnd", "gridArea", "justifySelf", "alignSelf", "placeSelf", "order"], re = te.concat([vt, bt, "boxSizing", "max" + Tt, "max" + D, "position", _t, St, St + xt, St + mt, St + wt, St + yt]), ne = /([A-Z])/g, It = function _setState(e) {
        if (e) {
            var t, r, n = e.t.style, i = e.length, o = 0;
            for ((e.t._gsap || We.core.getCache(e.t)).uncache = 1; o < i; o += 2)
                r = e[o + 1],
                t = e[o],
                r ? n[t] = r : n[t] && n.removeProperty(t.replace(ne, "-$1").toLowerCase())
        }
    }, Bt = {
        left: 0,
        top: 0
    }, ie = /(webkit|moz|length|cssText|inset)/i, oe = (ScrollTrigger.prototype.init = function init(_, T) {
        if (this.progress = this.start = 0,
        this.vars && this.kill(!0, !0),
        gt) {
            var k, n, p, M, A, C, O, P, E, B, D, e, z, Y, X, F, L, t, H, b, R, N, m, U, x, w, r, S, V, W, i, g, j, Q, q, G, K, o, Z = (_ = fb(Ha(_) || Ja(_) || _.nodeType ? {
                trigger: _
            } : _, Ct)).onUpdate, $ = _.toggleClass, a = _.id, ee = _.onToggle, te = _.onRefresh, re = _.scrub, ne = _.trigger, ie = _.pin, oe = _.pinSpacing, ae = _.invalidateOnRefresh, se = _.anticipatePin, s = _.onScrubComplete, h = _.onSnapComplete, le = _.once, ce = _.snap, ue = _.pinReparent, l = _.pinSpacer, fe = _.containerAnimation, de = _.fastScrollEnd, pe = _.preventOverlaps, ge = _.horizontal || _.containerAnimation && !1 !== _.horizontal ? Re : Ne, he = !re && 0 !== re, ve = I(_.scroller || je), c = We.core.getCache(ve), be = Ba(ve), me = "fixed" === ("pinType"in _ ? _.pinType : y(ve, "pinType") || be && "fixed"), ye = [_.onEnter, _.onLeave, _.onEnterBack, _.onLeaveBack], xe = he && _.toggleActions.split(" "), u = "markers"in _ ? _.markers : Ct.markers, we = be ? 0 : parseFloat(db(ve)["border" + ge.p2 + Tt]) || 0, Se = this, _e = _.onRefreshInit && function() {
                return _.onRefreshInit(Se)
            }
            , Te = function _getSizeFunc(e, t, r) {
                var n = r.d
                  , i = r.d2
                  , o = r.a;
                return (o = y(e, "getBoundingClientRect")) ? function() {
                    return o()[n]
                }
                : function() {
                    return (t ? je["inner" + i] : e["client" + i]) || 0
                }
            }(ve, be, ge), ke = function _getOffsetsFunc(e, t) {
                return !t || ~Le.indexOf(e) ? Ca(e) : function() {
                    return Bt
                }
            }(ve, be), Me = 0, Ae = 0, Ce = J(ve, ge);
            if (Se.media = lt,
            Se._dir = ge,
            se *= 45,
            Se.scroller = ve,
            Se.scroll = fe ? fe.time.bind(fe) : Ce,
            M = Ce(),
            Se.vars = _,
            T = T || _.animation,
            "refreshPriority"in _ && (ot = 1,
            -9999 === _.refreshPriority && (ut = Se)),
            c.tweenScroll = c.tweenScroll || {
                top: gc(ve, Ne),
                left: gc(ve, Re)
            },
            Se.tweenTo = k = c.tweenScroll[ge.p],
            Se.scrubDuration = function(e) {
                (i = Ja(e) && e) ? W ? W.duration(e) : W = We.to(T, {
                    ease: "expo",
                    totalProgress: "+=0.001",
                    duration: i,
                    paused: !0,
                    onComplete: function onComplete() {
                        return s && s(Se)
                    }
                }) : (W && W.progress(1).kill(),
                W = 0)
            }
            ,
            T && (T.vars.lazy = !1,
            T._initted || !1 !== T.vars.immediateRender && !1 !== _.immediateRender && T.render(0, !0, !0),
            Se.animation = T.pause(),
            (T.scrollTrigger = Se).scrubDuration(re),
            S = 0,
            a = a || T.vars.id),
            Ot.push(Se),
            ce && (Ka(ce) && !ce.push || (ce = {
                snapTo: ce
            }),
            "scrollBehavior"in Ge.style && We.set(be ? [Ge, qe] : ve, {
                scrollBehavior: "auto"
            }),
            p = Ia(ce.snapTo) ? ce.snapTo : "labels" === ce.snapTo ? function _getClosestLabel(t) {
                return function(e) {
                    return We.utils.snap(ib(t), e)
                }
            }(T) : "labelsDirectional" === ce.snapTo ? function _getLabelAtDirection(r) {
                return function(e, t) {
                    return kb(ib(r))(e, t.direction)
                }
            }(T) : !1 !== ce.directional ? function(e, t) {
                return kb(ce.snapTo)(e, dt() - Ae < 500 ? 0 : t.direction)
            }
            : We.utils.snap(ce.snapTo),
            g = ce.duration || {
                min: .1,
                max: 2
            },
            g = Ka(g) ? et(g.min, g.max) : et(g, g),
            j = We.delayedCall(ce.delay || i / 2 || .1, function() {
                var e = Ce()
                  , t = dt() - Ae < 500
                  , r = k.tween;
                if (!(t || Math.abs(Se.getVelocity()) < 10) || r || nt || Me === e)
                    Se.isActive && Me !== e && j.restart(!0);
                else {
                    var n = (e - C) / z
                      , i = T && !he ? T.totalProgress() : n
                      , o = t ? 0 : (i - V) / (dt() - tt) * 1e3 || 0
                      , a = We.utils.clamp(-n, 1 - n, ht(o / 2) * o / .185)
                      , s = n + (!1 === ce.inertia ? 0 : a)
                      , l = et(0, 1, p(s, Se))
                      , c = Math.round(C + l * z)
                      , u = ce.onStart
                      , f = ce.onInterrupt
                      , d = ce.onComplete;
                    if (e <= O && C <= e && c !== e) {
                        if (r && !r._initted && r.data <= ht(c - e))
                            return;
                        !1 === ce.inertia && (a = l - n),
                        k(c, {
                            duration: g(ht(.185 * Math.max(ht(s - i), ht(l - i)) / o / .05 || 0)),
                            ease: ce.ease || "power3",
                            data: ht(c - e),
                            onInterrupt: function onInterrupt() {
                                return j.restart(!0) && f && f(Se)
                            },
                            onComplete: function onComplete() {
                                Se.update(),
                                Me = Ce(),
                                S = V = T && !he ? T.totalProgress() : Se.progress,
                                h && h(Se),
                                d && d(Se)
                            }
                        }, e, a * z, c - e - a * z),
                        u && u(Se, k.tween)
                    }
                }
            }).pause()),
            a && (Pt[a] = Se),
            o = (o = (ne = Se.trigger = I(ne || ie)) && ne._gsap && ne._gsap.stRevert) && o(Se),
            ie = !0 === ie ? ne : I(ie),
            Ha($) && ($ = {
                targets: ne,
                className: $
            }),
            ie && (!1 === oe || oe === _t || (oe = !(!oe && "flex" === db(ie.parentNode).display) && St),
            Se.pin = ie,
            !1 !== _.force3D && We.set(ie, {
                force3D: !0
            }),
            (n = We.core.getCache(ie)).spacer ? Y = n.pinState : (l && ((l = I(l)) && !l.nodeType && (l = l.current || l.nativeElement),
            n.spacerIsNative = !!l,
            l && (n.spacerState = ac(l))),
            n.spacer = L = l || Je.createElement("div"),
            L.classList.add("pin-spacer"),
            a && L.classList.add("pin-spacer-" + a),
            n.pinState = Y = ac(ie)),
            Se.spacer = L = n.spacer,
            r = db(ie),
            m = r[oe + ge.os2],
            H = We.getProperty(ie),
            b = We.quickSetter(ie, ge.a, kt),
            Zb(ie, L, r),
            F = ac(ie)),
            u) {
                e = Ka(u) ? fb(u, At) : At,
                B = ub("scroller-start", a, ve, ge, e, 0),
                D = ub("scroller-end", a, ve, ge, e, 0, B),
                t = B["offset" + ge.op.d2];
                var f = I(y(ve, "content") || ve);
                P = this.markerStart = ub("start", a, f, ge, e, t, 0, fe),
                E = this.markerEnd = ub("end", a, f, ge, e, t, 0, fe),
                fe && (K = We.quickSetter([P, E], ge.a, kt)),
                me || Le.length && !0 === y(ve, "fixedMarkers") || (function _makePositionable(e) {
                    var t = db(e).position;
                    e.style.position = "absolute" === t || "fixed" === t ? t : "relative"
                }(be ? Ge : ve),
                We.set([B, D], {
                    force3D: !0
                }),
                x = We.quickSetter(B, ge.a, kt),
                w = We.quickSetter(D, ge.a, kt))
            }
            if (fe) {
                var d = fe.vars.onUpdate
                  , v = fe.vars.onUpdateParams;
                fe.eventCallback("onUpdate", function() {
                    Se.update(0, 0, 1),
                    d && d.apply(v || [])
                })
            }
            Se.previous = function() {
                return Ot[Ot.indexOf(Se) - 1]
            }
            ,
            Se.next = function() {
                return Ot[Ot.indexOf(Se) + 1]
            }
            ,
            Se.revert = function(e) {
                var t = !1 !== e || !Se.enabled
                  , r = rt;
                t !== Se.isReverted && (t && (!Se.scroll.rec && rt && ct && (Se.scroll.rec = Ce()),
                q = Math.max(Ce(), Se.scroll.rec || 0),
                Q = Se.progress,
                G = T && T.progress()),
                P && [P, E, B, D].forEach(function(e) {
                    return e.style.display = t ? "none" : "block"
                }),
                t && (rt = 1),
                Se.update(t),
                rt = r,
                ie && (t ? function _swapPinOut(e, t, r) {
                    It(r);
                    var n = e._gsap;
                    if (n.spacerIsNative)
                        It(n.spacerState);
                    else if (e.parentNode === t) {
                        var i = t.parentNode;
                        i && (i.insertBefore(e, t),
                        i.removeChild(t))
                    }
                }(ie, L, Y) : ue && Se.isActive || Zb(ie, L, db(ie), U)),
                Se.isReverted = t)
            }
            ,
            Se.refresh = function(e, t) {
                if (!rt && Se.enabled || t)
                    if (ie && e && pt)
                        nb(ScrollTrigger, "scrollEnd", Jb);
                    else {
                        !ct && _e && _e(Se),
                        rt = 1,
                        Ae = dt(),
                        k.tween && (k.tween.kill(),
                        k.tween = 0),
                        W && W.pause(),
                        ae && T && T.time(-.01, !0).invalidate(),
                        Se.isReverted || Se.revert();
                        for (var r, n, i, o, a, s, l, c, u, f, d = Te(), p = ke(), g = fe ? fe.duration() : Fa(ve, ge), h = 0, v = 0, b = _.end, m = _.endTrigger || ne, y = _.start || (0 !== _.start && ne ? ie ? "0 0" : "0 100%" : 0), x = Se.pinnedContainer = _.pinnedContainer && I(_.pinnedContainer), w = ne && Math.max(0, Ot.indexOf(Se)) || 0, S = w; S--; )
                            (s = Ot[S]).end || s.refresh(0, 1) || (rt = 1),
                            !(l = s.pin) || l !== ne && l !== ie || s.isReverted || ((f = f || []).unshift(s),
                            s.revert()),
                            s !== Ot[S] && (w--,
                            S--);
                        for (Ia(y) && (y = y(Se)),
                        C = dc(y, ne, d, ge, Ce(), P, B, Se, p, we, me, g, fe) || (ie ? -.001 : 0),
                        Ia(b) && (b = b(Se)),
                        Ha(b) && !b.indexOf("+=") && (~b.indexOf(" ") ? b = (Ha(y) ? y.split(" ")[0] : "") + b : (h = tb(b.substr(2), d),
                        b = Ha(y) ? y : C + h,
                        m = ne)),
                        O = Math.max(C, dc(b || (m ? "100% 0" : g), m, d, ge, Ce() + h, E, D, Se, p, we, me, g, fe)) || -.001,
                        z = O - C || (C -= .01) && .001,
                        h = 0,
                        S = w; S--; )
                            (l = (s = Ot[S]).pin) && s.start - s._pinPush < C && !fe && 0 < s.end && (r = s.end - s.start,
                            l !== ne && l !== x || Ja(y) || (h += r * (1 - s.progress)),
                            l === ie && (v += r));
                        if (C += h,
                        O += h,
                        Se._pinPush = v,
                        P && h && ((r = {})[ge.a] = "+=" + h,
                        x && (r[ge.p] = "-=" + Ce()),
                        We.set([P, E], r)),
                        ie)
                            r = db(ie),
                            o = ge === Ne,
                            i = Ce(),
                            R = parseFloat(H(ge.a)) + v,
                            !g && 1 < O && ((be ? Ge : ve).style["overflow-" + ge.a] = "scroll"),
                            Zb(ie, L, r),
                            F = ac(ie),
                            n = Mt(ie, !0),
                            c = me && J(ve, o ? Re : Ne)(),
                            oe && ((U = [oe + ge.os2, z + v + kt]).t = L,
                            (S = oe === St ? hb(ie, ge) + z + v : 0) && U.push(ge.d, S + kt),
                            It(U),
                            me && Ce(q)),
                            me && ((a = {
                                top: n.top + (o ? i - C : c) + kt,
                                left: n.left + (o ? c : i - C) + kt,
                                boxSizing: "border-box",
                                position: "fixed"
                            })[vt] = a.maxWidth = Math.ceil(n.width) + kt,
                            a[bt] = a.maxHeight = Math.ceil(n.height) + kt,
                            a[_t] = a[_t + xt] = a[_t + mt] = a[_t + wt] = a[_t + yt] = "0",
                            a[St] = r[St],
                            a[St + xt] = r[St + xt],
                            a[St + mt] = r[St + mt],
                            a[St + wt] = r[St + wt],
                            a[St + yt] = r[St + yt],
                            X = function _copyState(e, t, r) {
                                for (var n, i = [], o = e.length, a = r ? 8 : 0; a < o; a += 2)
                                    n = e[a],
                                    i.push(n, n in t ? t[n] : e[a + 1]);
                                return i.t = e.t,
                                i
                            }(Y, a, ue)),
                            T ? (u = T._initted,
                            at(1),
                            T.render(T.duration(), !0, !0),
                            N = H(ge.a) - R + z + v,
                            z !== N && me && X.splice(X.length - 2, 2),
                            T.render(0, !0, !0),
                            u || T.invalidate(),
                            at(0)) : N = z;
                        else if (ne && Ce() && !fe)
                            for (n = ne.parentNode; n && n !== Ge; )
                                n._pinOffset && (C -= n._pinOffset,
                                O -= n._pinOffset),
                                n = n.parentNode;
                        f && f.forEach(function(e) {
                            return e.revert(!1)
                        }),
                        Se.start = C,
                        Se.end = O,
                        M = A = Ce(),
                        fe || (M < q && Ce(q),
                        Se.scroll.rec = 0),
                        Se.revert(!1),
                        j && (Me = -1,
                        Se.isActive && Ce(C + z * Q),
                        j.restart(!0)),
                        rt = 0,
                        T && he && (T._initted || G) && T.progress() !== G && T.progress(G, !0).render(T.time(), !0, !0),
                        Q === Se.progress && !fe || (T && !he && T.totalProgress(Q, !0),
                        Se.progress = Q,
                        Se.update(0, 0, 1)),
                        ie && oe && (L._pinOffset = Math.round(Se.progress * N)),
                        te && te(Se)
                    }
            }
            ,
            Se.getVelocity = function() {
                return (Ce() - A) / (dt() - tt) * 1e3 || 0
            }
            ,
            Se.endAnimation = function() {
                Na(Se.callbackAnimation),
                T && (W ? W.progress(1) : T.paused() ? he || Na(T, Se.direction < 0, 1) : Na(T, T.reversed()))
            }
            ,
            Se.labelToScroll = function(e) {
                return T && T.labels && (C || Se.refresh() || C) + T.labels[e] / T.duration() * z || 0
            }
            ,
            Se.getTrailing = function(t) {
                var e = Ot.indexOf(Se)
                  , r = 0 < Se.direction ? Ot.slice(0, e).reverse() : Ot.slice(e + 1);
                return (Ha(t) ? r.filter(function(e) {
                    return e.vars.preventOverlaps === t
                }) : r).filter(function(e) {
                    return 0 < Se.direction ? e.end <= C : e.start >= O
                })
            }
            ,
            Se.update = function(e, t, r) {
                if (!fe || r || e) {
                    var n, i, o, a, s, l, c, u = Se.scroll(), f = e ? 0 : (u - C) / z, d = f < 0 ? 0 : 1 < f ? 1 : f || 0, p = Se.progress;
                    if (t && (A = M,
                    M = fe ? Ce() : u,
                    ce && (V = S,
                    S = T && !he ? T.totalProgress() : d)),
                    se && !d && ie && !rt && !ft && pt && C < u + (u - A) / (dt() - tt) * se && (d = 1e-4),
                    d !== p && Se.enabled) {
                        if (a = (s = (n = Se.isActive = !!d && d < 1) != (!!p && p < 1)) || !!d != !!p,
                        Se.direction = p < d ? 1 : -1,
                        Se.progress = d,
                        a && !rt && (i = d && !p ? 0 : 1 === d ? 1 : 1 === p ? 2 : 3,
                        he && (o = !s && "none" !== xe[i + 1] && xe[i + 1] || xe[i],
                        c = T && ("complete" === o || "reset" === o || o in T))),
                        pe && (s || c) && (c || re || !T) && (Ia(pe) ? pe(Se) : Se.getTrailing(pe).forEach(function(e) {
                            return e.endAnimation()
                        })),
                        he || (!W || rt || ft ? T && T.totalProgress(d, !!rt) : ((fe || ut && ut !== Se) && W.render(W._dp._time - W._start),
                        W.resetTo ? W.resetTo("totalProgress", d, T._tTime / T._tDur) : (W.vars.totalProgress = d,
                        W.invalidate().restart()))),
                        ie)
                            if (e && oe && (L.style[oe + ge.os2] = m),
                            me) {
                                if (a) {
                                    if (l = !e && p < d && u < O + 1 && u + 1 >= Fa(ve, ge),
                                    ue)
                                        if (e || !n && !l)
                                            fc(ie, L);
                                        else {
                                            var g = Mt(ie, !0)
                                              , h = u - C;
                                            fc(ie, Ge, g.top + (ge === Ne ? h : 0) + kt, g.left + (ge === Ne ? 0 : h) + kt)
                                        }
                                    It(n || l ? X : F),
                                    N !== z && d < 1 && n || b(R + (1 !== d || l ? 0 : N))
                                }
                            } else
                                b(ya(R + N * d));
                        !ce || k.tween || rt || ft || j.restart(!0),
                        $ && (s || le && d && (d < 1 || !st)) && Ke($.targets).forEach(function(e) {
                            return e.classList[n || le ? "add" : "remove"]($.className)
                        }),
                        !Z || he || e || Z(Se),
                        a && !rt ? (he && (c && ("complete" === o ? T.pause().totalProgress(1) : "reset" === o ? T.restart(!0).pause() : "restart" === o ? T.restart(!0) : T[o]()),
                        Z && Z(Se)),
                        !s && st || (ee && s && Oa(Se, ee),
                        ye[i] && Oa(Se, ye[i]),
                        le && (1 === d ? Se.kill(!1, 1) : ye[i] = 0),
                        s || ye[i = 1 === d ? 1 : 3] && Oa(Se, ye[i])),
                        de && !n && Math.abs(Se.getVelocity()) > (Ja(de) ? de : 2500) && (Na(Se.callbackAnimation),
                        W ? W.progress(1) : Na(T, !d, 1))) : he && Z && !rt && Z(Se)
                    }
                    if (w) {
                        var v = fe ? u / fe.duration() * (fe._caScrollDist || 0) : u;
                        x(v + (B._isFlipped ? 1 : 0)),
                        w(v)
                    }
                    K && K(-u / fe.duration() * (fe._caScrollDist || 0))
                }
            }
            ,
            Se.enable = function(e, t) {
                Se.enabled || (Se.enabled = !0,
                nb(ve, "resize", Cb),
                nb(be ? Je : ve, "scroll", Ab),
                _e && nb(ScrollTrigger, "refreshInit", _e),
                !1 !== e && (Se.progress = Q = 0,
                M = A = Me = Ce()),
                !1 !== t && Se.refresh())
            }
            ,
            Se.getTween = function(e) {
                return e && k ? k.tween : W
            }
            ,
            Se.setPositions = function(e, t) {
                ie && (R += e - C,
                N += t - e - z),
                Se.start = C = e,
                Se.end = O = t,
                z = t - e,
                Se.update()
            }
            ,
            Se.disable = function(e, t) {
                if (Se.enabled && (!1 !== e && Se.revert(),
                Se.enabled = Se.isActive = !1,
                t || W && W.pause(),
                q = 0,
                n && (n.uncache = 1),
                _e && ob(ScrollTrigger, "refreshInit", _e),
                j && (j.pause(),
                k.tween && k.tween.kill() && (k.tween = 0)),
                !be)) {
                    for (var r = Ot.length; r--; )
                        if (Ot[r].scroller === ve && Ot[r] !== Se)
                            return;
                    ob(ve, "resize", Cb),
                    ob(ve, "scroll", Ab)
                }
            }
            ,
            Se.kill = function(e, t) {
                Se.disable(e, t),
                W && !t && W.kill(),
                a && delete Pt[a];
                var r = Ot.indexOf(Se);
                0 <= r && Ot.splice(r, 1),
                r === it && 0 < Et && it--,
                r = 0,
                Ot.forEach(function(e) {
                    return e.scroller === Se.scroller && (r = 1)
                }),
                r || (Se.scroll.rec = 0),
                T && (T.scrollTrigger = null,
                e && T.render(-1),
                t || T.kill()),
                P && [P, E, B, D].forEach(function(e) {
                    return e.parentNode && e.parentNode.removeChild(e)
                }),
                ut === Se && (ut = 0),
                ie && (n && (n.uncache = 1),
                r = 0,
                Ot.forEach(function(e) {
                    return e.pin === ie && r++
                }),
                r || (n.spacer = 0)),
                _.onKill && _.onKill(Se)
            }
            ,
            Se.enable(!1, !1),
            o && o(Se),
            T && T.add && !z ? We.delayedCall(.01, function() {
                return C || O || Se.refresh()
            }) && (z = .01) && (C = O = 0) : Se.refresh()
        } else
            this.update = this.refresh = this.kill = xa
    }
    ,
    ScrollTrigger.register = function register(e) {
        return a || (We = e || Aa(),
        za() && window.document && ScrollTrigger.enable(),
        a = gt),
        a
    }
    ,
    ScrollTrigger.defaults = function defaults(e) {
        if (e)
            for (var t in e)
                Ct[t] = e[t];
        return Ct
    }
    ,
    ScrollTrigger.disable = function disable(t, r) {
        gt = 0,
        Ot.forEach(function(e) {
            return e[r ? "kill" : "disable"](t)
        }),
        ob(je, "wheel", Ab),
        ob(Je, "scroll", Ab),
        clearInterval(c),
        ob(Je, "touchcancel", xa),
        ob(Ge, "touchstart", xa),
        mb(ob, Je, "pointerdown,touchstart,mousedown", va),
        mb(ob, Je, "pointerup,touchend,mouseup", wa),
        l.kill(),
        Ga(ob);
        for (var e = 0; e < T.length; e += 3)
            pb(ob, T[e], T[e + 1]),
            pb(ob, T[e], T[e + 2])
    }
    ,
    ScrollTrigger.enable = function enable() {
        if (je = window,
        Je = document,
        qe = Je.documentElement,
        Ge = Je.body,
        We && (Ke = We.utils.toArray,
        et = We.utils.clamp,
        at = We.core.suppressOverwrites || xa,
        We.core.globals("ScrollTrigger", ScrollTrigger),
        Ge)) {
            gt = 1,
            k.register(We),
            ScrollTrigger.isTouch = k.isTouch,
            C = k.isTouch && /(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent),
            nb(je, "wheel", Ab),
            s = [je, Je, qe, Ge],
            ScrollTrigger.matchMedia({
                "(orientation: portrait)": function orientationPortrait() {
                    return Bb(),
                    Bb
                }
            }),
            nb(Je, "scroll", Ab);
            var e, t, r = Ge.style, n = r.borderTopStyle;
            for (r.borderTopStyle = "solid",
            e = Mt(Ge),
            Ne.m = Math.round(e.top + Ne.sc()) || 0,
            Re.m = Math.round(e.left + Re.sc()) || 0,
            n ? r.borderTopStyle = n : r.removeProperty("border-top-style"),
            c = setInterval(zb, 250),
            We.delayedCall(.5, function() {
                return ft = 0
            }),
            nb(Je, "touchcancel", xa),
            nb(Ge, "touchstart", xa),
            mb(nb, Je, "pointerdown,touchstart,mousedown", va),
            mb(nb, Je, "pointerup,touchend,mouseup", wa),
            u = We.utils.checkPrefix("transform"),
            re.push(u),
            a = dt(),
            l = We.delayedCall(.2, Z).pause(),
            p = [Je, "visibilitychange", function() {
                var e = je.innerWidth
                  , t = je.innerHeight;
                Je.hidden ? (f = e,
                d = t) : f === e && d === t || Cb()
            }
            , Je, "DOMContentLoaded", Z, je, "load", Z, je, "resize", Cb],
            Ga(nb),
            Ot.forEach(function(e) {
                return e.enable(0, 1)
            }),
            t = 0; t < T.length; t += 3)
                pb(ob, T[t], T[t + 1]),
                pb(ob, T[t], T[t + 2])
        }
    }
    ,
    ScrollTrigger.config = function config(e) {
        "limitCallbacks"in e && (st = !!e.limitCallbacks);
        var t = e.syncInterval;
        t && clearInterval(c) || (c = t) && setInterval(zb, t),
        "ignoreMobileResize"in e && (v = 1 === ScrollTrigger.isTouch && e.ignoreMobileResize),
        "autoRefreshEvents"in e && (Ga(ob) || Ga(nb, e.autoRefreshEvents || "none"),
        g = -1 === (e.autoRefreshEvents + "").indexOf("resize"))
    }
    ,
    ScrollTrigger.scrollerProxy = function scrollerProxy(e, t) {
        var r = I(e)
          , n = T.indexOf(r)
          , i = Ba(r);
        ~n && T.splice(n, i ? 6 : 2),
        t && (i ? Le.unshift(je, t, Ge, t, qe, t) : Le.unshift(r, t))
    }
    ,
    ScrollTrigger.matchMedia = function matchMedia(e) {
        var t, r, n, i, o;
        for (r in e)
            n = U.indexOf(r),
            i = e[r],
            "all" === (lt = r) ? i() : (t = je.matchMedia(r)) && (t.matches && (o = i()),
            ~n ? (U[n + 1] = Ma(U[n + 1], i),
            U[n + 2] = Ma(U[n + 2], o)) : (n = U.length,
            U.push(r, i, o),
            t.addListener ? t.addListener(Ib) : t.addEventListener("change", Ib)),
            U[n + 3] = t.matches),
            lt = 0;
        return U
    }
    ,
    ScrollTrigger.clearMatchMedia = function clearMatchMedia(e) {
        e || (U.length = 0),
        0 <= (e = U.indexOf(e)) && U.splice(e, 4)
    }
    ,
    ScrollTrigger.isInViewport = function isInViewport(e, t, r) {
        var n = (Ha(e) ? I(e) : e).getBoundingClientRect()
          , i = n[r ? vt : bt] * t || 0;
        return r ? 0 < n.right - i && n.left + i < je.innerWidth : 0 < n.bottom - i && n.top + i < je.innerHeight
    }
    ,
    ScrollTrigger.positionInViewport = function positionInViewport(e, t, r) {
        Ha(e) && (e = I(e));
        var n = e.getBoundingClientRect()
          , i = n[r ? vt : bt]
          , o = null == t ? i / 2 : t in Y ? Y[t] * i : ~t.indexOf("%") ? parseFloat(t) * i / 100 : parseFloat(t) || 0;
        return r ? (n.left + o) / je.innerWidth : (n.top + o) / je.innerHeight
    }
    ,
    ScrollTrigger);
    function ScrollTrigger(e, t) {
        a || ScrollTrigger.register(We) || console.warn("Please gsap.registerPlugin(ScrollTrigger)"),
        this.init(e, t)
    }
    oe.version = "3.10.4",
    oe.saveStyles = function(e) {
        return e ? Ke(e).forEach(function(e) {
            if (e && e.style) {
                var t = W.indexOf(e);
                0 <= t && W.splice(t, 5),
                W.push(e, e.style.cssText, e.getBBox && e.getAttribute("transform"), We.core.getCache(e), lt)
            }
        }) : W
    }
    ,
    oe.revert = function(e, t) {
        return Q(!e, t)
    }
    ,
    oe.create = function(e, t) {
        return new oe(e,t)
    }
    ,
    oe.refresh = function(e) {
        return e ? Cb() : (a || oe.register()) && Z(!0)
    }
    ,
    oe.update = ee,
    oe.clearScrollMemory = Ob,
    oe.maxScroll = function(e, t) {
        return Fa(e, t ? Re : Ne)
    }
    ,
    oe.getScrollFunc = function(e, t) {
        return J(I(e), t ? Re : Ne)
    }
    ,
    oe.getById = function(e) {
        return Pt[e]
    }
    ,
    oe.getAll = function() {
        return Ot.filter(function(e) {
            return "ScrollSmoother" !== e.vars.id
        })
    }
    ,
    oe.isScrolling = function() {
        return !!pt
    }
    ,
    oe.snapDirectional = kb,
    oe.addEventListener = function(e, t) {
        var r = H[e] || (H[e] = []);
        ~r.indexOf(t) || r.push(t)
    }
    ,
    oe.removeEventListener = function(e, t) {
        var r = H[e]
          , n = r && r.indexOf(t);
        0 <= n && r.splice(n, 1)
    }
    ,
    oe.batch = function(e, t) {
        function to(e, t) {
            var r = []
              , n = []
              , i = We.delayedCall(o, function() {
                t(r, n),
                r = [],
                n = []
            }).pause();
            return function(e) {
                r.length || i.restart(!0),
                r.push(e.trigger),
                n.push(e),
                a <= r.length && i.progress(1)
            }
        }
        var r, n = [], i = {}, o = t.interval || .016, a = t.batchMax || 1e9;
        for (r in t)
            i[r] = "on" === r.substr(0, 2) && Ia(t[r]) && "onRefreshInit" !== r ? to(0, t[r]) : t[r];
        return Ia(a) && (a = a(),
        nb(oe, "refresh", function() {
            return a = t.batchMax()
        })),
        Ke(e).forEach(function(e) {
            var t = {};
            for (r in i)
                t[r] = i[r];
            t.trigger = e,
            n.push(oe.create(t))
        }),
        n
    }
    ;
    function ic(e, t, r, n) {
        return n < t ? e(n) : t < 0 && e(0),
        n < r ? (n - t) / (r - t) : r < 0 ? t / (t - r) : 1
    }
    function jc(e, t) {
        !0 === t ? e.style.removeProperty("touch-action") : e.style.touchAction = !0 === t ? "auto" : t ? "pan-" + t + (k.isTouch ? " pinch-zoom" : "") : "none",
        e === qe && jc(Ge, t)
    }
    function lc(e) {
        var t, r = e.event, n = e.target, i = e.axis, o = (r.changedTouches ? r.changedTouches[0] : r).target, a = o._gsap || We.core.getCache(o), s = dt();
        if (!a._isScrollT || 2e3 < s - a._isScrollT) {
            for (; o && o.scrollHeight <= o.clientHeight; )
                o = o.parentNode;
            a._isScroll = o && !Ba(o) && o !== n && (se[(t = db(o)).overflowY] || se[t.overflowX]),
            a._isScrollT = s
        }
        !a._isScroll && "x" !== i || (r._gsapAllow = !0)
    }
    function mc(e, t, r, n) {
        return k.create({
            target: e,
            capture: !0,
            debounce: !1,
            lockAxis: !0,
            type: t,
            onWheel: n = n && lc,
            onPress: n,
            onDrag: n,
            onScroll: n,
            onEnable: function onEnable() {
                return r && nb(Je, k.eventTypes[0], ce, !1, !0)
            },
            onDisable: function onDisable() {
                return ob(Je, k.eventTypes[0], ce, !0)
            }
        })
    }
    function qc(e) {
        function op() {
            return n = !1
        }
        function rp() {
            o = Fa(d, Ne),
            _ = et(C ? 1 : 0, o),
            f && (S = et(0, Fa(d, Re))),
            a = G
        }
        function xp() {
            rp(),
            s.isActive() && s.vars.scrollY > o && (h() > o ? s.progress(1) && h(o) : s.resetTo("scrollY", o))
        }
        Ka(e) || (e = {}),
        e.preventDefault = e.isNormalizer = e.allowClicks = !0,
        e.type || (e.type = "wheel,touch"),
        e.debounce = !!e.debounce,
        e.id = e.id || "normalizer";
        var r, o, n, a, s, l, c, u, f = e.normalizeScrollX, t = e.momentum, i = e.allowNestedScroll, d = I(e.target) || qe, p = We.core.globals().ScrollSmoother, g = C && (e.content && I(e.content) || p && p.get() && p.get().content()), h = J(d, Ne), v = J(d, Re), b = 1, m = (k.isTouch && je.visualViewport ? je.visualViewport.scale * je.visualViewport.width : je.outerWidth) / je.innerWidth, y = 0, x = Ia(t) ? function() {
            return t(r)
        }
        : function() {
            return t || 2.8
        }
        , w = mc(d, e.type, !0, i), S = xa, _ = xa;
        return e.ignoreCheck = function(e) {
            return C && "touchmove" === e.type && function ignoreDrag() {
                if (n) {
                    requestAnimationFrame(op);
                    var e = ya(r.deltaY / 2)
                      , t = _(h.v - e);
                    return g && t !== h.v + h.offset && (h.offset = t - h.v,
                    g.style.transform = "translateY(" + -h.offset + "px)",
                    g._gsap && (g._gsap.y = -h.offset + "px"),
                    h.cacheID = T.cache,
                    ee()),
                    !0
                }
                g && (g.style.transform = "translateY(0px)",
                h.offset = h.cacheID = 0,
                g._gsap && (g._gsap.y = "0px")),
                n = !0
            }() || 1.05 < b && "touchstart" !== e.type || r.isGesturing || e.touches && 1 < e.touches.length
        }
        ,
        e.onPress = function() {
            var e = b;
            b = ya((je.visualViewport && je.visualViewport.scale || 1) / m),
            s.pause(),
            e !== b && jc(d, 1.01 < b || !f && "x"),
            n = !1,
            l = v(),
            c = h(),
            rp(),
            a = G
        }
        ,
        e.onRelease = e.onGestureStart = function(e, t) {
            if (g && (g.style.transform = "translateY(0px)",
            h.offset = h.cacheID = 0,
            g._gsap && (g._gsap.y = "0px")),
            t) {
                T.cache++;
                var r, n, i = x();
                f && (n = (r = v()) + .05 * i * -e.velocityX / .227,
                i *= ic(v, r, n, Fa(d, Re)),
                s.vars.scrollX = S(n)),
                n = (r = h()) + .05 * i * -e.velocityY / .227,
                i *= ic(h, r, n, Fa(d, Ne)),
                s.vars.scrollY = _(n),
                s.invalidate().duration(i).play(.01),
                (C && s.vars.scrollY >= o || o - 1 <= r) && We.to({}, {
                    onUpdate: xp,
                    duration: i
                })
            } else
                u.restart(!0)
        }
        ,
        e.onWheel = function() {
            s._ts && s.pause(),
            1e3 < dt() - y && (a = 0,
            y = dt())
        }
        ,
        e.onChange = function(e, t, r, n, i) {
            G !== a && rp(),
            t && f && v(S(n[2] === t ? l + (e.startX - e.x) : v() + t - n[1])),
            r && h(_(i[2] === r ? c + (e.startY - e.y) : h() + r - i[1])),
            ee()
        }
        ,
        e.onEnable = function() {
            jc(d, !f && "x"),
            nb(je, "resize", xp),
            w.enable()
        }
        ,
        e.onDisable = function() {
            jc(d, !0),
            ob(je, "resize", xp),
            w.kill()
        }
        ,
        ((r = new k(e)).iOS = C) && !h() && h(1),
        u = r._dc,
        s = We.to(r, {
            ease: "power4",
            paused: !0,
            scrollX: f ? "+=0.1" : "+=0",
            scrollY: "+=0.1",
            onComplete: u.vars.onComplete
        }),
        r
    }
    var ae, se = {
        auto: 1,
        scroll: 1
    }, le = /(input|label|select|textarea)/i, ce = function _captureInputs(e) {
        var t = le.test(e.target.tagName);
        (t || ae) && (e._gsapAllow = !0,
        ae = t)
    };
    oe.sort = function(e) {
        return Ot.sort(e || function(e, t) {
            return -1e6 * (e.vars.refreshPriority || 0) + e.start - (t.start + -1e6 * (t.vars.refreshPriority || 0))
        }
        )
    }
    ,
    oe.observe = function(e) {
        return new k(e)
    }
    ,
    oe.normalizeScroll = function(e) {
        if (void 0 === e)
            return h;
        if (!0 === e && h)
            return h.enable();
        if (!1 === e)
            return h && h.kill();
        var t = e instanceof k ? e : qc(e);
        return h && h.target === t.target && h.kill(),
        Ba(t.target) && (h = t),
        t
    }
    ,
    oe.core = {
        _getVelocityProp: K,
        _inputObserver: mc,
        _scrollers: T,
        _proxies: Le,
        bridge: {
            ss: function ss() {
                pt || V("scrollStart"),
                pt = dt()
            },
            ref: function ref() {
                return rt
            }
        }
    },
    Aa() && We.registerPlugin(oe),
    e.ScrollTrigger = oe,
    e.default = oe;
    if (typeof (window) === "undefined" || window !== e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        })
    } else {
        delete e.default
    }
});
/**
 * Swiper 5.3.6
 * Most modern mobile touch slider and framework with hardware accelerated transitions
 * http://swiperjs.com
 *
 * Copyright 2014-2020 Vladimir Kharlampidi
 *
 * Released under the MIT License
 *
 * Released on: February 29, 2020
 */

!function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = e || self).Swiper = t()
}(this, (function() {
    "use strict";
    var e = "undefined" == typeof document ? {
        body: {},
        addEventListener: function() {},
        removeEventListener: function() {},
        activeElement: {
            blur: function() {},
            nodeName: ""
        },
        querySelector: function() {
            return null
        },
        querySelectorAll: function() {
            return []
        },
        getElementById: function() {
            return null
        },
        createEvent: function() {
            return {
                initEvent: function() {}
            }
        },
        createElement: function() {
            return {
                children: [],
                childNodes: [],
                style: {},
                setAttribute: function() {},
                getElementsByTagName: function() {
                    return []
                }
            }
        },
        location: {
            hash: ""
        }
    } : document
      , t = "undefined" == typeof window ? {
        document: e,
        navigator: {
            userAgent: ""
        },
        location: {},
        history: {},
        CustomEvent: function() {
            return this
        },
        addEventListener: function() {},
        removeEventListener: function() {},
        getComputedStyle: function() {
            return {
                getPropertyValue: function() {
                    return ""
                }
            }
        },
        Image: function() {},
        Date: function() {},
        screen: {},
        setTimeout: function() {},
        clearTimeout: function() {}
    } : window
      , i = function(e) {
        for (var t = 0; t < e.length; t += 1)
            this[t] = e[t];
        return this.length = e.length,
        this
    };
    function s(s, a) {
        var r = []
          , n = 0;
        if (s && !a && s instanceof i)
            return s;
        if (s)
            if ("string" == typeof s) {
                var o, l, d = s.trim();
                if (d.indexOf("<") >= 0 && d.indexOf(">") >= 0) {
                    var h = "div";
                    for (0 === d.indexOf("<li") && (h = "ul"),
                    0 === d.indexOf("<tr") && (h = "tbody"),
                    0 !== d.indexOf("<td") && 0 !== d.indexOf("<th") || (h = "tr"),
                    0 === d.indexOf("<tbody") && (h = "table"),
                    0 === d.indexOf("<option") && (h = "select"),
                    (l = e.createElement(h)).innerHTML = d,
                    n = 0; n < l.childNodes.length; n += 1)
                        r.push(l.childNodes[n])
                } else
                    for (o = a || "#" !== s[0] || s.match(/[ .<>:~]/) ? (a || e).querySelectorAll(s.trim()) : [e.getElementById(s.trim().split("#")[1])],
                    n = 0; n < o.length; n += 1)
                        o[n] && r.push(o[n])
            } else if (s.nodeType || s === t || s === e)
                r.push(s);
            else if (s.length > 0 && s[0].nodeType)
                for (n = 0; n < s.length; n += 1)
                    r.push(s[n]);
        return new i(r)
    }
    function a(e) {
        for (var t = [], i = 0; i < e.length; i += 1)
            -1 === t.indexOf(e[i]) && t.push(e[i]);
        return t
    }
    s.fn = i.prototype,
    s.Class = i,
    s.Dom7 = i;
    var r = {
        addClass: function(e) {
            if (void 0 === e)
                return this;
            for (var t = e.split(" "), i = 0; i < t.length; i += 1)
                for (var s = 0; s < this.length; s += 1)
                    void 0 !== this[s] && void 0 !== this[s].classList && this[s].classList.add(t[i]);
            return this
        },
        removeClass: function(e) {
            for (var t = e.split(" "), i = 0; i < t.length; i += 1)
                for (var s = 0; s < this.length; s += 1)
                    void 0 !== this[s] && void 0 !== this[s].classList && this[s].classList.remove(t[i]);
            return this
        },
        hasClass: function(e) {
            return !!this[0] && this[0].classList.contains(e)
        },
        toggleClass: function(e) {
            for (var t = e.split(" "), i = 0; i < t.length; i += 1)
                for (var s = 0; s < this.length; s += 1)
                    void 0 !== this[s] && void 0 !== this[s].classList && this[s].classList.toggle(t[i]);
            return this
        },
        attr: function(e, t) {
            var i = arguments;
            if (1 === arguments.length && "string" == typeof e)
                return this[0] ? this[0].getAttribute(e) : void 0;
            for (var s = 0; s < this.length; s += 1)
                if (2 === i.length)
                    this[s].setAttribute(e, t);
                else
                    for (var a in e)
                        this[s][a] = e[a],
                        this[s].setAttribute(a, e[a]);
            return this
        },
        removeAttr: function(e) {
            for (var t = 0; t < this.length; t += 1)
                this[t].removeAttribute(e);
            return this
        },
        data: function(e, t) {
            var i;
            if (void 0 !== t) {
                for (var s = 0; s < this.length; s += 1)
                    (i = this[s]).dom7ElementDataStorage || (i.dom7ElementDataStorage = {}),
                    i.dom7ElementDataStorage[e] = t;
                return this
            }
            if (i = this[0]) {
                if (i.dom7ElementDataStorage && e in i.dom7ElementDataStorage)
                    return i.dom7ElementDataStorage[e];
                var a = i.getAttribute("data-" + e);
                return a || void 0
            }
        },
        transform: function(e) {
            for (var t = 0; t < this.length; t += 1) {
                var i = this[t].style;
                i.webkitTransform = e,
                i.transform = e
            }
            return this
        },
        transition: function(e) {
            "string" != typeof e && (e += "ms");
            for (var t = 0; t < this.length; t += 1) {
                var i = this[t].style;
                i.webkitTransitionDuration = e,
                i.transitionDuration = e
            }
            return this
        },
        on: function() {
            for (var e, t = [], i = arguments.length; i--; )
                t[i] = arguments[i];
            var a = t[0]
              , r = t[1]
              , n = t[2]
              , o = t[3];
            function l(e) {
                var t = e.target;
                if (t) {
                    var i = e.target.dom7EventData || [];
                    if (i.indexOf(e) < 0 && i.unshift(e),
                    s(t).is(r))
                        n.apply(t, i);
                    else
                        for (var a = s(t).parents(), o = 0; o < a.length; o += 1)
                            s(a[o]).is(r) && n.apply(a[o], i)
                }
            }
            function d(e) {
                var t = e && e.target && e.target.dom7EventData || [];
                t.indexOf(e) < 0 && t.unshift(e),
                n.apply(this, t)
            }
            "function" == typeof t[1] && (a = (e = t)[0],
            n = e[1],
            o = e[2],
            r = void 0),
            o || (o = !1);
            for (var h, p = a.split(" "), c = 0; c < this.length; c += 1) {
                var u = this[c];
                if (r)
                    for (h = 0; h < p.length; h += 1) {
                        var v = p[h];
                        u.dom7LiveListeners || (u.dom7LiveListeners = {}),
                        u.dom7LiveListeners[v] || (u.dom7LiveListeners[v] = []),
                        u.dom7LiveListeners[v].push({
                            listener: n,
                            proxyListener: l
                        }),
                        u.addEventListener(v, l, o)
                    }
                else
                    for (h = 0; h < p.length; h += 1) {
                        var f = p[h];
                        u.dom7Listeners || (u.dom7Listeners = {}),
                        u.dom7Listeners[f] || (u.dom7Listeners[f] = []),
                        u.dom7Listeners[f].push({
                            listener: n,
                            proxyListener: d
                        }),
                        u.addEventListener(f, d, o)
                    }
            }
            return this
        },
        off: function() {
            for (var e, t = [], i = arguments.length; i--; )
                t[i] = arguments[i];
            var s = t[0]
              , a = t[1]
              , r = t[2]
              , n = t[3];
            "function" == typeof t[1] && (s = (e = t)[0],
            r = e[1],
            n = e[2],
            a = void 0),
            n || (n = !1);
            for (var o = s.split(" "), l = 0; l < o.length; l += 1)
                for (var d = o[l], h = 0; h < this.length; h += 1) {
                    var p = this[h]
                      , c = void 0;
                    if (!a && p.dom7Listeners ? c = p.dom7Listeners[d] : a && p.dom7LiveListeners && (c = p.dom7LiveListeners[d]),
                    c && c.length)
                        for (var u = c.length - 1; u >= 0; u -= 1) {
                            var v = c[u];
                            r && v.listener === r ? (p.removeEventListener(d, v.proxyListener, n),
                            c.splice(u, 1)) : r && v.listener && v.listener.dom7proxy && v.listener.dom7proxy === r ? (p.removeEventListener(d, v.proxyListener, n),
                            c.splice(u, 1)) : r || (p.removeEventListener(d, v.proxyListener, n),
                            c.splice(u, 1))
                        }
                }
            return this
        },
        trigger: function() {
            for (var i = [], s = arguments.length; s--; )
                i[s] = arguments[s];
            for (var a = i[0].split(" "), r = i[1], n = 0; n < a.length; n += 1)
                for (var o = a[n], l = 0; l < this.length; l += 1) {
                    var d = this[l]
                      , h = void 0;
                    try {
                        h = new t.CustomEvent(o,{
                            detail: r,
                            bubbles: !0,
                            cancelable: !0
                        })
                    } catch (t) {
                        (h = e.createEvent("Event")).initEvent(o, !0, !0),
                        h.detail = r
                    }
                    d.dom7EventData = i.filter((function(e, t) {
                        return t > 0
                    }
                    )),
                    d.dispatchEvent(h),
                    d.dom7EventData = [],
                    delete d.dom7EventData
                }
            return this
        },
        transitionEnd: function(e) {
            var t, i = ["webkitTransitionEnd", "transitionend"], s = this;
            function a(r) {
                if (r.target === this)
                    for (e.call(this, r),
                    t = 0; t < i.length; t += 1)
                        s.off(i[t], a)
            }
            if (e)
                for (t = 0; t < i.length; t += 1)
                    s.on(i[t], a);
            return this
        },
        outerWidth: function(e) {
            if (this.length > 0) {
                if (e) {
                    var t = this.styles();
                    return this[0].offsetWidth + parseFloat(t.getPropertyValue("margin-right")) + parseFloat(t.getPropertyValue("margin-left"))
                }
                return this[0].offsetWidth
            }
            return null
        },
        outerHeight: function(e) {
            if (this.length > 0) {
                if (e) {
                    var t = this.styles();
                    return this[0].offsetHeight + parseFloat(t.getPropertyValue("margin-top")) + parseFloat(t.getPropertyValue("margin-bottom"))
                }
                return this[0].offsetHeight
            }
            return null
        },
        offset: function() {
            if (this.length > 0) {
                var i = this[0]
                  , s = i.getBoundingClientRect()
                  , a = e.body
                  , r = i.clientTop || a.clientTop || 0
                  , n = i.clientLeft || a.clientLeft || 0
                  , o = i === t ? t.scrollY : i.scrollTop
                  , l = i === t ? t.scrollX : i.scrollLeft;
                return {
                    top: s.top + o - r,
                    left: s.left + l - n
                }
            }
            return null
        },
        css: function(e, i) {
            var s;
            if (1 === arguments.length) {
                if ("string" != typeof e) {
                    for (s = 0; s < this.length; s += 1)
                        for (var a in e)
                            this[s].style[a] = e[a];
                    return this
                }
                if (this[0])
                    return t.getComputedStyle(this[0], null).getPropertyValue(e)
            }
            if (2 === arguments.length && "string" == typeof e) {
                for (s = 0; s < this.length; s += 1)
                    this[s].style[e] = i;
                return this
            }
            return this
        },
        each: function(e) {
            if (!e)
                return this;
            for (var t = 0; t < this.length; t += 1)
                if (!1 === e.call(this[t], t, this[t]))
                    return this;
            return this
        },
        html: function(e) {
            if (void 0 === e)
                return this[0] ? this[0].innerHTML : void 0;
            for (var t = 0; t < this.length; t += 1)
                this[t].innerHTML = e;
            return this
        },
        text: function(e) {
            if (void 0 === e)
                return this[0] ? this[0].textContent.trim() : null;
            for (var t = 0; t < this.length; t += 1)
                this[t].textContent = e;
            return this
        },
        is: function(a) {
            var r, n, o = this[0];
            if (!o || void 0 === a)
                return !1;
            if ("string" == typeof a) {
                if (o.matches)
                    return o.matches(a);
                if (o.webkitMatchesSelector)
                    return o.webkitMatchesSelector(a);
                if (o.msMatchesSelector)
                    return o.msMatchesSelector(a);
                for (r = s(a),
                n = 0; n < r.length; n += 1)
                    if (r[n] === o)
                        return !0;
                return !1
            }
            if (a === e)
                return o === e;
            if (a === t)
                return o === t;
            if (a.nodeType || a instanceof i) {
                for (r = a.nodeType ? [a] : a,
                n = 0; n < r.length; n += 1)
                    if (r[n] === o)
                        return !0;
                return !1
            }
            return !1
        },
        index: function() {
            var e, t = this[0];
            if (t) {
                for (e = 0; null !== (t = t.previousSibling); )
                    1 === t.nodeType && (e += 1);
                return e
            }
        },
        eq: function(e) {
            if (void 0 === e)
                return this;
            var t, s = this.length;
            return new i(e > s - 1 ? [] : e < 0 ? (t = s + e) < 0 ? [] : [this[t]] : [this[e]])
        },
        append: function() {
            for (var t, s = [], a = arguments.length; a--; )
                s[a] = arguments[a];
            for (var r = 0; r < s.length; r += 1) {
                t = s[r];
                for (var n = 0; n < this.length; n += 1)
                    if ("string" == typeof t) {
                        var o = e.createElement("div");
                        for (o.innerHTML = t; o.firstChild; )
                            this[n].appendChild(o.firstChild)
                    } else if (t instanceof i)
                        for (var l = 0; l < t.length; l += 1)
                            this[n].appendChild(t[l]);
                    else
                        this[n].appendChild(t)
            }
            return this
        },
        prepend: function(t) {
            var s, a;
            for (s = 0; s < this.length; s += 1)
                if ("string" == typeof t) {
                    var r = e.createElement("div");
                    for (r.innerHTML = t,
                    a = r.childNodes.length - 1; a >= 0; a -= 1)
                        this[s].insertBefore(r.childNodes[a], this[s].childNodes[0])
                } else if (t instanceof i)
                    for (a = 0; a < t.length; a += 1)
                        this[s].insertBefore(t[a], this[s].childNodes[0]);
                else
                    this[s].insertBefore(t, this[s].childNodes[0]);
            return this
        },
        next: function(e) {
            return this.length > 0 ? e ? this[0].nextElementSibling && s(this[0].nextElementSibling).is(e) ? new i([this[0].nextElementSibling]) : new i([]) : this[0].nextElementSibling ? new i([this[0].nextElementSibling]) : new i([]) : new i([])
        },
        nextAll: function(e) {
            var t = []
              , a = this[0];
            if (!a)
                return new i([]);
            for (; a.nextElementSibling; ) {
                var r = a.nextElementSibling;
                e ? s(r).is(e) && t.push(r) : t.push(r),
                a = r
            }
            return new i(t)
        },
        prev: function(e) {
            if (this.length > 0) {
                var t = this[0];
                return e ? t.previousElementSibling && s(t.previousElementSibling).is(e) ? new i([t.previousElementSibling]) : new i([]) : t.previousElementSibling ? new i([t.previousElementSibling]) : new i([])
            }
            return new i([])
        },
        prevAll: function(e) {
            var t = []
              , a = this[0];
            if (!a)
                return new i([]);
            for (; a.previousElementSibling; ) {
                var r = a.previousElementSibling;
                e ? s(r).is(e) && t.push(r) : t.push(r),
                a = r
            }
            return new i(t)
        },
        parent: function(e) {
            for (var t = [], i = 0; i < this.length; i += 1)
                null !== this[i].parentNode && (e ? s(this[i].parentNode).is(e) && t.push(this[i].parentNode) : t.push(this[i].parentNode));
            return s(a(t))
        },
        parents: function(e) {
            for (var t = [], i = 0; i < this.length; i += 1)
                for (var r = this[i].parentNode; r; )
                    e ? s(r).is(e) && t.push(r) : t.push(r),
                    r = r.parentNode;
            return s(a(t))
        },
        closest: function(e) {
            var t = this;
            return void 0 === e ? new i([]) : (t.is(e) || (t = t.parents(e).eq(0)),
            t)
        },
        find: function(e) {
            for (var t = [], s = 0; s < this.length; s += 1)
                for (var a = this[s].querySelectorAll(e), r = 0; r < a.length; r += 1)
                    t.push(a[r]);
            return new i(t)
        },
        children: function(e) {
            for (var t = [], r = 0; r < this.length; r += 1)
                for (var n = this[r].childNodes, o = 0; o < n.length; o += 1)
                    e ? 1 === n[o].nodeType && s(n[o]).is(e) && t.push(n[o]) : 1 === n[o].nodeType && t.push(n[o]);
            return new i(a(t))
        },
        filter: function(e) {
            for (var t = [], s = 0; s < this.length; s += 1)
                e.call(this[s], s, this[s]) && t.push(this[s]);
            return new i(t)
        },
        remove: function() {
            for (var e = 0; e < this.length; e += 1)
                this[e].parentNode && this[e].parentNode.removeChild(this[e]);
            return this
        },
        add: function() {
            for (var e = [], t = arguments.length; t--; )
                e[t] = arguments[t];
            var i, a;
            for (i = 0; i < e.length; i += 1) {
                var r = s(e[i]);
                for (a = 0; a < r.length; a += 1)
                    this[this.length] = r[a],
                    this.length += 1
            }
            return this
        },
        styles: function() {
            return this[0] ? t.getComputedStyle(this[0], null) : {}
        }
    };
    Object.keys(r).forEach((function(e) {
        s.fn[e] = s.fn[e] || r[e]
    }
    ));
    var n = {
        deleteProps: function(e) {
            var t = e;
            Object.keys(t).forEach((function(e) {
                try {
                    t[e] = null
                } catch (e) {}
                try {
                    delete t[e]
                } catch (e) {}
            }
            ))
        },
        nextTick: function(e, t) {
            return void 0 === t && (t = 0),
            setTimeout(e, t)
        },
        now: function() {
            return Date.now()
        },
        getTranslate: function(e, i) {
            var s, a, r;
            void 0 === i && (i = "x");
            var n = t.getComputedStyle(e, null);
            return t.WebKitCSSMatrix ? ((a = n.transform || n.webkitTransform).split(",").length > 6 && (a = a.split(", ").map((function(e) {
                return e.replace(",", ".")
            }
            )).join(", ")),
            r = new t.WebKitCSSMatrix("none" === a ? "" : a)) : s = (r = n.MozTransform || n.OTransform || n.MsTransform || n.msTransform || n.transform || n.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,")).toString().split(","),
            "x" === i && (a = t.WebKitCSSMatrix ? r.m41 : 16 === s.length ? parseFloat(s[12]) : parseFloat(s[4])),
            "y" === i && (a = t.WebKitCSSMatrix ? r.m42 : 16 === s.length ? parseFloat(s[13]) : parseFloat(s[5])),
            a || 0
        },
        parseUrlQuery: function(e) {
            var i, s, a, r, n = {}, o = e || t.location.href;
            if ("string" == typeof o && o.length)
                for (r = (s = (o = o.indexOf("?") > -1 ? o.replace(/\S*\?/, "") : "").split("&").filter((function(e) {
                    return "" !== e
                }
                ))).length,
                i = 0; i < r; i += 1)
                    a = s[i].replace(/#\S+/g, "").split("="),
                    n[decodeURIComponent(a[0])] = void 0 === a[1] ? void 0 : decodeURIComponent(a[1]) || "";
            return n
        },
        isObject: function(e) {
            return "object" == typeof e && null !== e && e.constructor && e.constructor === Object
        },
        extend: function() {
            for (var e = [], t = arguments.length; t--; )
                e[t] = arguments[t];
            for (var i = Object(e[0]), s = 1; s < e.length; s += 1) {
                var a = e[s];
                if (null != a)
                    for (var r = Object.keys(Object(a)), o = 0, l = r.length; o < l; o += 1) {
                        var d = r[o]
                          , h = Object.getOwnPropertyDescriptor(a, d);
                        void 0 !== h && h.enumerable && (n.isObject(i[d]) && n.isObject(a[d]) ? n.extend(i[d], a[d]) : !n.isObject(i[d]) && n.isObject(a[d]) ? (i[d] = {},
                        n.extend(i[d], a[d])) : i[d] = a[d])
                    }
            }
            return i
        }
    }
      , o = {
        touch: t.Modernizr && !0 === t.Modernizr.touch || !!(t.navigator.maxTouchPoints > 0 || "ontouchstart"in t || t.DocumentTouch && e instanceof t.DocumentTouch),
        pointerEvents: !!t.PointerEvent && "maxTouchPoints"in t.navigator && t.navigator.maxTouchPoints > 0,
        observer: "MutationObserver"in t || "WebkitMutationObserver"in t,
        passiveListener: function() {
            var e = !1;
            try {
                var i = Object.defineProperty({}, "passive", {
                    get: function() {
                        e = !0
                    }
                });
                t.addEventListener("testPassiveListener", null, i)
            } catch (e) {}
            return e
        }(),
        gestures: "ongesturestart"in t
    }
      , l = function(e) {
        void 0 === e && (e = {});
        var t = this;
        t.params = e,
        t.eventsListeners = {},
        t.params && t.params.on && Object.keys(t.params.on).forEach((function(e) {
            t.on(e, t.params.on[e])
        }
        ))
    }
      , d = {
        components: {
            configurable: !0
        }
    };
    l.prototype.on = function(e, t, i) {
        var s = this;
        if ("function" != typeof t)
            return s;
        var a = i ? "unshift" : "push";
        return e.split(" ").forEach((function(e) {
            s.eventsListeners[e] || (s.eventsListeners[e] = []),
            s.eventsListeners[e][a](t)
        }
        )),
        s
    }
    ,
    l.prototype.once = function(e, t, i) {
        var s = this;
        if ("function" != typeof t)
            return s;
        function a() {
            for (var i = [], r = arguments.length; r--; )
                i[r] = arguments[r];
            s.off(e, a),
            a.f7proxy && delete a.f7proxy,
            t.apply(s, i)
        }
        return a.f7proxy = t,
        s.on(e, a, i)
    }
    ,
    l.prototype.off = function(e, t) {
        var i = this;
        return i.eventsListeners ? (e.split(" ").forEach((function(e) {
            void 0 === t ? i.eventsListeners[e] = [] : i.eventsListeners[e] && i.eventsListeners[e].length && i.eventsListeners[e].forEach((function(s, a) {
                (s === t || s.f7proxy && s.f7proxy === t) && i.eventsListeners[e].splice(a, 1)
            }
            ))
        }
        )),
        i) : i
    }
    ,
    l.prototype.emit = function() {
        for (var e = [], t = arguments.length; t--; )
            e[t] = arguments[t];
        var i, s, a, r = this;
        if (!r.eventsListeners)
            return r;
        "string" == typeof e[0] || Array.isArray(e[0]) ? (i = e[0],
        s = e.slice(1, e.length),
        a = r) : (i = e[0].events,
        s = e[0].data,
        a = e[0].context || r);
        var n = Array.isArray(i) ? i : i.split(" ");
        return n.forEach((function(e) {
            if (r.eventsListeners && r.eventsListeners[e]) {
                var t = [];
                r.eventsListeners[e].forEach((function(e) {
                    t.push(e)
                }
                )),
                t.forEach((function(e) {
                    e.apply(a, s)
                }
                ))
            }
        }
        )),
        r
    }
    ,
    l.prototype.useModulesParams = function(e) {
        var t = this;
        t.modules && Object.keys(t.modules).forEach((function(i) {
            var s = t.modules[i];
            s.params && n.extend(e, s.params)
        }
        ))
    }
    ,
    l.prototype.useModules = function(e) {
        void 0 === e && (e = {});
        var t = this;
        t.modules && Object.keys(t.modules).forEach((function(i) {
            var s = t.modules[i]
              , a = e[i] || {};
            s.instance && Object.keys(s.instance).forEach((function(e) {
                var i = s.instance[e];
                t[e] = "function" == typeof i ? i.bind(t) : i
            }
            )),
            s.on && t.on && Object.keys(s.on).forEach((function(e) {
                t.on(e, s.on[e])
            }
            )),
            s.create && s.create.bind(t)(a)
        }
        ))
    }
    ,
    d.components.set = function(e) {
        this.use && this.use(e)
    }
    ,
    l.installModule = function(e) {
        for (var t = [], i = arguments.length - 1; i-- > 0; )
            t[i] = arguments[i + 1];
        var s = this;
        s.prototype.modules || (s.prototype.modules = {});
        var a = e.name || Object.keys(s.prototype.modules).length + "_" + n.now();
        return s.prototype.modules[a] = e,
        e.proto && Object.keys(e.proto).forEach((function(t) {
            s.prototype[t] = e.proto[t]
        }
        )),
        e.static && Object.keys(e.static).forEach((function(t) {
            s[t] = e.static[t]
        }
        )),
        e.install && e.install.apply(s, t),
        s
    }
    ,
    l.use = function(e) {
        for (var t = [], i = arguments.length - 1; i-- > 0; )
            t[i] = arguments[i + 1];
        var s = this;
        return Array.isArray(e) ? (e.forEach((function(e) {
            return s.installModule(e)
        }
        )),
        s) : s.installModule.apply(s, [e].concat(t))
    }
    ,
    Object.defineProperties(l, d);
    var h = {
        updateSize: function() {
            var e, t, i = this.$el;
            e = void 0 !== this.params.width ? this.params.width : i[0].clientWidth,
            t = void 0 !== this.params.height ? this.params.height : i[0].clientHeight,
            0 === e && this.isHorizontal() || 0 === t && this.isVertical() || (e = e - parseInt(i.css("padding-left"), 10) - parseInt(i.css("padding-right"), 10),
            t = t - parseInt(i.css("padding-top"), 10) - parseInt(i.css("padding-bottom"), 10),
            n.extend(this, {
                width: e,
                height: t,
                size: this.isHorizontal() ? e : t
            }))
        },
        updateSlides: function() {
            var e = this.params
              , i = this.$wrapperEl
              , s = this.size
              , a = this.rtlTranslate
              , r = this.wrongRTL
              , o = this.virtual && e.virtual.enabled
              , l = o ? this.virtual.slides.length : this.slides.length
              , d = i.children("." + this.params.slideClass)
              , h = o ? this.virtual.slides.length : d.length
              , p = []
              , c = []
              , u = [];
            function v(t) {
                return !e.cssMode || t !== d.length - 1
            }
            var f = e.slidesOffsetBefore;
            "function" == typeof f && (f = e.slidesOffsetBefore.call(this));
            var m = e.slidesOffsetAfter;
            "function" == typeof m && (m = e.slidesOffsetAfter.call(this));
            var g = this.snapGrid.length
              , b = this.snapGrid.length
              , w = e.spaceBetween
              , y = -f
              , x = 0
              , T = 0;
            if (void 0 !== s) {
                var E, S;
                "string" == typeof w && w.indexOf("%") >= 0 && (w = parseFloat(w.replace("%", "")) / 100 * s),
                this.virtualSize = -w,
                a ? d.css({
                    marginLeft: "",
                    marginTop: ""
                }) : d.css({
                    marginRight: "",
                    marginBottom: ""
                }),
                e.slidesPerColumn > 1 && (E = Math.floor(h / e.slidesPerColumn) === h / this.params.slidesPerColumn ? h : Math.ceil(h / e.slidesPerColumn) * e.slidesPerColumn,
                "auto" !== e.slidesPerView && "row" === e.slidesPerColumnFill && (E = Math.max(E, e.slidesPerView * e.slidesPerColumn)));
                for (var C, M = e.slidesPerColumn, P = E / M, z = Math.floor(h / e.slidesPerColumn), k = 0; k < h; k += 1) {
                    S = 0;
                    var $ = d.eq(k);
                    if (e.slidesPerColumn > 1) {
                        var L = void 0
                          , I = void 0
                          , D = void 0;
                        if ("row" === e.slidesPerColumnFill && e.slidesPerGroup > 1) {
                            var O = Math.floor(k / (e.slidesPerGroup * e.slidesPerColumn))
                              , A = k - e.slidesPerColumn * e.slidesPerGroup * O
                              , G = 0 === O ? e.slidesPerGroup : Math.min(Math.ceil((h - O * M * e.slidesPerGroup) / M), e.slidesPerGroup);
                            L = (I = A - (D = Math.floor(A / G)) * G + O * e.slidesPerGroup) + D * E / M,
                            $.css({
                                "-webkit-box-ordinal-group": L,
                                "-moz-box-ordinal-group": L,
                                "-ms-flex-order": L,
                                "-webkit-order": L,
                                order: L
                            })
                        } else
                            "column" === e.slidesPerColumnFill ? (D = k - (I = Math.floor(k / M)) * M,
                            (I > z || I === z && D === M - 1) && (D += 1) >= M && (D = 0,
                            I += 1)) : I = k - (D = Math.floor(k / P)) * P;
                        $.css("margin-" + (this.isHorizontal() ? "top" : "left"), 0 !== D && e.spaceBetween && e.spaceBetween + "px")
                    }
                    if ("none" !== $.css("display")) {
                        if ("auto" === e.slidesPerView) {
                            var H = t.getComputedStyle($[0], null)
                              , B = $[0].style.transform
                              , N = $[0].style.webkitTransform;
                            if (B && ($[0].style.transform = "none"),
                            N && ($[0].style.webkitTransform = "none"),
                            e.roundLengths)
                                S = this.isHorizontal() ? $.outerWidth(!0) : $.outerHeight(!0);
                            else if (this.isHorizontal()) {
                                var X = parseFloat(H.getPropertyValue("width"))
                                  , V = parseFloat(H.getPropertyValue("padding-left"))
                                  , Y = parseFloat(H.getPropertyValue("padding-right"))
                                  , F = parseFloat(H.getPropertyValue("margin-left"))
                                  , W = parseFloat(H.getPropertyValue("margin-right"))
                                  , R = H.getPropertyValue("box-sizing");
                                S = R && "border-box" === R ? X + F + W : X + V + Y + F + W
                            } else {
                                var q = parseFloat(H.getPropertyValue("height"))
                                  , j = parseFloat(H.getPropertyValue("padding-top"))
                                  , K = parseFloat(H.getPropertyValue("padding-bottom"))
                                  , U = parseFloat(H.getPropertyValue("margin-top"))
                                  , _ = parseFloat(H.getPropertyValue("margin-bottom"))
                                  , Z = H.getPropertyValue("box-sizing");
                                S = Z && "border-box" === Z ? q + U + _ : q + j + K + U + _
                            }
                            B && ($[0].style.transform = B),
                            N && ($[0].style.webkitTransform = N),
                            e.roundLengths && (S = Math.floor(S))
                        } else
                            S = (s - (e.slidesPerView - 1) * w) / e.slidesPerView,
                            e.roundLengths && (S = Math.floor(S)),
                            d[k] && (this.isHorizontal() ? d[k].style.width = S + "px" : d[k].style.height = S + "px");
                        d[k] && (d[k].swiperSlideSize = S),
                        u.push(S),
                        e.centeredSlides ? (y = y + S / 2 + x / 2 + w,
                        0 === x && 0 !== k && (y = y - s / 2 - w),
                        0 === k && (y = y - s / 2 - w),
                        Math.abs(y) < .001 && (y = 0),
                        e.roundLengths && (y = Math.floor(y)),
                        T % e.slidesPerGroup == 0 && p.push(y),
                        c.push(y)) : (e.roundLengths && (y = Math.floor(y)),
                        (T - Math.min(this.params.slidesPerGroupSkip, T)) % this.params.slidesPerGroup == 0 && p.push(y),
                        c.push(y),
                        y = y + S + w),
                        this.virtualSize += S + w,
                        x = S,
                        T += 1
                    }
                }
                if (this.virtualSize = Math.max(this.virtualSize, s) + m,
                a && r && ("slide" === e.effect || "coverflow" === e.effect) && i.css({
                    width: this.virtualSize + e.spaceBetween + "px"
                }),
                e.setWrapperSize && (this.isHorizontal() ? i.css({
                    width: this.virtualSize + e.spaceBetween + "px"
                }) : i.css({
                    height: this.virtualSize + e.spaceBetween + "px"
                })),
                e.slidesPerColumn > 1 && (this.virtualSize = (S + e.spaceBetween) * E,
                this.virtualSize = Math.ceil(this.virtualSize / e.slidesPerColumn) - e.spaceBetween,
                this.isHorizontal() ? i.css({
                    width: this.virtualSize + e.spaceBetween + "px"
                }) : i.css({
                    height: this.virtualSize + e.spaceBetween + "px"
                }),
                e.centeredSlides)) {
                    C = [];
                    for (var Q = 0; Q < p.length; Q += 1) {
                        var J = p[Q];
                        e.roundLengths && (J = Math.floor(J)),
                        p[Q] < this.virtualSize + p[0] && C.push(J)
                    }
                    p = C
                }
                if (!e.centeredSlides) {
                    C = [];
                    for (var ee = 0; ee < p.length; ee += 1) {
                        var te = p[ee];
                        e.roundLengths && (te = Math.floor(te)),
                        p[ee] <= this.virtualSize - s && C.push(te)
                    }
                    p = C,
                    Math.floor(this.virtualSize - s) - Math.floor(p[p.length - 1]) > 1 && p.push(this.virtualSize - s)
                }
                if (0 === p.length && (p = [0]),
                0 !== e.spaceBetween && (this.isHorizontal() ? a ? d.filter(v).css({
                    marginLeft: w + "px"
                }) : d.filter(v).css({
                    marginRight: w + "px"
                }) : d.filter(v).css({
                    marginBottom: w + "px"
                })),
                e.centeredSlides && e.centeredSlidesBounds) {
                    var ie = 0;
                    u.forEach((function(t) {
                        ie += t + (e.spaceBetween ? e.spaceBetween : 0)
                    }
                    ));
                    var se = (ie -= e.spaceBetween) - s;
                    p = p.map((function(e) {
                        return e < 0 ? -f : e > se ? se + m : e
                    }
                    ))
                }
                if (e.centerInsufficientSlides) {
                    var ae = 0;
                    if (u.forEach((function(t) {
                        ae += t + (e.spaceBetween ? e.spaceBetween : 0)
                    }
                    )),
                    (ae -= e.spaceBetween) < s) {
                        var re = (s - ae) / 2;
                        p.forEach((function(e, t) {
                            p[t] = e - re
                        }
                        )),
                        c.forEach((function(e, t) {
                            c[t] = e + re
                        }
                        ))
                    }
                }
                n.extend(this, {
                    slides: d,
                    snapGrid: p,
                    slidesGrid: c,
                    slidesSizesGrid: u
                }),
                h !== l && this.emit("slidesLengthChange"),
                p.length !== g && (this.params.watchOverflow && this.checkOverflow(),
                this.emit("snapGridLengthChange")),
                c.length !== b && this.emit("slidesGridLengthChange"),
                (e.watchSlidesProgress || e.watchSlidesVisibility) && this.updateSlidesOffset()
            }
        },
        updateAutoHeight: function(e) {
            var t, i = [], s = 0;
            if ("number" == typeof e ? this.setTransition(e) : !0 === e && this.setTransition(this.params.speed),
            "auto" !== this.params.slidesPerView && this.params.slidesPerView > 1)
                if (this.params.centeredSlides)
                    i.push.apply(i, this.visibleSlides);
                else
                    for (t = 0; t < Math.ceil(this.params.slidesPerView); t += 1) {
                        var a = this.activeIndex + t;
                        if (a > this.slides.length)
                            break;
                        i.push(this.slides.eq(a)[0])
                    }
            else
                i.push(this.slides.eq(this.activeIndex)[0]);
            for (t = 0; t < i.length; t += 1)
                if (void 0 !== i[t]) {
                    var r = i[t].offsetHeight;
                    s = r > s ? r : s
                }
            s && this.$wrapperEl.css("height", s + "px")
        },
        updateSlidesOffset: function() {
            for (var e = this.slides, t = 0; t < e.length; t += 1)
                e[t].swiperSlideOffset = this.isHorizontal() ? e[t].offsetLeft : e[t].offsetTop
        },
        updateSlidesProgress: function(e) {
            void 0 === e && (e = this && this.translate || 0);
            var t = this.params
              , i = this.slides
              , a = this.rtlTranslate;
            if (0 !== i.length) {
                void 0 === i[0].swiperSlideOffset && this.updateSlidesOffset();
                var r = -e;
                a && (r = e),
                i.removeClass(t.slideVisibleClass),
                this.visibleSlidesIndexes = [],
                this.visibleSlides = [];
                for (var n = 0; n < i.length; n += 1) {
                    var o = i[n]
                      , l = (r + (t.centeredSlides ? this.minTranslate() : 0) - o.swiperSlideOffset) / (o.swiperSlideSize + t.spaceBetween);
                    if (t.watchSlidesVisibility || t.centeredSlides && t.autoHeight) {
                        var d = -(r - o.swiperSlideOffset)
                          , h = d + this.slidesSizesGrid[n];
                        (d >= 0 && d < this.size - 1 || h > 1 && h <= this.size || d <= 0 && h >= this.size) && (this.visibleSlides.push(o),
                        this.visibleSlidesIndexes.push(n),
                        i.eq(n).addClass(t.slideVisibleClass))
                    }
                    o.progress = a ? -l : l
                }
                this.visibleSlides = s(this.visibleSlides)
            }
        },
        updateProgress: function(e) {
            if (void 0 === e) {
                var t = this.rtlTranslate ? -1 : 1;
                e = this && this.translate && this.translate * t || 0
            }
            var i = this.params
              , s = this.maxTranslate() - this.minTranslate()
              , a = this.progress
              , r = this.isBeginning
              , o = this.isEnd
              , l = r
              , d = o;
            0 === s ? (a = 0,
            r = !0,
            o = !0) : (r = (a = (e - this.minTranslate()) / s) <= 0,
            o = a >= 1),
            n.extend(this, {
                progress: a,
                isBeginning: r,
                isEnd: o
            }),
            (i.watchSlidesProgress || i.watchSlidesVisibility || i.centeredSlides && i.autoHeight) && this.updateSlidesProgress(e),
            r && !l && this.emit("reachBeginning toEdge"),
            o && !d && this.emit("reachEnd toEdge"),
            (l && !r || d && !o) && this.emit("fromEdge"),
            this.emit("progress", a)
        },
        updateSlidesClasses: function() {
            var e, t = this.slides, i = this.params, s = this.$wrapperEl, a = this.activeIndex, r = this.realIndex, n = this.virtual && i.virtual.enabled;
            t.removeClass(i.slideActiveClass + " " + i.slideNextClass + " " + i.slidePrevClass + " " + i.slideDuplicateActiveClass + " " + i.slideDuplicateNextClass + " " + i.slideDuplicatePrevClass),
            (e = n ? this.$wrapperEl.find("." + i.slideClass + '[data-swiper-slide-index="' + a + '"]') : t.eq(a)).addClass(i.slideActiveClass),
            i.loop && (e.hasClass(i.slideDuplicateClass) ? s.children("." + i.slideClass + ":not(." + i.slideDuplicateClass + ')[data-swiper-slide-index="' + r + '"]').addClass(i.slideDuplicateActiveClass) : s.children("." + i.slideClass + "." + i.slideDuplicateClass + '[data-swiper-slide-index="' + r + '"]').addClass(i.slideDuplicateActiveClass));
            var o = e.nextAll("." + i.slideClass).eq(0).addClass(i.slideNextClass);
            i.loop && 0 === o.length && (o = t.eq(0)).addClass(i.slideNextClass);
            var l = e.prevAll("." + i.slideClass).eq(0).addClass(i.slidePrevClass);
            i.loop && 0 === l.length && (l = t.eq(-1)).addClass(i.slidePrevClass),
            i.loop && (o.hasClass(i.slideDuplicateClass) ? s.children("." + i.slideClass + ":not(." + i.slideDuplicateClass + ')[data-swiper-slide-index="' + o.attr("data-swiper-slide-index") + '"]').addClass(i.slideDuplicateNextClass) : s.children("." + i.slideClass + "." + i.slideDuplicateClass + '[data-swiper-slide-index="' + o.attr("data-swiper-slide-index") + '"]').addClass(i.slideDuplicateNextClass),
            l.hasClass(i.slideDuplicateClass) ? s.children("." + i.slideClass + ":not(." + i.slideDuplicateClass + ')[data-swiper-slide-index="' + l.attr("data-swiper-slide-index") + '"]').addClass(i.slideDuplicatePrevClass) : s.children("." + i.slideClass + "." + i.slideDuplicateClass + '[data-swiper-slide-index="' + l.attr("data-swiper-slide-index") + '"]').addClass(i.slideDuplicatePrevClass))
        },
        updateActiveIndex: function(e) {
            var t, i = this.rtlTranslate ? this.translate : -this.translate, s = this.slidesGrid, a = this.snapGrid, r = this.params, o = this.activeIndex, l = this.realIndex, d = this.snapIndex, h = e;
            if (void 0 === h) {
                for (var p = 0; p < s.length; p += 1)
                    void 0 !== s[p + 1] ? i >= s[p] && i < s[p + 1] - (s[p + 1] - s[p]) / 2 ? h = p : i >= s[p] && i < s[p + 1] && (h = p + 1) : i >= s[p] && (h = p);
                r.normalizeSlideIndex && (h < 0 || void 0 === h) && (h = 0)
            }
            if (a.indexOf(i) >= 0)
                t = a.indexOf(i);
            else {
                var c = Math.min(r.slidesPerGroupSkip, h);
                t = c + Math.floor((h - c) / r.slidesPerGroup)
            }
            if (t >= a.length && (t = a.length - 1),
            h !== o) {
                var u = parseInt(this.slides.eq(h).attr("data-swiper-slide-index") || h, 10);
                n.extend(this, {
                    snapIndex: t,
                    realIndex: u,
                    previousIndex: o,
                    activeIndex: h
                }),
                this.emit("activeIndexChange"),
                this.emit("snapIndexChange"),
                l !== u && this.emit("realIndexChange"),
                (this.initialized || this.runCallbacksOnInit) && this.emit("slideChange")
            } else
                t !== d && (this.snapIndex = t,
                this.emit("snapIndexChange"))
        },
        updateClickedSlide: function(e) {
            var t = this.params
              , i = s(e.target).closest("." + t.slideClass)[0]
              , a = !1;
            if (i)
                for (var r = 0; r < this.slides.length; r += 1)
                    this.slides[r] === i && (a = !0);
            if (!i || !a)
                return this.clickedSlide = void 0,
                void (this.clickedIndex = void 0);
            this.clickedSlide = i,
            this.virtual && this.params.virtual.enabled ? this.clickedIndex = parseInt(s(i).attr("data-swiper-slide-index"), 10) : this.clickedIndex = s(i).index(),
            t.slideToClickedSlide && void 0 !== this.clickedIndex && this.clickedIndex !== this.activeIndex && this.slideToClickedSlide()
        }
    };
    var p = {
        getTranslate: function(e) {
            void 0 === e && (e = this.isHorizontal() ? "x" : "y");
            var t = this.params
              , i = this.rtlTranslate
              , s = this.translate
              , a = this.$wrapperEl;
            if (t.virtualTranslate)
                return i ? -s : s;
            if (t.cssMode)
                return s;
            var r = n.getTranslate(a[0], e);
            return i && (r = -r),
            r || 0
        },
        setTranslate: function(e, t) {
            var i = this.rtlTranslate
              , s = this.params
              , a = this.$wrapperEl
              , r = this.wrapperEl
              , n = this.progress
              , o = 0
              , l = 0;
            this.isHorizontal() ? o = i ? -e : e : l = e,
            s.roundLengths && (o = Math.floor(o),
            l = Math.floor(l)),
            s.cssMode ? r[this.isHorizontal() ? "scrollLeft" : "scrollTop"] = this.isHorizontal() ? -o : -l : s.virtualTranslate || a.transform("translate3d(" + o + "px, " + l + "px, 0px)"),
            this.previousTranslate = this.translate,
            this.translate = this.isHorizontal() ? o : l;
            var d = this.maxTranslate() - this.minTranslate();
            (0 === d ? 0 : (e - this.minTranslate()) / d) !== n && this.updateProgress(e),
            this.emit("setTranslate", this.translate, t)
        },
        minTranslate: function() {
            return -this.snapGrid[0]
        },
        maxTranslate: function() {
            return -this.snapGrid[this.snapGrid.length - 1]
        },
        translateTo: function(e, t, i, s, a) {
            var r;
            void 0 === e && (e = 0),
            void 0 === t && (t = this.params.speed),
            void 0 === i && (i = !0),
            void 0 === s && (s = !0);
            var n = this
              , o = n.params
              , l = n.wrapperEl;
            if (n.animating && o.preventInteractionOnTransition)
                return !1;
            var d, h = n.minTranslate(), p = n.maxTranslate();
            if (d = s && e > h ? h : s && e < p ? p : e,
            n.updateProgress(d),
            o.cssMode) {
                var c = n.isHorizontal();
                return 0 === t ? l[c ? "scrollLeft" : "scrollTop"] = -d : l.scrollTo ? l.scrollTo(((r = {})[c ? "left" : "top"] = -d,
                r.behavior = "smooth",
                r)) : l[c ? "scrollLeft" : "scrollTop"] = -d,
                !0
            }
            return 0 === t ? (n.setTransition(0),
            n.setTranslate(d),
            i && (n.emit("beforeTransitionStart", t, a),
            n.emit("transitionEnd"))) : (n.setTransition(t),
            n.setTranslate(d),
            i && (n.emit("beforeTransitionStart", t, a),
            n.emit("transitionStart")),
            n.animating || (n.animating = !0,
            n.onTranslateToWrapperTransitionEnd || (n.onTranslateToWrapperTransitionEnd = function(e) {
                n && !n.destroyed && e.target === this && (n.$wrapperEl[0].removeEventListener("transitionend", n.onTranslateToWrapperTransitionEnd),
                n.$wrapperEl[0].removeEventListener("webkitTransitionEnd", n.onTranslateToWrapperTransitionEnd),
                n.onTranslateToWrapperTransitionEnd = null,
                delete n.onTranslateToWrapperTransitionEnd,
                i && n.emit("transitionEnd"))
            }
            ),
            n.$wrapperEl[0].addEventListener("transitionend", n.onTranslateToWrapperTransitionEnd),
            n.$wrapperEl[0].addEventListener("webkitTransitionEnd", n.onTranslateToWrapperTransitionEnd))),
            !0
        }
    };
    var c = {
        setTransition: function(e, t) {
            this.params.cssMode || this.$wrapperEl.transition(e),
            this.emit("setTransition", e, t)
        },
        transitionStart: function(e, t) {
            void 0 === e && (e = !0);
            var i = this.activeIndex
              , s = this.params
              , a = this.previousIndex;
            if (!s.cssMode) {
                s.autoHeight && this.updateAutoHeight();
                var r = t;
                if (r || (r = i > a ? "next" : i < a ? "prev" : "reset"),
                this.emit("transitionStart"),
                e && i !== a) {
                    if ("reset" === r)
                        return void this.emit("slideResetTransitionStart");
                    this.emit("slideChangeTransitionStart"),
                    "next" === r ? this.emit("slideNextTransitionStart") : this.emit("slidePrevTransitionStart")
                }
            }
        },
        transitionEnd: function(e, t) {
            void 0 === e && (e = !0);
            var i = this.activeIndex
              , s = this.previousIndex
              , a = this.params;
            if (this.animating = !1,
            !a.cssMode) {
                this.setTransition(0);
                var r = t;
                if (r || (r = i > s ? "next" : i < s ? "prev" : "reset"),
                this.emit("transitionEnd"),
                e && i !== s) {
                    if ("reset" === r)
                        return void this.emit("slideResetTransitionEnd");
                    this.emit("slideChangeTransitionEnd"),
                    "next" === r ? this.emit("slideNextTransitionEnd") : this.emit("slidePrevTransitionEnd")
                }
            }
        }
    };
    var u = {
        slideTo: function(e, t, i, s) {
            var a;
            void 0 === e && (e = 0),
            void 0 === t && (t = this.params.speed),
            void 0 === i && (i = !0);
            var r = this
              , n = e;
            n < 0 && (n = 0);
            var o = r.params
              , l = r.snapGrid
              , d = r.slidesGrid
              , h = r.previousIndex
              , p = r.activeIndex
              , c = r.rtlTranslate
              , u = r.wrapperEl;
            if (r.animating && o.preventInteractionOnTransition)
                return !1;
            var v = Math.min(r.params.slidesPerGroupSkip, n)
              , f = v + Math.floor((n - v) / r.params.slidesPerGroup);
            f >= l.length && (f = l.length - 1),
            (p || o.initialSlide || 0) === (h || 0) && i && r.emit("beforeSlideChangeStart");
            var m, g = -l[f];
            if (r.updateProgress(g),
            o.normalizeSlideIndex)
                for (var b = 0; b < d.length; b += 1)
                    -Math.floor(100 * g) >= Math.floor(100 * d[b]) && (n = b);
            if (r.initialized && n !== p) {
                if (!r.allowSlideNext && g < r.translate && g < r.minTranslate())
                    return !1;
                if (!r.allowSlidePrev && g > r.translate && g > r.maxTranslate() && (p || 0) !== n)
                    return !1
            }
            if (m = n > p ? "next" : n < p ? "prev" : "reset",
            c && -g === r.translate || !c && g === r.translate)
                return r.updateActiveIndex(n),
                o.autoHeight && r.updateAutoHeight(),
                r.updateSlidesClasses(),
                "slide" !== o.effect && r.setTranslate(g),
                "reset" !== m && (r.transitionStart(i, m),
                r.transitionEnd(i, m)),
                !1;
            if (o.cssMode) {
                var w = r.isHorizontal();
                return 0 === t ? u[w ? "scrollLeft" : "scrollTop"] = -g : u.scrollTo ? u.scrollTo(((a = {})[w ? "left" : "top"] = -g,
                a.behavior = "smooth",
                a)) : u[w ? "scrollLeft" : "scrollTop"] = -g,
                !0
            }
            return 0 === t ? (r.setTransition(0),
            r.setTranslate(g),
            r.updateActiveIndex(n),
            r.updateSlidesClasses(),
            r.emit("beforeTransitionStart", t, s),
            r.transitionStart(i, m),
            r.transitionEnd(i, m)) : (r.setTransition(t),
            r.setTranslate(g),
            r.updateActiveIndex(n),
            r.updateSlidesClasses(),
            r.emit("beforeTransitionStart", t, s),
            r.transitionStart(i, m),
            r.animating || (r.animating = !0,
            r.onSlideToWrapperTransitionEnd || (r.onSlideToWrapperTransitionEnd = function(e) {
                r && !r.destroyed && e.target === this && (r.$wrapperEl[0].removeEventListener("transitionend", r.onSlideToWrapperTransitionEnd),
                r.$wrapperEl[0].removeEventListener("webkitTransitionEnd", r.onSlideToWrapperTransitionEnd),
                r.onSlideToWrapperTransitionEnd = null,
                delete r.onSlideToWrapperTransitionEnd,
                r.transitionEnd(i, m))
            }
            ),
            r.$wrapperEl[0].addEventListener("transitionend", r.onSlideToWrapperTransitionEnd),
            r.$wrapperEl[0].addEventListener("webkitTransitionEnd", r.onSlideToWrapperTransitionEnd))),
            !0
        },
        slideToLoop: function(e, t, i, s) {
            void 0 === e && (e = 0),
            void 0 === t && (t = this.params.speed),
            void 0 === i && (i = !0);
            var a = e;
            return this.params.loop && (a += this.loopedSlides),
            this.slideTo(a, t, i, s)
        },
        slideNext: function(e, t, i) {
            void 0 === e && (e = this.params.speed),
            void 0 === t && (t = !0);
            var s = this.params
              , a = this.animating
              , r = this.activeIndex < s.slidesPerGroupSkip ? 1 : s.slidesPerGroup;
            if (s.loop) {
                if (a)
                    return !1;
                this.loopFix(),
                this._clientLeft = this.$wrapperEl[0].clientLeft
            }
            return this.slideTo(this.activeIndex + r, e, t, i)
        },
        slidePrev: function(e, t, i) {
            void 0 === e && (e = this.params.speed),
            void 0 === t && (t = !0);
            var s = this.params
              , a = this.animating
              , r = this.snapGrid
              , n = this.slidesGrid
              , o = this.rtlTranslate;
            if (s.loop) {
                if (a)
                    return !1;
                this.loopFix(),
                this._clientLeft = this.$wrapperEl[0].clientLeft
            }
            function l(e) {
                return e < 0 ? -Math.floor(Math.abs(e)) : Math.floor(e)
            }
            var d, h = l(o ? this.translate : -this.translate), p = r.map((function(e) {
                return l(e)
            }
            )), c = (n.map((function(e) {
                return l(e)
            }
            )),
            r[p.indexOf(h)],
            r[p.indexOf(h) - 1]);
            return void 0 === c && s.cssMode && r.forEach((function(e) {
                !c && h >= e && (c = e)
            }
            )),
            void 0 !== c && (d = n.indexOf(c)) < 0 && (d = this.activeIndex - 1),
            this.slideTo(d, e, t, i)
        },
        slideReset: function(e, t, i) {
            return void 0 === e && (e = this.params.speed),
            void 0 === t && (t = !0),
            this.slideTo(this.activeIndex, e, t, i)
        },
        slideToClosest: function(e, t, i, s) {
            void 0 === e && (e = this.params.speed),
            void 0 === t && (t = !0),
            void 0 === s && (s = .5);
            var a = this.activeIndex
              , r = Math.min(this.params.slidesPerGroupSkip, a)
              , n = r + Math.floor((a - r) / this.params.slidesPerGroup)
              , o = this.rtlTranslate ? this.translate : -this.translate;
            if (o >= this.snapGrid[n]) {
                var l = this.snapGrid[n];
                o - l > (this.snapGrid[n + 1] - l) * s && (a += this.params.slidesPerGroup)
            } else {
                var d = this.snapGrid[n - 1];
                o - d <= (this.snapGrid[n] - d) * s && (a -= this.params.slidesPerGroup)
            }
            return a = Math.max(a, 0),
            a = Math.min(a, this.slidesGrid.length - 1),
            this.slideTo(a, e, t, i)
        },
        slideToClickedSlide: function() {
            var e, t = this, i = t.params, a = t.$wrapperEl, r = "auto" === i.slidesPerView ? t.slidesPerViewDynamic() : i.slidesPerView, o = t.clickedIndex;
            if (i.loop) {
                if (t.animating)
                    return;
                e = parseInt(s(t.clickedSlide).attr("data-swiper-slide-index"), 10),
                i.centeredSlides ? o < t.loopedSlides - r / 2 || o > t.slides.length - t.loopedSlides + r / 2 ? (t.loopFix(),
                o = a.children("." + i.slideClass + '[data-swiper-slide-index="' + e + '"]:not(.' + i.slideDuplicateClass + ")").eq(0).index(),
                n.nextTick((function() {
                    t.slideTo(o)
                }
                ))) : t.slideTo(o) : o > t.slides.length - r ? (t.loopFix(),
                o = a.children("." + i.slideClass + '[data-swiper-slide-index="' + e + '"]:not(.' + i.slideDuplicateClass + ")").eq(0).index(),
                n.nextTick((function() {
                    t.slideTo(o)
                }
                ))) : t.slideTo(o)
            } else
                t.slideTo(o)
        }
    };
    var v = {
        loopCreate: function() {
            var t = this
              , i = t.params
              , a = t.$wrapperEl;
            a.children("." + i.slideClass + "." + i.slideDuplicateClass).remove();
            var r = a.children("." + i.slideClass);
            if (i.loopFillGroupWithBlank) {
                var n = i.slidesPerGroup - r.length % i.slidesPerGroup;
                if (n !== i.slidesPerGroup) {
                    for (var o = 0; o < n; o += 1) {
                        var l = s(e.createElement("div")).addClass(i.slideClass + " " + i.slideBlankClass);
                        a.append(l)
                    }
                    r = a.children("." + i.slideClass)
                }
            }
            "auto" !== i.slidesPerView || i.loopedSlides || (i.loopedSlides = r.length),
            t.loopedSlides = Math.ceil(parseFloat(i.loopedSlides || i.slidesPerView, 10)),
            t.loopedSlides += i.loopAdditionalSlides,
            t.loopedSlides > r.length && (t.loopedSlides = r.length);
            var d = []
              , h = [];
            r.each((function(e, i) {
                var a = s(i);
                e < t.loopedSlides && h.push(i),
                e < r.length && e >= r.length - t.loopedSlides && d.push(i),
                a.attr("data-swiper-slide-index", e)
            }
            ));
            for (var p = 0; p < h.length; p += 1)
                a.append(s(h[p].cloneNode(!0)).addClass(i.slideDuplicateClass));
            for (var c = d.length - 1; c >= 0; c -= 1)
                a.prepend(s(d[c].cloneNode(!0)).addClass(i.slideDuplicateClass))
        },
        loopFix: function() {
            this.emit("beforeLoopFix");
            var e, t = this.activeIndex, i = this.slides, s = this.loopedSlides, a = this.allowSlidePrev, r = this.allowSlideNext, n = this.snapGrid, o = this.rtlTranslate;
            this.allowSlidePrev = !0,
            this.allowSlideNext = !0;
            var l = -n[t] - this.getTranslate();
            if (t < s)
                e = i.length - 3 * s + t,
                e += s,
                this.slideTo(e, 0, !1, !0) && 0 !== l && this.setTranslate((o ? -this.translate : this.translate) - l);
            else if (t >= i.length - s) {
                e = -i.length + t + s,
                e += s,
                this.slideTo(e, 0, !1, !0) && 0 !== l && this.setTranslate((o ? -this.translate : this.translate) - l)
            }
            this.allowSlidePrev = a,
            this.allowSlideNext = r,
            this.emit("loopFix")
        },
        loopDestroy: function() {
            var e = this.$wrapperEl
              , t = this.params
              , i = this.slides;
            e.children("." + t.slideClass + "." + t.slideDuplicateClass + ",." + t.slideClass + "." + t.slideBlankClass).remove(),
            i.removeAttr("data-swiper-slide-index")
        }
    };
    var f = {
        setGrabCursor: function(e) {
            if (!(o.touch || !this.params.simulateTouch || this.params.watchOverflow && this.isLocked || this.params.cssMode)) {
                var t = this.el;
                t.style.cursor = "move",
                t.style.cursor = e ? "-webkit-grabbing" : "-webkit-grab",
                t.style.cursor = e ? "-moz-grabbin" : "-moz-grab",
                t.style.cursor = e ? "grabbing" : "grab"
            }
        },
        unsetGrabCursor: function() {
            o.touch || this.params.watchOverflow && this.isLocked || this.params.cssMode || (this.el.style.cursor = "")
        }
    };
    var m, g, b, w, y, x, T, E, S, C, M, P, z, k, $, L = {
        appendSlide: function(e) {
            var t = this.$wrapperEl
              , i = this.params;
            if (i.loop && this.loopDestroy(),
            "object" == typeof e && "length"in e)
                for (var s = 0; s < e.length; s += 1)
                    e[s] && t.append(e[s]);
            else
                t.append(e);
            i.loop && this.loopCreate(),
            i.observer && o.observer || this.update()
        },
        prependSlide: function(e) {
            var t = this.params
              , i = this.$wrapperEl
              , s = this.activeIndex;
            t.loop && this.loopDestroy();
            var a = s + 1;
            if ("object" == typeof e && "length"in e) {
                for (var r = 0; r < e.length; r += 1)
                    e[r] && i.prepend(e[r]);
                a = s + e.length
            } else
                i.prepend(e);
            t.loop && this.loopCreate(),
            t.observer && o.observer || this.update(),
            this.slideTo(a, 0, !1)
        },
        addSlide: function(e, t) {
            var i = this.$wrapperEl
              , s = this.params
              , a = this.activeIndex;
            s.loop && (a -= this.loopedSlides,
            this.loopDestroy(),
            this.slides = i.children("." + s.slideClass));
            var r = this.slides.length;
            if (e <= 0)
                this.prependSlide(t);
            else if (e >= r)
                this.appendSlide(t);
            else {
                for (var n = a > e ? a + 1 : a, l = [], d = r - 1; d >= e; d -= 1) {
                    var h = this.slides.eq(d);
                    h.remove(),
                    l.unshift(h)
                }
                if ("object" == typeof t && "length"in t) {
                    for (var p = 0; p < t.length; p += 1)
                        t[p] && i.append(t[p]);
                    n = a > e ? a + t.length : a
                } else
                    i.append(t);
                for (var c = 0; c < l.length; c += 1)
                    i.append(l[c]);
                s.loop && this.loopCreate(),
                s.observer && o.observer || this.update(),
                s.loop ? this.slideTo(n + this.loopedSlides, 0, !1) : this.slideTo(n, 0, !1)
            }
        },
        removeSlide: function(e) {
            var t = this.params
              , i = this.$wrapperEl
              , s = this.activeIndex;
            t.loop && (s -= this.loopedSlides,
            this.loopDestroy(),
            this.slides = i.children("." + t.slideClass));
            var a, r = s;
            if ("object" == typeof e && "length"in e) {
                for (var n = 0; n < e.length; n += 1)
                    a = e[n],
                    this.slides[a] && this.slides.eq(a).remove(),
                    a < r && (r -= 1);
                r = Math.max(r, 0)
            } else
                a = e,
                this.slides[a] && this.slides.eq(a).remove(),
                a < r && (r -= 1),
                r = Math.max(r, 0);
            t.loop && this.loopCreate(),
            t.observer && o.observer || this.update(),
            t.loop ? this.slideTo(r + this.loopedSlides, 0, !1) : this.slideTo(r, 0, !1)
        },
        removeAllSlides: function() {
            for (var e = [], t = 0; t < this.slides.length; t += 1)
                e.push(t);
            this.removeSlide(e)
        }
    }, I = (m = t.navigator.platform,
    g = t.navigator.userAgent,
    b = {
        ios: !1,
        android: !1,
        androidChrome: !1,
        desktop: !1,
        iphone: !1,
        ipod: !1,
        ipad: !1,
        edge: !1,
        ie: !1,
        firefox: !1,
        macos: !1,
        windows: !1,
        cordova: !(!t.cordova && !t.phonegap),
        phonegap: !(!t.cordova && !t.phonegap),
        electron: !1
    },
    w = t.screen.width,
    y = t.screen.height,
    x = g.match(/(Android);?[\s\/]+([\d.]+)?/),
    T = g.match(/(iPad).*OS\s([\d_]+)/),
    E = g.match(/(iPod)(.*OS\s([\d_]+))?/),
    S = !T && g.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
    C = g.indexOf("MSIE ") >= 0 || g.indexOf("Trident/") >= 0,
    M = g.indexOf("Edge/") >= 0,
    P = g.indexOf("Gecko/") >= 0 && g.indexOf("Firefox/") >= 0,
    z = "Win32" === m,
    k = g.toLowerCase().indexOf("electron") >= 0,
    $ = "MacIntel" === m,
    !T && $ && o.touch && (1024 === w && 1366 === y || 834 === w && 1194 === y || 834 === w && 1112 === y || 768 === w && 1024 === y) && (T = g.match(/(Version)\/([\d.]+)/),
    $ = !1),
    b.ie = C,
    b.edge = M,
    b.firefox = P,
    x && !z && (b.os = "android",
    b.osVersion = x[2],
    b.android = !0,
    b.androidChrome = g.toLowerCase().indexOf("chrome") >= 0),
    (T || S || E) && (b.os = "ios",
    b.ios = !0),
    S && !E && (b.osVersion = S[2].replace(/_/g, "."),
    b.iphone = !0),
    T && (b.osVersion = T[2].replace(/_/g, "."),
    b.ipad = !0),
    E && (b.osVersion = E[3] ? E[3].replace(/_/g, ".") : null,
    b.ipod = !0),
    b.ios && b.osVersion && g.indexOf("Version/") >= 0 && "10" === b.osVersion.split(".")[0] && (b.osVersion = g.toLowerCase().split("version/")[1].split(" ")[0]),
    b.webView = !(!(S || T || E) || !g.match(/.*AppleWebKit(?!.*Safari)/i) && !t.navigator.standalone) || t.matchMedia && t.matchMedia("(display-mode: standalone)").matches,
    b.webview = b.webView,
    b.standalone = b.webView,
    b.desktop = !(b.ios || b.android) || k,
    b.desktop && (b.electron = k,
    b.macos = $,
    b.windows = z,
    b.macos && (b.os = "macos"),
    b.windows && (b.os = "windows")),
    b.pixelRatio = t.devicePixelRatio || 1,
    b);
    function D(i) {
        var a = this.touchEventsData
          , r = this.params
          , o = this.touches;
        if (!this.animating || !r.preventInteractionOnTransition) {
            var l = i;
            l.originalEvent && (l = l.originalEvent);
            var d = s(l.target);
            if (("wrapper" !== r.touchEventsTarget || d.closest(this.wrapperEl).length) && (a.isTouchEvent = "touchstart" === l.type,
            (a.isTouchEvent || !("which"in l) || 3 !== l.which) && !(!a.isTouchEvent && "button"in l && l.button > 0 || a.isTouched && a.isMoved)))
                if (r.noSwiping && d.closest(r.noSwipingSelector ? r.noSwipingSelector : "." + r.noSwipingClass)[0])
                    this.allowClick = !0;
                else if (!r.swipeHandler || d.closest(r.swipeHandler)[0]) {
                    o.currentX = "touchstart" === l.type ? l.targetTouches[0].pageX : l.pageX,
                    o.currentY = "touchstart" === l.type ? l.targetTouches[0].pageY : l.pageY;
                    var h = o.currentX
                      , p = o.currentY
                      , c = r.edgeSwipeDetection || r.iOSEdgeSwipeDetection
                      , u = r.edgeSwipeThreshold || r.iOSEdgeSwipeThreshold;
                    if (!c || !(h <= u || h >= t.screen.width - u)) {
                        if (n.extend(a, {
                            isTouched: !0,
                            isMoved: !1,
                            allowTouchCallbacks: !0,
                            isScrolling: void 0,
                            startMoving: void 0
                        }),
                        o.startX = h,
                        o.startY = p,
                        a.touchStartTime = n.now(),
                        this.allowClick = !0,
                        this.updateSize(),
                        this.swipeDirection = void 0,
                        r.threshold > 0 && (a.allowThresholdMove = !1),
                        "touchstart" !== l.type) {
                            var v = !0;
                            d.is(a.formElements) && (v = !1),
                            e.activeElement && s(e.activeElement).is(a.formElements) && e.activeElement !== d[0] && e.activeElement.blur();
                            var f = v && this.allowTouchMove && r.touchStartPreventDefault;
                            (r.touchStartForcePreventDefault || f) && l.preventDefault()
                        }
                        this.emit("touchStart", l)
                    }
                }
        }
    }
    function O(t) {
        var i = this.touchEventsData
          , a = this.params
          , r = this.touches
          , o = this.rtlTranslate
          , l = t;
        if (l.originalEvent && (l = l.originalEvent),
        i.isTouched) {
            if (!i.isTouchEvent || "mousemove" !== l.type) {
                var d = "touchmove" === l.type && l.targetTouches && (l.targetTouches[0] || l.changedTouches[0])
                  , h = "touchmove" === l.type ? d.pageX : l.pageX
                  , p = "touchmove" === l.type ? d.pageY : l.pageY;
                if (l.preventedByNestedSwiper)
                    return r.startX = h,
                    void (r.startY = p);
                if (!this.allowTouchMove)
                    return this.allowClick = !1,
                    void (i.isTouched && (n.extend(r, {
                        startX: h,
                        startY: p,
                        currentX: h,
                        currentY: p
                    }),
                    i.touchStartTime = n.now()));
                if (i.isTouchEvent && a.touchReleaseOnEdges && !a.loop)
                    if (this.isVertical()) {
                        if (p < r.startY && this.translate <= this.maxTranslate() || p > r.startY && this.translate >= this.minTranslate())
                            return i.isTouched = !1,
                            void (i.isMoved = !1)
                    } else if (h < r.startX && this.translate <= this.maxTranslate() || h > r.startX && this.translate >= this.minTranslate())
                        return;
                if (i.isTouchEvent && e.activeElement && l.target === e.activeElement && s(l.target).is(i.formElements))
                    return i.isMoved = !0,
                    void (this.allowClick = !1);
                if (i.allowTouchCallbacks && this.emit("touchMove", l),
                !(l.targetTouches && l.targetTouches.length > 1)) {
                    r.currentX = h,
                    r.currentY = p;
                    var c = r.currentX - r.startX
                      , u = r.currentY - r.startY;
                    if (!(this.params.threshold && Math.sqrt(Math.pow(c, 2) + Math.pow(u, 2)) < this.params.threshold)) {
                        var v;
                        if (void 0 === i.isScrolling)
                            this.isHorizontal() && r.currentY === r.startY || this.isVertical() && r.currentX === r.startX ? i.isScrolling = !1 : c * c + u * u >= 25 && (v = 180 * Math.atan2(Math.abs(u), Math.abs(c)) / Math.PI,
                            i.isScrolling = this.isHorizontal() ? v > a.touchAngle : 90 - v > a.touchAngle);
                        if (i.isScrolling && this.emit("touchMoveOpposite", l),
                        void 0 === i.startMoving && (r.currentX === r.startX && r.currentY === r.startY || (i.startMoving = !0)),
                        i.isScrolling)
                            i.isTouched = !1;
                        else if (i.startMoving) {
                            this.allowClick = !1,
                            a.cssMode || l.preventDefault(),
                            a.touchMoveStopPropagation && !a.nested && l.stopPropagation(),
                            i.isMoved || (a.loop && this.loopFix(),
                            i.startTranslate = this.getTranslate(),
                            this.setTransition(0),
                            this.animating && this.$wrapperEl.trigger("webkitTransitionEnd transitionend"),
                            i.allowMomentumBounce = !1,
                            !a.grabCursor || !0 !== this.allowSlideNext && !0 !== this.allowSlidePrev || this.setGrabCursor(!0),
                            this.emit("sliderFirstMove", l)),
                            this.emit("sliderMove", l),
                            i.isMoved = !0;
                            var f = this.isHorizontal() ? c : u;
                            r.diff = f,
                            f *= a.touchRatio,
                            o && (f = -f),
                            this.swipeDirection = f > 0 ? "prev" : "next",
                            i.currentTranslate = f + i.startTranslate;
                            var m = !0
                              , g = a.resistanceRatio;
                            if (a.touchReleaseOnEdges && (g = 0),
                            f > 0 && i.currentTranslate > this.minTranslate() ? (m = !1,
                            a.resistance && (i.currentTranslate = this.minTranslate() - 1 + Math.pow(-this.minTranslate() + i.startTranslate + f, g))) : f < 0 && i.currentTranslate < this.maxTranslate() && (m = !1,
                            a.resistance && (i.currentTranslate = this.maxTranslate() + 1 - Math.pow(this.maxTranslate() - i.startTranslate - f, g))),
                            m && (l.preventedByNestedSwiper = !0),
                            !this.allowSlideNext && "next" === this.swipeDirection && i.currentTranslate < i.startTranslate && (i.currentTranslate = i.startTranslate),
                            !this.allowSlidePrev && "prev" === this.swipeDirection && i.currentTranslate > i.startTranslate && (i.currentTranslate = i.startTranslate),
                            a.threshold > 0) {
                                if (!(Math.abs(f) > a.threshold || i.allowThresholdMove))
                                    return void (i.currentTranslate = i.startTranslate);
                                if (!i.allowThresholdMove)
                                    return i.allowThresholdMove = !0,
                                    r.startX = r.currentX,
                                    r.startY = r.currentY,
                                    i.currentTranslate = i.startTranslate,
                                    void (r.diff = this.isHorizontal() ? r.currentX - r.startX : r.currentY - r.startY)
                            }
                            a.followFinger && !a.cssMode && ((a.freeMode || a.watchSlidesProgress || a.watchSlidesVisibility) && (this.updateActiveIndex(),
                            this.updateSlidesClasses()),
                            a.freeMode && (0 === i.velocities.length && i.velocities.push({
                                position: r[this.isHorizontal() ? "startX" : "startY"],
                                time: i.touchStartTime
                            }),
                            i.velocities.push({
                                position: r[this.isHorizontal() ? "currentX" : "currentY"],
                                time: n.now()
                            })),
                            this.updateProgress(i.currentTranslate),
                            this.setTranslate(i.currentTranslate))
                        }
                    }
                }
            }
        } else
            i.startMoving && i.isScrolling && this.emit("touchMoveOpposite", l)
    }
    function A(e) {
        var t = this
          , i = t.touchEventsData
          , s = t.params
          , a = t.touches
          , r = t.rtlTranslate
          , o = t.$wrapperEl
          , l = t.slidesGrid
          , d = t.snapGrid
          , h = e;
        if (h.originalEvent && (h = h.originalEvent),
        i.allowTouchCallbacks && t.emit("touchEnd", h),
        i.allowTouchCallbacks = !1,
        !i.isTouched)
            return i.isMoved && s.grabCursor && t.setGrabCursor(!1),
            i.isMoved = !1,
            void (i.startMoving = !1);
        s.grabCursor && i.isMoved && i.isTouched && (!0 === t.allowSlideNext || !0 === t.allowSlidePrev) && t.setGrabCursor(!1);
        var p, c = n.now(), u = c - i.touchStartTime;
        if (t.allowClick && (t.updateClickedSlide(h),
        t.emit("tap click", h),
        u < 300 && c - i.lastClickTime < 300 && t.emit("doubleTap doubleClick", h)),
        i.lastClickTime = n.now(),
        n.nextTick((function() {
            t.destroyed || (t.allowClick = !0)
        }
        )),
        !i.isTouched || !i.isMoved || !t.swipeDirection || 0 === a.diff || i.currentTranslate === i.startTranslate)
            return i.isTouched = !1,
            i.isMoved = !1,
            void (i.startMoving = !1);
        if (i.isTouched = !1,
        i.isMoved = !1,
        i.startMoving = !1,
        p = s.followFinger ? r ? t.translate : -t.translate : -i.currentTranslate,
        !s.cssMode)
            if (s.freeMode) {
                if (p < -t.minTranslate())
                    return void t.slideTo(t.activeIndex);
                if (p > -t.maxTranslate())
                    return void (t.slides.length < d.length ? t.slideTo(d.length - 1) : t.slideTo(t.slides.length - 1));
                if (s.freeModeMomentum) {
                    if (i.velocities.length > 1) {
                        var v = i.velocities.pop()
                          , f = i.velocities.pop()
                          , m = v.position - f.position
                          , g = v.time - f.time;
                        t.velocity = m / g,
                        t.velocity /= 2,
                        Math.abs(t.velocity) < s.freeModeMinimumVelocity && (t.velocity = 0),
                        (g > 150 || n.now() - v.time > 300) && (t.velocity = 0)
                    } else
                        t.velocity = 0;
                    t.velocity *= s.freeModeMomentumVelocityRatio,
                    i.velocities.length = 0;
                    var b = 1e3 * s.freeModeMomentumRatio
                      , w = t.velocity * b
                      , y = t.translate + w;
                    r && (y = -y);
                    var x, T, E = !1, S = 20 * Math.abs(t.velocity) * s.freeModeMomentumBounceRatio;
                    if (y < t.maxTranslate())
                        s.freeModeMomentumBounce ? (y + t.maxTranslate() < -S && (y = t.maxTranslate() - S),
                        x = t.maxTranslate(),
                        E = !0,
                        i.allowMomentumBounce = !0) : y = t.maxTranslate(),
                        s.loop && s.centeredSlides && (T = !0);
                    else if (y > t.minTranslate())
                        s.freeModeMomentumBounce ? (y - t.minTranslate() > S && (y = t.minTranslate() + S),
                        x = t.minTranslate(),
                        E = !0,
                        i.allowMomentumBounce = !0) : y = t.minTranslate(),
                        s.loop && s.centeredSlides && (T = !0);
                    else if (s.freeModeSticky) {
                        for (var C, M = 0; M < d.length; M += 1)
                            if (d[M] > -y) {
                                C = M;
                                break
                            }
                        y = -(y = Math.abs(d[C] - y) < Math.abs(d[C - 1] - y) || "next" === t.swipeDirection ? d[C] : d[C - 1])
                    }
                    if (T && t.once("transitionEnd", (function() {
                        t.loopFix()
                    }
                    )),
                    0 !== t.velocity) {
                        if (b = r ? Math.abs((-y - t.translate) / t.velocity) : Math.abs((y - t.translate) / t.velocity),
                        s.freeModeSticky) {
                            var P = Math.abs((r ? -y : y) - t.translate)
                              , z = t.slidesSizesGrid[t.activeIndex];
                            b = P < z ? s.speed : P < 2 * z ? 1.5 * s.speed : 2.5 * s.speed
                        }
                    } else if (s.freeModeSticky)
                        return void t.slideToClosest();
                    s.freeModeMomentumBounce && E ? (t.updateProgress(x),
                    t.setTransition(b),
                    t.setTranslate(y),
                    t.transitionStart(!0, t.swipeDirection),
                    t.animating = !0,
                    o.transitionEnd((function() {
                        t && !t.destroyed && i.allowMomentumBounce && (t.emit("momentumBounce"),
                        t.setTransition(s.speed),
                        t.setTranslate(x),
                        o.transitionEnd((function() {
                            t && !t.destroyed && t.transitionEnd()
                        }
                        )))
                    }
                    ))) : t.velocity ? (t.updateProgress(y),
                    t.setTransition(b),
                    t.setTranslate(y),
                    t.transitionStart(!0, t.swipeDirection),
                    t.animating || (t.animating = !0,
                    o.transitionEnd((function() {
                        t && !t.destroyed && t.transitionEnd()
                    }
                    )))) : t.updateProgress(y),
                    t.updateActiveIndex(),
                    t.updateSlidesClasses()
                } else if (s.freeModeSticky)
                    return void t.slideToClosest();
                (!s.freeModeMomentum || u >= s.longSwipesMs) && (t.updateProgress(),
                t.updateActiveIndex(),
                t.updateSlidesClasses())
            } else {
                for (var k = 0, $ = t.slidesSizesGrid[0], L = 0; L < l.length; L += L < s.slidesPerGroupSkip ? 1 : s.slidesPerGroup) {
                    var I = L < s.slidesPerGroupSkip - 1 ? 1 : s.slidesPerGroup;
                    void 0 !== l[L + I] ? p >= l[L] && p < l[L + I] && (k = L,
                    $ = l[L + I] - l[L]) : p >= l[L] && (k = L,
                    $ = l[l.length - 1] - l[l.length - 2])
                }
                var D = (p - l[k]) / $
                  , O = k < s.slidesPerGroupSkip - 1 ? 1 : s.slidesPerGroup;
                if (u > s.longSwipesMs) {
                    if (!s.longSwipes)
                        return void t.slideTo(t.activeIndex);
                    "next" === t.swipeDirection && (D >= s.longSwipesRatio ? t.slideTo(k + O) : t.slideTo(k)),
                    "prev" === t.swipeDirection && (D > 1 - s.longSwipesRatio ? t.slideTo(k + O) : t.slideTo(k))
                } else {
                    if (!s.shortSwipes)
                        return void t.slideTo(t.activeIndex);
                    t.navigation && (h.target === t.navigation.nextEl || h.target === t.navigation.prevEl) ? h.target === t.navigation.nextEl ? t.slideTo(k + O) : t.slideTo(k) : ("next" === t.swipeDirection && t.slideTo(k + O),
                    "prev" === t.swipeDirection && t.slideTo(k))
                }
            }
    }
    function G() {
        var e = this.params
          , t = this.el;
        if (!t || 0 !== t.offsetWidth) {
            e.breakpoints && this.setBreakpoint();
            var i = this.allowSlideNext
              , s = this.allowSlidePrev
              , a = this.snapGrid;
            this.allowSlideNext = !0,
            this.allowSlidePrev = !0,
            this.updateSize(),
            this.updateSlides(),
            this.updateSlidesClasses(),
            ("auto" === e.slidesPerView || e.slidesPerView > 1) && this.isEnd && !this.params.centeredSlides ? this.slideTo(this.slides.length - 1, 0, !1, !0) : this.slideTo(this.activeIndex, 0, !1, !0),
            this.autoplay && this.autoplay.running && this.autoplay.paused && this.autoplay.run(),
            this.allowSlidePrev = s,
            this.allowSlideNext = i,
            this.params.watchOverflow && a !== this.snapGrid && this.checkOverflow()
        }
    }
    function H(e) {
        this.allowClick || (this.params.preventClicks && e.preventDefault(),
        this.params.preventClicksPropagation && this.animating && (e.stopPropagation(),
        e.stopImmediatePropagation()))
    }
    function B() {
        var e = this.wrapperEl;
        this.previousTranslate = this.translate,
        this.translate = this.isHorizontal() ? -e.scrollLeft : -e.scrollTop,
        -0 === this.translate && (this.translate = 0),
        this.updateActiveIndex(),
        this.updateSlidesClasses();
        var t = this.maxTranslate() - this.minTranslate();
        (0 === t ? 0 : (this.translate - this.minTranslate()) / t) !== this.progress && this.updateProgress(this.translate),
        this.emit("setTranslate", this.translate, !1)
    }
    var N = !1;
    function X() {}
    var V = {
        init: !0,
        direction: "horizontal",
        touchEventsTarget: "container",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        preventInteractionOnTransition: !1,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        freeMode: !1,
        freeModeMomentum: !0,
        freeModeMomentumRatio: 1,
        freeModeMomentumBounce: !0,
        freeModeMomentumBounceRatio: 1,
        freeModeMomentumVelocityRatio: 1,
        freeModeSticky: !1,
        freeModeMinimumVelocity: .02,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerColumn: 1,
        slidesPerColumnFill: "column",
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !1,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 0,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        watchSlidesVisibility: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        preloadImages: !0,
        updateOnImagesReady: !0,
        loop: !1,
        loopAdditionalSlides: 0,
        loopedSlides: null,
        loopFillGroupWithBlank: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        containerModifierClass: "swiper-container-",
        slideClass: "swiper-slide",
        slideBlankClass: "swiper-slide-invisible-blank",
        slideActiveClass: "swiper-slide-active",
        slideDuplicateActiveClass: "swiper-slide-duplicate-active",
        slideVisibleClass: "swiper-slide-visible",
        slideDuplicateClass: "swiper-slide-duplicate",
        slideNextClass: "swiper-slide-next",
        slideDuplicateNextClass: "swiper-slide-duplicate-next",
        slidePrevClass: "swiper-slide-prev",
        slideDuplicatePrevClass: "swiper-slide-duplicate-prev",
        wrapperClass: "swiper-wrapper",
        runCallbacksOnInit: !0
    }
      , Y = {
        update: h,
        translate: p,
        transition: c,
        slide: u,
        loop: v,
        grabCursor: f,
        manipulation: L,
        events: {
            attachEvents: function() {
                var t = this.params
                  , i = this.touchEvents
                  , s = this.el
                  , a = this.wrapperEl;
                this.onTouchStart = D.bind(this),
                this.onTouchMove = O.bind(this),
                this.onTouchEnd = A.bind(this),
                t.cssMode && (this.onScroll = B.bind(this)),
                this.onClick = H.bind(this);
                var r = !!t.nested;
                if (!o.touch && o.pointerEvents)
                    s.addEventListener(i.start, this.onTouchStart, !1),
                    e.addEventListener(i.move, this.onTouchMove, r),
                    e.addEventListener(i.end, this.onTouchEnd, !1);
                else {
                    if (o.touch) {
                        var n = !("touchstart" !== i.start || !o.passiveListener || !t.passiveListeners) && {
                            passive: !0,
                            capture: !1
                        };
                        s.addEventListener(i.start, this.onTouchStart, n),
                        s.addEventListener(i.move, this.onTouchMove, o.passiveListener ? {
                            passive: !1,
                            capture: r
                        } : r),
                        s.addEventListener(i.end, this.onTouchEnd, n),
                        i.cancel && s.addEventListener(i.cancel, this.onTouchEnd, n),
                        N || (e.addEventListener("touchstart", X),
                        N = !0)
                    }
                    (t.simulateTouch && !I.ios && !I.android || t.simulateTouch && !o.touch && I.ios) && (s.addEventListener("mousedown", this.onTouchStart, !1),
                    e.addEventListener("mousemove", this.onTouchMove, r),
                    e.addEventListener("mouseup", this.onTouchEnd, !1))
                }
                (t.preventClicks || t.preventClicksPropagation) && s.addEventListener("click", this.onClick, !0),
                t.cssMode && a.addEventListener("scroll", this.onScroll),
                t.updateOnWindowResize ? this.on(I.ios || I.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", G, !0) : this.on("observerUpdate", G, !0)
            },
            detachEvents: function() {
                var t = this.params
                  , i = this.touchEvents
                  , s = this.el
                  , a = this.wrapperEl
                  , r = !!t.nested;
                if (!o.touch && o.pointerEvents)
                    s.removeEventListener(i.start, this.onTouchStart, !1),
                    e.removeEventListener(i.move, this.onTouchMove, r),
                    e.removeEventListener(i.end, this.onTouchEnd, !1);
                else {
                    if (o.touch) {
                        var n = !("onTouchStart" !== i.start || !o.passiveListener || !t.passiveListeners) && {
                            passive: !0,
                            capture: !1
                        };
                        s.removeEventListener(i.start, this.onTouchStart, n),
                        s.removeEventListener(i.move, this.onTouchMove, r),
                        s.removeEventListener(i.end, this.onTouchEnd, n),
                        i.cancel && s.removeEventListener(i.cancel, this.onTouchEnd, n)
                    }
                    (t.simulateTouch && !I.ios && !I.android || t.simulateTouch && !o.touch && I.ios) && (s.removeEventListener("mousedown", this.onTouchStart, !1),
                    e.removeEventListener("mousemove", this.onTouchMove, r),
                    e.removeEventListener("mouseup", this.onTouchEnd, !1))
                }
                (t.preventClicks || t.preventClicksPropagation) && s.removeEventListener("click", this.onClick, !0),
                t.cssMode && a.removeEventListener("scroll", this.onScroll),
                this.off(I.ios || I.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", G)
            }
        },
        breakpoints: {
            setBreakpoint: function() {
                var e = this.activeIndex
                  , t = this.initialized
                  , i = this.loopedSlides;
                void 0 === i && (i = 0);
                var s = this.params
                  , a = this.$el
                  , r = s.breakpoints;
                if (r && (!r || 0 !== Object.keys(r).length)) {
                    var o = this.getBreakpoint(r);
                    if (o && this.currentBreakpoint !== o) {
                        var l = o in r ? r[o] : void 0;
                        l && ["slidesPerView", "spaceBetween", "slidesPerGroup", "slidesPerGroupSkip", "slidesPerColumn"].forEach((function(e) {
                            var t = l[e];
                            void 0 !== t && (l[e] = "slidesPerView" !== e || "AUTO" !== t && "auto" !== t ? "slidesPerView" === e ? parseFloat(t) : parseInt(t, 10) : "auto")
                        }
                        ));
                        var d = l || this.originalParams
                          , h = s.slidesPerColumn > 1
                          , p = d.slidesPerColumn > 1;
                        h && !p ? a.removeClass(s.containerModifierClass + "multirow " + s.containerModifierClass + "multirow-column") : !h && p && (a.addClass(s.containerModifierClass + "multirow"),
                        "column" === d.slidesPerColumnFill && a.addClass(s.containerModifierClass + "multirow-column"));
                        var c = d.direction && d.direction !== s.direction
                          , u = s.loop && (d.slidesPerView !== s.slidesPerView || c);
                        c && t && this.changeDirection(),
                        n.extend(this.params, d),
                        n.extend(this, {
                            allowTouchMove: this.params.allowTouchMove,
                            allowSlideNext: this.params.allowSlideNext,
                            allowSlidePrev: this.params.allowSlidePrev
                        }),
                        this.currentBreakpoint = o,
                        u && t && (this.loopDestroy(),
                        this.loopCreate(),
                        this.updateSlides(),
                        this.slideTo(e - i + this.loopedSlides, 0, !1)),
                        this.emit("breakpoint", d)
                    }
                }
            },
            getBreakpoint: function(e) {
                if (e) {
                    var i = !1
                      , s = Object.keys(e).map((function(e) {
                        if ("string" == typeof e && 0 === e.indexOf("@")) {
                            var i = parseFloat(e.substr(1));
                            return {
                                value: t.innerHeight * i,
                                point: e
                            }
                        }
                        return {
                            value: e,
                            point: e
                        }
                    }
                    ));
                    s.sort((function(e, t) {
                        return parseInt(e.value, 10) - parseInt(t.value, 10)
                    }
                    ));
                    for (var a = 0; a < s.length; a += 1) {
                        var r = s[a]
                          , n = r.point;
                        r.value <= t.innerWidth && (i = n)
                    }
                    return i || "max"
                }
            }
        },
        checkOverflow: {
            checkOverflow: function() {
                var e = this.params
                  , t = this.isLocked
                  , i = this.slides.length > 0 && e.slidesOffsetBefore + e.spaceBetween * (this.slides.length - 1) + this.slides[0].offsetWidth * this.slides.length;
                e.slidesOffsetBefore && e.slidesOffsetAfter && i ? this.isLocked = i <= this.size : this.isLocked = 1 === this.snapGrid.length,
                this.allowSlideNext = !this.isLocked,
                this.allowSlidePrev = !this.isLocked,
                t !== this.isLocked && this.emit(this.isLocked ? "lock" : "unlock"),
                t && t !== this.isLocked && (this.isEnd = !1,
                this.navigation.update())
            }
        },
        classes: {
            addClasses: function() {
                var e = this.classNames
                  , t = this.params
                  , i = this.rtl
                  , s = this.$el
                  , a = [];
                a.push("initialized"),
                a.push(t.direction),
                t.freeMode && a.push("free-mode"),
                t.autoHeight && a.push("autoheight"),
                i && a.push("rtl"),
                t.slidesPerColumn > 1 && (a.push("multirow"),
                "column" === t.slidesPerColumnFill && a.push("multirow-column")),
                I.android && a.push("android"),
                I.ios && a.push("ios"),
                t.cssMode && a.push("css-mode"),
                a.forEach((function(i) {
                    e.push(t.containerModifierClass + i)
                }
                )),
                s.addClass(e.join(" "))
            },
            removeClasses: function() {
                var e = this.$el
                  , t = this.classNames;
                e.removeClass(t.join(" "))
            }
        },
        images: {
            loadImage: function(e, i, s, a, r, n) {
                var o;
                function l() {
                    n && n()
                }
                e.complete && r ? l() : i ? ((o = new t.Image).onload = l,
                o.onerror = l,
                a && (o.sizes = a),
                s && (o.srcset = s),
                i && (o.src = i)) : l()
            },
            preloadImages: function() {
                var e = this;
                function t() {
                    null != e && e && !e.destroyed && (void 0 !== e.imagesLoaded && (e.imagesLoaded += 1),
                    e.imagesLoaded === e.imagesToLoad.length && (e.params.updateOnImagesReady && e.update(),
                    e.emit("imagesReady")))
                }
                e.imagesToLoad = e.$el.find("img");
                for (var i = 0; i < e.imagesToLoad.length; i += 1) {
                    var s = e.imagesToLoad[i];
                    e.loadImage(s, s.currentSrc || s.getAttribute("src"), s.srcset || s.getAttribute("srcset"), s.sizes || s.getAttribute("sizes"), !0, t)
                }
            }
        }
    }
      , F = {}
      , W = function(e) {
        function t() {
            for (var i, a, r, l = [], d = arguments.length; d--; )
                l[d] = arguments[d];
            1 === l.length && l[0].constructor && l[0].constructor === Object ? r = l[0] : (a = (i = l)[0],
            r = i[1]),
            r || (r = {}),
            r = n.extend({}, r),
            a && !r.el && (r.el = a),
            e.call(this, r),
            Object.keys(Y).forEach((function(e) {
                Object.keys(Y[e]).forEach((function(i) {
                    t.prototype[i] || (t.prototype[i] = Y[e][i])
                }
                ))
            }
            ));
            var h = this;
            void 0 === h.modules && (h.modules = {}),
            Object.keys(h.modules).forEach((function(e) {
                var t = h.modules[e];
                if (t.params) {
                    var i = Object.keys(t.params)[0]
                      , s = t.params[i];
                    if ("object" != typeof s || null === s)
                        return;
                    if (!(i in r && "enabled"in s))
                        return;
                    !0 === r[i] && (r[i] = {
                        enabled: !0
                    }),
                    "object" != typeof r[i] || "enabled"in r[i] || (r[i].enabled = !0),
                    r[i] || (r[i] = {
                        enabled: !1
                    })
                }
            }
            ));
            var p = n.extend({}, V);
            h.useModulesParams(p),
            h.params = n.extend({}, p, F, r),
            h.originalParams = n.extend({}, h.params),
            h.passedParams = n.extend({}, r),
            h.$ = s;
            var c = s(h.params.el);
            if (a = c[0]) {
                if (c.length > 1) {
                    var u = [];
                    return c.each((function(e, i) {
                        var s = n.extend({}, r, {
                            el: i
                        });
                        u.push(new t(s))
                    }
                    )),
                    u
                }
                var v, f, m;
                return a.swiper = h,
                c.data("swiper", h),
                a && a.shadowRoot && a.shadowRoot.querySelector ? (v = s(a.shadowRoot.querySelector("." + h.params.wrapperClass))).children = function(e) {
                    return c.children(e)
                }
                : v = c.children("." + h.params.wrapperClass),
                n.extend(h, {
                    $el: c,
                    el: a,
                    $wrapperEl: v,
                    wrapperEl: v[0],
                    classNames: [],
                    slides: s(),
                    slidesGrid: [],
                    snapGrid: [],
                    slidesSizesGrid: [],
                    isHorizontal: function() {
                        return "horizontal" === h.params.direction
                    },
                    isVertical: function() {
                        return "vertical" === h.params.direction
                    },
                    rtl: "rtl" === a.dir.toLowerCase() || "rtl" === c.css("direction"),
                    rtlTranslate: "horizontal" === h.params.direction && ("rtl" === a.dir.toLowerCase() || "rtl" === c.css("direction")),
                    wrongRTL: "-webkit-box" === v.css("display"),
                    activeIndex: 0,
                    realIndex: 0,
                    isBeginning: !0,
                    isEnd: !1,
                    translate: 0,
                    previousTranslate: 0,
                    progress: 0,
                    velocity: 0,
                    animating: !1,
                    allowSlideNext: h.params.allowSlideNext,
                    allowSlidePrev: h.params.allowSlidePrev,
                    touchEvents: (f = ["touchstart", "touchmove", "touchend", "touchcancel"],
                    m = ["mousedown", "mousemove", "mouseup"],
                    o.pointerEvents && (m = ["pointerdown", "pointermove", "pointerup"]),
                    h.touchEventsTouch = {
                        start: f[0],
                        move: f[1],
                        end: f[2],
                        cancel: f[3]
                    },
                    h.touchEventsDesktop = {
                        start: m[0],
                        move: m[1],
                        end: m[2]
                    },
                    o.touch || !h.params.simulateTouch ? h.touchEventsTouch : h.touchEventsDesktop),
                    touchEventsData: {
                        isTouched: void 0,
                        isMoved: void 0,
                        allowTouchCallbacks: void 0,
                        touchStartTime: void 0,
                        isScrolling: void 0,
                        currentTranslate: void 0,
                        startTranslate: void 0,
                        allowThresholdMove: void 0,
                        formElements: "input, select, option, textarea, button, video, label",
                        lastClickTime: n.now(),
                        clickTimeout: void 0,
                        velocities: [],
                        allowMomentumBounce: void 0,
                        isTouchEvent: void 0,
                        startMoving: void 0
                    },
                    allowClick: !0,
                    allowTouchMove: h.params.allowTouchMove,
                    touches: {
                        startX: 0,
                        startY: 0,
                        currentX: 0,
                        currentY: 0,
                        diff: 0
                    },
                    imagesToLoad: [],
                    imagesLoaded: 0
                }),
                h.useModules(),
                h.params.init && h.init(),
                h
            }
        }
        e && (t.__proto__ = e),
        t.prototype = Object.create(e && e.prototype),
        t.prototype.constructor = t;
        var i = {
            extendedDefaults: {
                configurable: !0
            },
            defaults: {
                configurable: !0
            },
            Class: {
                configurable: !0
            },
            $: {
                configurable: !0
            }
        };
        return t.prototype.slidesPerViewDynamic = function() {
            var e = this.params
              , t = this.slides
              , i = this.slidesGrid
              , s = this.size
              , a = this.activeIndex
              , r = 1;
            if (e.centeredSlides) {
                for (var n, o = t[a].swiperSlideSize, l = a + 1; l < t.length; l += 1)
                    t[l] && !n && (r += 1,
                    (o += t[l].swiperSlideSize) > s && (n = !0));
                for (var d = a - 1; d >= 0; d -= 1)
                    t[d] && !n && (r += 1,
                    (o += t[d].swiperSlideSize) > s && (n = !0))
            } else
                for (var h = a + 1; h < t.length; h += 1)
                    i[h] - i[a] < s && (r += 1);
            return r
        }
        ,
        t.prototype.update = function() {
            var e = this;
            if (e && !e.destroyed) {
                var t = e.snapGrid
                  , i = e.params;
                i.breakpoints && e.setBreakpoint(),
                e.updateSize(),
                e.updateSlides(),
                e.updateProgress(),
                e.updateSlidesClasses(),
                e.params.freeMode ? (s(),
                e.params.autoHeight && e.updateAutoHeight()) : (("auto" === e.params.slidesPerView || e.params.slidesPerView > 1) && e.isEnd && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0)) || s(),
                i.watchOverflow && t !== e.snapGrid && e.checkOverflow(),
                e.emit("update")
            }
            function s() {
                var t = e.rtlTranslate ? -1 * e.translate : e.translate
                  , i = Math.min(Math.max(t, e.maxTranslate()), e.minTranslate());
                e.setTranslate(i),
                e.updateActiveIndex(),
                e.updateSlidesClasses()
            }
        }
        ,
        t.prototype.changeDirection = function(e, t) {
            void 0 === t && (t = !0);
            var i = this.params.direction;
            return e || (e = "horizontal" === i ? "vertical" : "horizontal"),
            e === i || "horizontal" !== e && "vertical" !== e ? this : (this.$el.removeClass("" + this.params.containerModifierClass + i).addClass("" + this.params.containerModifierClass + e),
            this.params.direction = e,
            this.slides.each((function(t, i) {
                "vertical" === e ? i.style.width = "" : i.style.height = ""
            }
            )),
            this.emit("changeDirection"),
            t && this.update(),
            this)
        }
        ,
        t.prototype.init = function() {
            this.initialized || (this.emit("beforeInit"),
            this.params.breakpoints && this.setBreakpoint(),
            this.addClasses(),
            this.params.loop && this.loopCreate(),
            this.updateSize(),
            this.updateSlides(),
            this.params.watchOverflow && this.checkOverflow(),
            this.params.grabCursor && this.setGrabCursor(),
            this.params.preloadImages && this.preloadImages(),
            this.params.loop ? this.slideTo(this.params.initialSlide + this.loopedSlides, 0, this.params.runCallbacksOnInit) : this.slideTo(this.params.initialSlide, 0, this.params.runCallbacksOnInit),
            this.attachEvents(),
            this.initialized = !0,
            this.emit("init"))
        }
        ,
        t.prototype.destroy = function(e, t) {
            void 0 === e && (e = !0),
            void 0 === t && (t = !0);
            var i = this
              , s = i.params
              , a = i.$el
              , r = i.$wrapperEl
              , o = i.slides;
            return void 0 === i.params || i.destroyed ? null : (i.emit("beforeDestroy"),
            i.initialized = !1,
            i.detachEvents(),
            s.loop && i.loopDestroy(),
            t && (i.removeClasses(),
            a.removeAttr("style"),
            r.removeAttr("style"),
            o && o.length && o.removeClass([s.slideVisibleClass, s.slideActiveClass, s.slideNextClass, s.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-slide-index")),
            i.emit("destroy"),
            Object.keys(i.eventsListeners).forEach((function(e) {
                i.off(e)
            }
            )),
            !1 !== e && (i.$el[0].swiper = null,
            i.$el.data("swiper", null),
            n.deleteProps(i)),
            i.destroyed = !0,
            null)
        }
        ,
        t.extendDefaults = function(e) {
            n.extend(F, e)
        }
        ,
        i.extendedDefaults.get = function() {
            return F
        }
        ,
        i.defaults.get = function() {
            return V
        }
        ,
        i.Class.get = function() {
            return e
        }
        ,
        i.$.get = function() {
            return s
        }
        ,
        Object.defineProperties(t, i),
        t
    }(l)
      , R = {
        name: "device",
        proto: {
            device: I
        },
        static: {
            device: I
        }
    }
      , q = {
        name: "support",
        proto: {
            support: o
        },
        static: {
            support: o
        }
    }
      , j = {
        isEdge: !!t.navigator.userAgent.match(/Edge/g),
        isSafari: function() {
            var e = t.navigator.userAgent.toLowerCase();
            return e.indexOf("safari") >= 0 && e.indexOf("chrome") < 0 && e.indexOf("android") < 0
        }(),
        isUiWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(t.navigator.userAgent)
    }
      , K = {
        name: "browser",
        proto: {
            browser: j
        },
        static: {
            browser: j
        }
    }
      , U = {
        name: "resize",
        create: function() {
            var e = this;
            n.extend(e, {
                resize: {
                    resizeHandler: function() {
                        e && !e.destroyed && e.initialized && (e.emit("beforeResize"),
                        e.emit("resize"))
                    },
                    orientationChangeHandler: function() {
                        e && !e.destroyed && e.initialized && e.emit("orientationchange")
                    }
                }
            })
        },
        on: {
            init: function() {
                t.addEventListener("resize", this.resize.resizeHandler),
                t.addEventListener("orientationchange", this.resize.orientationChangeHandler)
            },
            destroy: function() {
                t.removeEventListener("resize", this.resize.resizeHandler),
                t.removeEventListener("orientationchange", this.resize.orientationChangeHandler)
            }
        }
    }
      , _ = {
        func: t.MutationObserver || t.WebkitMutationObserver,
        attach: function(e, i) {
            void 0 === i && (i = {});
            var s = this
              , a = new (0,
            _.func)((function(e) {
                if (1 !== e.length) {
                    var i = function() {
                        s.emit("observerUpdate", e[0])
                    };
                    t.requestAnimationFrame ? t.requestAnimationFrame(i) : t.setTimeout(i, 0)
                } else
                    s.emit("observerUpdate", e[0])
            }
            ));
            a.observe(e, {
                attributes: void 0 === i.attributes || i.attributes,
                childList: void 0 === i.childList || i.childList,
                characterData: void 0 === i.characterData || i.characterData
            }),
            s.observer.observers.push(a)
        },
        init: function() {
            if (o.observer && this.params.observer) {
                if (this.params.observeParents)
                    for (var e = this.$el.parents(), t = 0; t < e.length; t += 1)
                        this.observer.attach(e[t]);
                this.observer.attach(this.$el[0], {
                    childList: this.params.observeSlideChildren
                }),
                this.observer.attach(this.$wrapperEl[0], {
                    attributes: !1
                })
            }
        },
        destroy: function() {
            this.observer.observers.forEach((function(e) {
                e.disconnect()
            }
            )),
            this.observer.observers = []
        }
    }
      , Z = {
        name: "observer",
        params: {
            observer: !1,
            observeParents: !1,
            observeSlideChildren: !1
        },
        create: function() {
            n.extend(this, {
                observer: {
                    init: _.init.bind(this),
                    attach: _.attach.bind(this),
                    destroy: _.destroy.bind(this),
                    observers: []
                }
            })
        },
        on: {
            init: function() {
                this.observer.init()
            },
            destroy: function() {
                this.observer.destroy()
            }
        }
    }
      , Q = {
        update: function(e) {
            var t = this
              , i = t.params
              , s = i.slidesPerView
              , a = i.slidesPerGroup
              , r = i.centeredSlides
              , o = t.params.virtual
              , l = o.addSlidesBefore
              , d = o.addSlidesAfter
              , h = t.virtual
              , p = h.from
              , c = h.to
              , u = h.slides
              , v = h.slidesGrid
              , f = h.renderSlide
              , m = h.offset;
            t.updateActiveIndex();
            var g, b, w, y = t.activeIndex || 0;
            g = t.rtlTranslate ? "right" : t.isHorizontal() ? "left" : "top",
            r ? (b = Math.floor(s / 2) + a + l,
            w = Math.floor(s / 2) + a + d) : (b = s + (a - 1) + l,
            w = a + d);
            var x = Math.max((y || 0) - w, 0)
              , T = Math.min((y || 0) + b, u.length - 1)
              , E = (t.slidesGrid[x] || 0) - (t.slidesGrid[0] || 0);
            function S() {
                t.updateSlides(),
                t.updateProgress(),
                t.updateSlidesClasses(),
                t.lazy && t.params.lazy.enabled && t.lazy.load()
            }
            if (n.extend(t.virtual, {
                from: x,
                to: T,
                offset: E,
                slidesGrid: t.slidesGrid
            }),
            p === x && c === T && !e)
                return t.slidesGrid !== v && E !== m && t.slides.css(g, E + "px"),
                void t.updateProgress();
            if (t.params.virtual.renderExternal)
                return t.params.virtual.renderExternal.call(t, {
                    offset: E,
                    from: x,
                    to: T,
                    slides: function() {
                        for (var e = [], t = x; t <= T; t += 1)
                            e.push(u[t]);
                        return e
                    }()
                }),
                void S();
            var C = []
              , M = [];
            if (e)
                t.$wrapperEl.find("." + t.params.slideClass).remove();
            else
                for (var P = p; P <= c; P += 1)
                    (P < x || P > T) && t.$wrapperEl.find("." + t.params.slideClass + '[data-swiper-slide-index="' + P + '"]').remove();
            for (var z = 0; z < u.length; z += 1)
                z >= x && z <= T && (void 0 === c || e ? M.push(z) : (z > c && M.push(z),
                z < p && C.push(z)));
            M.forEach((function(e) {
                t.$wrapperEl.append(f(u[e], e))
            }
            )),
            C.sort((function(e, t) {
                return t - e
            }
            )).forEach((function(e) {
                t.$wrapperEl.prepend(f(u[e], e))
            }
            )),
            t.$wrapperEl.children(".swiper-slide").css(g, E + "px"),
            S()
        },
        renderSlide: function(e, t) {
            var i = this.params.virtual;
            if (i.cache && this.virtual.cache[t])
                return this.virtual.cache[t];
            var a = i.renderSlide ? s(i.renderSlide.call(this, e, t)) : s('<div class="' + this.params.slideClass + '" data-swiper-slide-index="' + t + '">' + e + "</div>");
            return a.attr("data-swiper-slide-index") || a.attr("data-swiper-slide-index", t),
            i.cache && (this.virtual.cache[t] = a),
            a
        },
        appendSlide: function(e) {
            if ("object" == typeof e && "length"in e)
                for (var t = 0; t < e.length; t += 1)
                    e[t] && this.virtual.slides.push(e[t]);
            else
                this.virtual.slides.push(e);
            this.virtual.update(!0)
        },
        prependSlide: function(e) {
            var t = this.activeIndex
              , i = t + 1
              , s = 1;
            if (Array.isArray(e)) {
                for (var a = 0; a < e.length; a += 1)
                    e[a] && this.virtual.slides.unshift(e[a]);
                i = t + e.length,
                s = e.length
            } else
                this.virtual.slides.unshift(e);
            if (this.params.virtual.cache) {
                var r = this.virtual.cache
                  , n = {};
                Object.keys(r).forEach((function(e) {
                    var t = r[e]
                      , i = t.attr("data-swiper-slide-index");
                    i && t.attr("data-swiper-slide-index", parseInt(i, 10) + 1),
                    n[parseInt(e, 10) + s] = t
                }
                )),
                this.virtual.cache = n
            }
            this.virtual.update(!0),
            this.slideTo(i, 0)
        },
        removeSlide: function(e) {
            if (null != e) {
                var t = this.activeIndex;
                if (Array.isArray(e))
                    for (var i = e.length - 1; i >= 0; i -= 1)
                        this.virtual.slides.splice(e[i], 1),
                        this.params.virtual.cache && delete this.virtual.cache[e[i]],
                        e[i] < t && (t -= 1),
                        t = Math.max(t, 0);
                else
                    this.virtual.slides.splice(e, 1),
                    this.params.virtual.cache && delete this.virtual.cache[e],
                    e < t && (t -= 1),
                    t = Math.max(t, 0);
                this.virtual.update(!0),
                this.slideTo(t, 0)
            }
        },
        removeAllSlides: function() {
            this.virtual.slides = [],
            this.params.virtual.cache && (this.virtual.cache = {}),
            this.virtual.update(!0),
            this.slideTo(0, 0)
        }
    }
      , J = {
        name: "virtual",
        params: {
            virtual: {
                enabled: !1,
                slides: [],
                cache: !0,
                renderSlide: null,
                renderExternal: null,
                addSlidesBefore: 0,
                addSlidesAfter: 0
            }
        },
        create: function() {
            n.extend(this, {
                virtual: {
                    update: Q.update.bind(this),
                    appendSlide: Q.appendSlide.bind(this),
                    prependSlide: Q.prependSlide.bind(this),
                    removeSlide: Q.removeSlide.bind(this),
                    removeAllSlides: Q.removeAllSlides.bind(this),
                    renderSlide: Q.renderSlide.bind(this),
                    slides: this.params.virtual.slides,
                    cache: {}
                }
            })
        },
        on: {
            beforeInit: function() {
                if (this.params.virtual.enabled) {
                    this.classNames.push(this.params.containerModifierClass + "virtual");
                    var e = {
                        watchSlidesProgress: !0
                    };
                    n.extend(this.params, e),
                    n.extend(this.originalParams, e),
                    this.params.initialSlide || this.virtual.update()
                }
            },
            setTranslate: function() {
                this.params.virtual.enabled && this.virtual.update()
            }
        }
    }
      , ee = {
        handle: function(i) {
            var s = this.rtlTranslate
              , a = i;
            a.originalEvent && (a = a.originalEvent);
            var r = a.keyCode || a.charCode;
            if (!this.allowSlideNext && (this.isHorizontal() && 39 === r || this.isVertical() && 40 === r || 34 === r))
                return !1;
            if (!this.allowSlidePrev && (this.isHorizontal() && 37 === r || this.isVertical() && 38 === r || 33 === r))
                return !1;
            if (!(a.shiftKey || a.altKey || a.ctrlKey || a.metaKey || e.activeElement && e.activeElement.nodeName && ("input" === e.activeElement.nodeName.toLowerCase() || "textarea" === e.activeElement.nodeName.toLowerCase()))) {
                if (this.params.keyboard.onlyInViewport && (33 === r || 34 === r || 37 === r || 39 === r || 38 === r || 40 === r)) {
                    var n = !1;
                    if (this.$el.parents("." + this.params.slideClass).length > 0 && 0 === this.$el.parents("." + this.params.slideActiveClass).length)
                        return;
                    var o = t.innerWidth
                      , l = t.innerHeight
                      , d = this.$el.offset();
                    s && (d.left -= this.$el[0].scrollLeft);
                    for (var h = [[d.left, d.top], [d.left + this.width, d.top], [d.left, d.top + this.height], [d.left + this.width, d.top + this.height]], p = 0; p < h.length; p += 1) {
                        var c = h[p];
                        c[0] >= 0 && c[0] <= o && c[1] >= 0 && c[1] <= l && (n = !0)
                    }
                    if (!n)
                        return
                }
                this.isHorizontal() ? (33 !== r && 34 !== r && 37 !== r && 39 !== r || (a.preventDefault ? a.preventDefault() : a.returnValue = !1),
                (34 !== r && 39 !== r || s) && (33 !== r && 37 !== r || !s) || this.slideNext(),
                (33 !== r && 37 !== r || s) && (34 !== r && 39 !== r || !s) || this.slidePrev()) : (33 !== r && 34 !== r && 38 !== r && 40 !== r || (a.preventDefault ? a.preventDefault() : a.returnValue = !1),
                34 !== r && 40 !== r || this.slideNext(),
                33 !== r && 38 !== r || this.slidePrev()),
                this.emit("keyPress", r)
            }
        },
        enable: function() {
            this.keyboard.enabled || (s(e).on("keydown", this.keyboard.handle),
            this.keyboard.enabled = !0)
        },
        disable: function() {
            this.keyboard.enabled && (s(e).off("keydown", this.keyboard.handle),
            this.keyboard.enabled = !1)
        }
    }
      , te = {
        name: "keyboard",
        params: {
            keyboard: {
                enabled: !1,
                onlyInViewport: !0
            }
        },
        create: function() {
            n.extend(this, {
                keyboard: {
                    enabled: !1,
                    enable: ee.enable.bind(this),
                    disable: ee.disable.bind(this),
                    handle: ee.handle.bind(this)
                }
            })
        },
        on: {
            init: function() {
                this.params.keyboard.enabled && this.keyboard.enable()
            },
            destroy: function() {
                this.keyboard.enabled && this.keyboard.disable()
            }
        }
    };
    var ie = {
        lastScrollTime: n.now(),
        lastEventBeforeSnap: void 0,
        recentWheelEvents: [],
        event: function() {
            return t.navigator.userAgent.indexOf("firefox") > -1 ? "DOMMouseScroll" : function() {
                var t = "onwheel"in e;
                if (!t) {
                    var i = e.createElement("div");
                    i.setAttribute("onwheel", "return;"),
                    t = "function" == typeof i.onwheel
                }
                return !t && e.implementation && e.implementation.hasFeature && !0 !== e.implementation.hasFeature("", "") && (t = e.implementation.hasFeature("Events.wheel", "3.0")),
                t
            }() ? "wheel" : "mousewheel"
        },
        normalize: function(e) {
            var t = 0
              , i = 0
              , s = 0
              , a = 0;
            return "detail"in e && (i = e.detail),
            "wheelDelta"in e && (i = -e.wheelDelta / 120),
            "wheelDeltaY"in e && (i = -e.wheelDeltaY / 120),
            "wheelDeltaX"in e && (t = -e.wheelDeltaX / 120),
            "axis"in e && e.axis === e.HORIZONTAL_AXIS && (t = i,
            i = 0),
            s = 10 * t,
            a = 10 * i,
            "deltaY"in e && (a = e.deltaY),
            "deltaX"in e && (s = e.deltaX),
            e.shiftKey && !s && (s = a,
            a = 0),
            (s || a) && e.deltaMode && (1 === e.deltaMode ? (s *= 40,
            a *= 40) : (s *= 800,
            a *= 800)),
            s && !t && (t = s < 1 ? -1 : 1),
            a && !i && (i = a < 1 ? -1 : 1),
            {
                spinX: t,
                spinY: i,
                pixelX: s,
                pixelY: a
            }
        },
        handleMouseEnter: function() {
            this.mouseEntered = !0
        },
        handleMouseLeave: function() {
            this.mouseEntered = !1
        },
        handle: function(e) {
            var t = e
              , i = this
              , a = i.params.mousewheel;
            i.params.cssMode && t.preventDefault();
            var r = i.$el;
            if ("container" !== i.params.mousewheel.eventsTarged && (r = s(i.params.mousewheel.eventsTarged)),
            !i.mouseEntered && !r[0].contains(t.target) && !a.releaseOnEdges)
                return !0;
            t.originalEvent && (t = t.originalEvent);
            var o = 0
              , l = i.rtlTranslate ? -1 : 1
              , d = ie.normalize(t);
            if (a.forceToAxis)
                if (i.isHorizontal()) {
                    if (!(Math.abs(d.pixelX) > Math.abs(d.pixelY)))
                        return !0;
                    o = d.pixelX * l
                } else {
                    if (!(Math.abs(d.pixelY) > Math.abs(d.pixelX)))
                        return !0;
                    o = d.pixelY
                }
            else
                o = Math.abs(d.pixelX) > Math.abs(d.pixelY) ? -d.pixelX * l : -d.pixelY;
            if (0 === o)
                return !0;
            if (a.invert && (o = -o),
            i.params.freeMode) {
                var h = {
                    time: n.now(),
                    delta: Math.abs(o),
                    direction: Math.sign(o)
                }
                  , p = i.mousewheel.lastEventBeforeSnap
                  , c = p && h.time < p.time + 500 && h.delta <= p.delta && h.direction === p.direction;
                if (!c) {
                    i.mousewheel.lastEventBeforeSnap = void 0,
                    i.params.loop && i.loopFix();
                    var u = i.getTranslate() + o * a.sensitivity
                      , v = i.isBeginning
                      , f = i.isEnd;
                    if (u >= i.minTranslate() && (u = i.minTranslate()),
                    u <= i.maxTranslate() && (u = i.maxTranslate()),
                    i.setTransition(0),
                    i.setTranslate(u),
                    i.updateProgress(),
                    i.updateActiveIndex(),
                    i.updateSlidesClasses(),
                    (!v && i.isBeginning || !f && i.isEnd) && i.updateSlidesClasses(),
                    i.params.freeModeSticky) {
                        clearTimeout(i.mousewheel.timeout),
                        i.mousewheel.timeout = void 0;
                        var m = i.mousewheel.recentWheelEvents;
                        m.length >= 15 && m.shift();
                        var g = m.length ? m[m.length - 1] : void 0
                          , b = m[0];
                        if (m.push(h),
                        g && (h.delta > g.delta || h.direction !== g.direction))
                            m.splice(0);
                        else if (m.length >= 15 && h.time - b.time < 500 && b.delta - h.delta >= 1 && h.delta <= 6) {
                            var w = o > 0 ? .8 : .2;
                            i.mousewheel.lastEventBeforeSnap = h,
                            m.splice(0),
                            i.mousewheel.timeout = n.nextTick((function() {
                                i.slideToClosest(i.params.speed, !0, void 0, w)
                            }
                            ), 0)
                        }
                        i.mousewheel.timeout || (i.mousewheel.timeout = n.nextTick((function() {
                            i.mousewheel.lastEventBeforeSnap = h,
                            m.splice(0),
                            i.slideToClosest(i.params.speed, !0, void 0, .5)
                        }
                        ), 500))
                    }
                    if (c || i.emit("scroll", t),
                    i.params.autoplay && i.params.autoplayDisableOnInteraction && i.autoplay.stop(),
                    u === i.minTranslate() || u === i.maxTranslate())
                        return !0
                }
            } else {
                var y = {
                    time: n.now(),
                    delta: Math.abs(o),
                    direction: Math.sign(o),
                    raw: e
                }
                  , x = i.mousewheel.recentWheelEvents;
                x.length >= 2 && x.shift();
                var T = x.length ? x[x.length - 1] : void 0;
                if (x.push(y),
                T ? (y.direction !== T.direction || y.delta > T.delta) && i.mousewheel.animateSlider(y) : i.mousewheel.animateSlider(y),
                i.mousewheel.releaseScroll(y))
                    return !0
            }
            return t.preventDefault ? t.preventDefault() : t.returnValue = !1,
            !1
        },
        animateSlider: function(e) {
            return e.delta >= 6 && n.now() - this.mousewheel.lastScrollTime < 60 || (e.direction < 0 ? this.isEnd && !this.params.loop || this.animating || (this.slideNext(),
            this.emit("scroll", e.raw)) : this.isBeginning && !this.params.loop || this.animating || (this.slidePrev(),
            this.emit("scroll", e.raw)),
            this.mousewheel.lastScrollTime = (new t.Date).getTime(),
            !1)
        },
        releaseScroll: function(e) {
            var t = this.params.mousewheel;
            if (e.direction < 0) {
                if (this.isEnd && !this.params.loop && t.releaseOnEdges)
                    return !0
            } else if (this.isBeginning && !this.params.loop && t.releaseOnEdges)
                return !0;
            return !1
        },
        enable: function() {
            var e = ie.event();
            if (this.params.cssMode)
                return this.wrapperEl.removeEventListener(e, this.mousewheel.handle),
                !0;
            if (!e)
                return !1;
            if (this.mousewheel.enabled)
                return !1;
            var t = this.$el;
            return "container" !== this.params.mousewheel.eventsTarged && (t = s(this.params.mousewheel.eventsTarged)),
            t.on("mouseenter", this.mousewheel.handleMouseEnter),
            t.on("mouseleave", this.mousewheel.handleMouseLeave),
            t.on(e, this.mousewheel.handle),
            this.mousewheel.enabled = !0,
            !0
        },
        disable: function() {
            var e = ie.event();
            if (this.params.cssMode)
                return this.wrapperEl.addEventListener(e, this.mousewheel.handle),
                !0;
            if (!e)
                return !1;
            if (!this.mousewheel.enabled)
                return !1;
            var t = this.$el;
            return "container" !== this.params.mousewheel.eventsTarged && (t = s(this.params.mousewheel.eventsTarged)),
            t.off(e, this.mousewheel.handle),
            this.mousewheel.enabled = !1,
            !0
        }
    }
      , se = {
        update: function() {
            var e = this.params.navigation;
            if (!this.params.loop) {
                var t = this.navigation
                  , i = t.$nextEl
                  , s = t.$prevEl;
                s && s.length > 0 && (this.isBeginning ? s.addClass(e.disabledClass) : s.removeClass(e.disabledClass),
                s[this.params.watchOverflow && this.isLocked ? "addClass" : "removeClass"](e.lockClass)),
                i && i.length > 0 && (this.isEnd ? i.addClass(e.disabledClass) : i.removeClass(e.disabledClass),
                i[this.params.watchOverflow && this.isLocked ? "addClass" : "removeClass"](e.lockClass))
            }
        },
        onPrevClick: function(e) {
            e.preventDefault(),
            this.isBeginning && !this.params.loop || this.slidePrev()
        },
        onNextClick: function(e) {
            e.preventDefault(),
            this.isEnd && !this.params.loop || this.slideNext()
        },
        init: function() {
            var e, t, i = this.params.navigation;
            (i.nextEl || i.prevEl) && (i.nextEl && (e = s(i.nextEl),
            this.params.uniqueNavElements && "string" == typeof i.nextEl && e.length > 1 && 1 === this.$el.find(i.nextEl).length && (e = this.$el.find(i.nextEl))),
            i.prevEl && (t = s(i.prevEl),
            this.params.uniqueNavElements && "string" == typeof i.prevEl && t.length > 1 && 1 === this.$el.find(i.prevEl).length && (t = this.$el.find(i.prevEl))),
            e && e.length > 0 && e.on("click", this.navigation.onNextClick),
            t && t.length > 0 && t.on("click", this.navigation.onPrevClick),
            n.extend(this.navigation, {
                $nextEl: e,
                nextEl: e && e[0],
                $prevEl: t,
                prevEl: t && t[0]
            }))
        },
        destroy: function() {
            var e = this.navigation
              , t = e.$nextEl
              , i = e.$prevEl;
            t && t.length && (t.off("click", this.navigation.onNextClick),
            t.removeClass(this.params.navigation.disabledClass)),
            i && i.length && (i.off("click", this.navigation.onPrevClick),
            i.removeClass(this.params.navigation.disabledClass))
        }
    }
      , ae = {
        update: function() {
            var e = this.rtl
              , t = this.params.pagination;
            if (t.el && this.pagination.el && this.pagination.$el && 0 !== this.pagination.$el.length) {
                var i, a = this.virtual && this.params.virtual.enabled ? this.virtual.slides.length : this.slides.length, r = this.pagination.$el, n = this.params.loop ? Math.ceil((a - 2 * this.loopedSlides) / this.params.slidesPerGroup) : this.snapGrid.length;
                if (this.params.loop ? ((i = Math.ceil((this.activeIndex - this.loopedSlides) / this.params.slidesPerGroup)) > a - 1 - 2 * this.loopedSlides && (i -= a - 2 * this.loopedSlides),
                i > n - 1 && (i -= n),
                i < 0 && "bullets" !== this.params.paginationType && (i = n + i)) : i = void 0 !== this.snapIndex ? this.snapIndex : this.activeIndex || 0,
                "bullets" === t.type && this.pagination.bullets && this.pagination.bullets.length > 0) {
                    var o, l, d, h = this.pagination.bullets;
                    if (t.dynamicBullets && (this.pagination.bulletSize = h.eq(0)[this.isHorizontal() ? "outerWidth" : "outerHeight"](!0),
                    r.css(this.isHorizontal() ? "width" : "height", this.pagination.bulletSize * (t.dynamicMainBullets + 4) + "px"),
                    t.dynamicMainBullets > 1 && void 0 !== this.previousIndex && (this.pagination.dynamicBulletIndex += i - this.previousIndex,
                    this.pagination.dynamicBulletIndex > t.dynamicMainBullets - 1 ? this.pagination.dynamicBulletIndex = t.dynamicMainBullets - 1 : this.pagination.dynamicBulletIndex < 0 && (this.pagination.dynamicBulletIndex = 0)),
                    o = i - this.pagination.dynamicBulletIndex,
                    d = ((l = o + (Math.min(h.length, t.dynamicMainBullets) - 1)) + o) / 2),
                    h.removeClass(t.bulletActiveClass + " " + t.bulletActiveClass + "-next " + t.bulletActiveClass + "-next-next " + t.bulletActiveClass + "-prev " + t.bulletActiveClass + "-prev-prev " + t.bulletActiveClass + "-main"),
                    r.length > 1)
                        h.each((function(e, a) {
                            var r = s(a)
                              , n = r.index();
                            n === i && r.addClass(t.bulletActiveClass),
                            t.dynamicBullets && (n >= o && n <= l && r.addClass(t.bulletActiveClass + "-main"),
                            n === o && r.prev().addClass(t.bulletActiveClass + "-prev").prev().addClass(t.bulletActiveClass + "-prev-prev"),
                            n === l && r.next().addClass(t.bulletActiveClass + "-next").next().addClass(t.bulletActiveClass + "-next-next"))
                        }
                        ));
                    else {
                        var p = h.eq(i)
                          , c = p.index();
                        if (p.addClass(t.bulletActiveClass),
                        t.dynamicBullets) {
                            for (var u = h.eq(o), v = h.eq(l), f = o; f <= l; f += 1)
                                h.eq(f).addClass(t.bulletActiveClass + "-main");
                            if (this.params.loop)
                                if (c >= h.length - t.dynamicMainBullets) {
                                    for (var m = t.dynamicMainBullets; m >= 0; m -= 1)
                                        h.eq(h.length - m).addClass(t.bulletActiveClass + "-main");
                                    h.eq(h.length - t.dynamicMainBullets - 1).addClass(t.bulletActiveClass + "-prev")
                                } else
                                    u.prev().addClass(t.bulletActiveClass + "-prev").prev().addClass(t.bulletActiveClass + "-prev-prev"),
                                    v.next().addClass(t.bulletActiveClass + "-next").next().addClass(t.bulletActiveClass + "-next-next");
                            else
                                u.prev().addClass(t.bulletActiveClass + "-prev").prev().addClass(t.bulletActiveClass + "-prev-prev"),
                                v.next().addClass(t.bulletActiveClass + "-next").next().addClass(t.bulletActiveClass + "-next-next")
                        }
                    }
                    if (t.dynamicBullets) {
                        var g = Math.min(h.length, t.dynamicMainBullets + 4)
                          , b = (this.pagination.bulletSize * g - this.pagination.bulletSize) / 2 - d * this.pagination.bulletSize
                          , w = e ? "right" : "left";
                        h.css(this.isHorizontal() ? w : "top", b + "px")
                    }
                }
                if ("fraction" === t.type && (r.find("." + t.currentClass).text(t.formatFractionCurrent(i + 1)),
                r.find("." + t.totalClass).text(t.formatFractionTotal(n))),
                "progressbar" === t.type) {
                    var y;
                    y = t.progressbarOpposite ? this.isHorizontal() ? "vertical" : "horizontal" : this.isHorizontal() ? "horizontal" : "vertical";
                    var x = (i + 1) / n
                      , T = 1
                      , E = 1;
                    "horizontal" === y ? T = x : E = x,
                    r.find("." + t.progressbarFillClass).transform("translate3d(0,0,0) scaleX(" + T + ") scaleY(" + E + ")").transition(this.params.speed)
                }
                "custom" === t.type && t.renderCustom ? (r.html(t.renderCustom(this, i + 1, n)),
                this.emit("paginationRender", this, r[0])) : this.emit("paginationUpdate", this, r[0]),
                r[this.params.watchOverflow && this.isLocked ? "addClass" : "removeClass"](t.lockClass)
            }
        },
        render: function() {
            var e = this.params.pagination;
            if (e.el && this.pagination.el && this.pagination.$el && 0 !== this.pagination.$el.length) {
                var t = this.virtual && this.params.virtual.enabled ? this.virtual.slides.length : this.slides.length
                  , i = this.pagination.$el
                  , s = "";
                if ("bullets" === e.type) {
                    for (var a = this.params.loop ? Math.ceil((t - 2 * this.loopedSlides) / this.params.slidesPerGroup) : this.snapGrid.length, r = 0; r < a; r += 1)
                        e.renderBullet ? s += e.renderBullet.call(this, r, e.bulletClass) : s += "<" + e.bulletElement + ' class="' + e.bulletClass + '"></' + e.bulletElement + ">";
                    i.html(s),
                    this.pagination.bullets = i.find("." + e.bulletClass)
                }
                "fraction" === e.type && (s = e.renderFraction ? e.renderFraction.call(this, e.currentClass, e.totalClass) : '<span class="' + e.currentClass + '"></span> / <span class="' + e.totalClass + '"></span>',
                i.html(s)),
                "progressbar" === e.type && (s = e.renderProgressbar ? e.renderProgressbar.call(this, e.progressbarFillClass) : '<span class="' + e.progressbarFillClass + '"></span>',
                i.html(s)),
                "custom" !== e.type && this.emit("paginationRender", this.pagination.$el[0])
            }
        },
        init: function() {
            var e = this
              , t = e.params.pagination;
            if (t.el) {
                var i = s(t.el);
                0 !== i.length && (e.params.uniqueNavElements && "string" == typeof t.el && i.length > 1 && 1 === e.$el.find(t.el).length && (i = e.$el.find(t.el)),
                "bullets" === t.type && t.clickable && i.addClass(t.clickableClass),
                i.addClass(t.modifierClass + t.type),
                "bullets" === t.type && t.dynamicBullets && (i.addClass("" + t.modifierClass + t.type + "-dynamic"),
                e.pagination.dynamicBulletIndex = 0,
                t.dynamicMainBullets < 1 && (t.dynamicMainBullets = 1)),
                "progressbar" === t.type && t.progressbarOpposite && i.addClass(t.progressbarOppositeClass),
                t.clickable && i.on("click", "." + t.bulletClass, (function(t) {
                    t.preventDefault();
                    var i = s(this).index() * e.params.slidesPerGroup;
                    e.params.loop && (i += e.loopedSlides),
                    e.slideTo(i)
                }
                )),
                n.extend(e.pagination, {
                    $el: i,
                    el: i[0]
                }))
            }
        },
        destroy: function() {
            var e = this.params.pagination;
            if (e.el && this.pagination.el && this.pagination.$el && 0 !== this.pagination.$el.length) {
                var t = this.pagination.$el;
                t.removeClass(e.hiddenClass),
                t.removeClass(e.modifierClass + e.type),
                this.pagination.bullets && this.pagination.bullets.removeClass(e.bulletActiveClass),
                e.clickable && t.off("click", "." + e.bulletClass)
            }
        }
    }
      , re = {
        setTranslate: function() {
            if (this.params.scrollbar.el && this.scrollbar.el) {
                var e = this.scrollbar
                  , t = this.rtlTranslate
                  , i = this.progress
                  , s = e.dragSize
                  , a = e.trackSize
                  , r = e.$dragEl
                  , n = e.$el
                  , o = this.params.scrollbar
                  , l = s
                  , d = (a - s) * i;
                t ? (d = -d) > 0 ? (l = s - d,
                d = 0) : -d + s > a && (l = a + d) : d < 0 ? (l = s + d,
                d = 0) : d + s > a && (l = a - d),
                this.isHorizontal() ? (r.transform("translate3d(" + d + "px, 0, 0)"),
                r[0].style.width = l + "px") : (r.transform("translate3d(0px, " + d + "px, 0)"),
                r[0].style.height = l + "px"),
                o.hide && (clearTimeout(this.scrollbar.timeout),
                n[0].style.opacity = 1,
                this.scrollbar.timeout = setTimeout((function() {
                    n[0].style.opacity = 0,
                    n.transition(400)
                }
                ), 1e3))
            }
        },
        setTransition: function(e) {
            this.params.scrollbar.el && this.scrollbar.el && this.scrollbar.$dragEl.transition(e)
        },
        updateSize: function() {
            if (this.params.scrollbar.el && this.scrollbar.el) {
                var e = this.scrollbar
                  , t = e.$dragEl
                  , i = e.$el;
                t[0].style.width = "",
                t[0].style.height = "";
                var s, a = this.isHorizontal() ? i[0].offsetWidth : i[0].offsetHeight, r = this.size / this.virtualSize, o = r * (a / this.size);
                s = "auto" === this.params.scrollbar.dragSize ? a * r : parseInt(this.params.scrollbar.dragSize, 10),
                this.isHorizontal() ? t[0].style.width = s + "px" : t[0].style.height = s + "px",
                i[0].style.display = r >= 1 ? "none" : "",
                this.params.scrollbar.hide && (i[0].style.opacity = 0),
                n.extend(e, {
                    trackSize: a,
                    divider: r,
                    moveDivider: o,
                    dragSize: s
                }),
                e.$el[this.params.watchOverflow && this.isLocked ? "addClass" : "removeClass"](this.params.scrollbar.lockClass)
            }
        },
        getPointerPosition: function(e) {
            return this.isHorizontal() ? "touchstart" === e.type || "touchmove" === e.type ? e.targetTouches[0].clientX : e.clientX : "touchstart" === e.type || "touchmove" === e.type ? e.targetTouches[0].clientY : e.clientY
        },
        setDragPosition: function(e) {
            var t, i = this.scrollbar, s = this.rtlTranslate, a = i.$el, r = i.dragSize, n = i.trackSize, o = i.dragStartPos;
            t = (i.getPointerPosition(e) - a.offset()[this.isHorizontal() ? "left" : "top"] - (null !== o ? o : r / 2)) / (n - r),
            t = Math.max(Math.min(t, 1), 0),
            s && (t = 1 - t);
            var l = this.minTranslate() + (this.maxTranslate() - this.minTranslate()) * t;
            this.updateProgress(l),
            this.setTranslate(l),
            this.updateActiveIndex(),
            this.updateSlidesClasses()
        },
        onDragStart: function(e) {
            var t = this.params.scrollbar
              , i = this.scrollbar
              , s = this.$wrapperEl
              , a = i.$el
              , r = i.$dragEl;
            this.scrollbar.isTouched = !0,
            this.scrollbar.dragStartPos = e.target === r[0] || e.target === r ? i.getPointerPosition(e) - e.target.getBoundingClientRect()[this.isHorizontal() ? "left" : "top"] : null,
            e.preventDefault(),
            e.stopPropagation(),
            s.transition(100),
            r.transition(100),
            i.setDragPosition(e),
            clearTimeout(this.scrollbar.dragTimeout),
            a.transition(0),
            t.hide && a.css("opacity", 1),
            this.params.cssMode && this.$wrapperEl.css("scroll-snap-type", "none"),
            this.emit("scrollbarDragStart", e)
        },
        onDragMove: function(e) {
            var t = this.scrollbar
              , i = this.$wrapperEl
              , s = t.$el
              , a = t.$dragEl;
            this.scrollbar.isTouched && (e.preventDefault ? e.preventDefault() : e.returnValue = !1,
            t.setDragPosition(e),
            i.transition(0),
            s.transition(0),
            a.transition(0),
            this.emit("scrollbarDragMove", e))
        },
        onDragEnd: function(e) {
            var t = this.params.scrollbar
              , i = this.scrollbar
              , s = this.$wrapperEl
              , a = i.$el;
            this.scrollbar.isTouched && (this.scrollbar.isTouched = !1,
            this.params.cssMode && (this.$wrapperEl.css("scroll-snap-type", ""),
            s.transition("")),
            t.hide && (clearTimeout(this.scrollbar.dragTimeout),
            this.scrollbar.dragTimeout = n.nextTick((function() {
                a.css("opacity", 0),
                a.transition(400)
            }
            ), 1e3)),
            this.emit("scrollbarDragEnd", e),
            t.snapOnRelease && this.slideToClosest())
        },
        enableDraggable: function() {
            if (this.params.scrollbar.el) {
                var t = this.scrollbar
                  , i = this.touchEventsTouch
                  , s = this.touchEventsDesktop
                  , a = this.params
                  , r = t.$el[0]
                  , n = !(!o.passiveListener || !a.passiveListeners) && {
                    passive: !1,
                    capture: !1
                }
                  , l = !(!o.passiveListener || !a.passiveListeners) && {
                    passive: !0,
                    capture: !1
                };
                o.touch ? (r.addEventListener(i.start, this.scrollbar.onDragStart, n),
                r.addEventListener(i.move, this.scrollbar.onDragMove, n),
                r.addEventListener(i.end, this.scrollbar.onDragEnd, l)) : (r.addEventListener(s.start, this.scrollbar.onDragStart, n),
                e.addEventListener(s.move, this.scrollbar.onDragMove, n),
                e.addEventListener(s.end, this.scrollbar.onDragEnd, l))
            }
        },
        disableDraggable: function() {
            if (this.params.scrollbar.el) {
                var t = this.scrollbar
                  , i = this.touchEventsTouch
                  , s = this.touchEventsDesktop
                  , a = this.params
                  , r = t.$el[0]
                  , n = !(!o.passiveListener || !a.passiveListeners) && {
                    passive: !1,
                    capture: !1
                }
                  , l = !(!o.passiveListener || !a.passiveListeners) && {
                    passive: !0,
                    capture: !1
                };
                o.touch ? (r.removeEventListener(i.start, this.scrollbar.onDragStart, n),
                r.removeEventListener(i.move, this.scrollbar.onDragMove, n),
                r.removeEventListener(i.end, this.scrollbar.onDragEnd, l)) : (r.removeEventListener(s.start, this.scrollbar.onDragStart, n),
                e.removeEventListener(s.move, this.scrollbar.onDragMove, n),
                e.removeEventListener(s.end, this.scrollbar.onDragEnd, l))
            }
        },
        init: function() {
            if (this.params.scrollbar.el) {
                var e = this.scrollbar
                  , t = this.$el
                  , i = this.params.scrollbar
                  , a = s(i.el);
                this.params.uniqueNavElements && "string" == typeof i.el && a.length > 1 && 1 === t.find(i.el).length && (a = t.find(i.el));
                var r = a.find("." + this.params.scrollbar.dragClass);
                0 === r.length && (r = s('<div class="' + this.params.scrollbar.dragClass + '"></div>'),
                a.append(r)),
                n.extend(e, {
                    $el: a,
                    el: a[0],
                    $dragEl: r,
                    dragEl: r[0]
                }),
                i.draggable && e.enableDraggable()
            }
        },
        destroy: function() {
            this.scrollbar.disableDraggable()
        }
    }
      , ne = {
        setTransform: function(e, t) {
            var i = this.rtl
              , a = s(e)
              , r = i ? -1 : 1
              , n = a.attr("data-swiper-parallax") || "0"
              , o = a.attr("data-swiper-parallax-x")
              , l = a.attr("data-swiper-parallax-y")
              , d = a.attr("data-swiper-parallax-scale")
              , h = a.attr("data-swiper-parallax-opacity");
            if (o || l ? (o = o || "0",
            l = l || "0") : this.isHorizontal() ? (o = n,
            l = "0") : (l = n,
            o = "0"),
            o = o.indexOf("%") >= 0 ? parseInt(o, 10) * t * r + "%" : o * t * r + "px",
            l = l.indexOf("%") >= 0 ? parseInt(l, 10) * t + "%" : l * t + "px",
            null != h) {
                var p = h - (h - 1) * (1 - Math.abs(t));
                a[0].style.opacity = p
            }
            if (null == d)
                a.transform("translate3d(" + o + ", " + l + ", 0px)");
            else {
                var c = d - (d - 1) * (1 - Math.abs(t));
                a.transform("translate3d(" + o + ", " + l + ", 0px) scale(" + c + ")")
            }
        },
        setTranslate: function() {
            var e = this
              , t = e.$el
              , i = e.slides
              , a = e.progress
              , r = e.snapGrid;
            t.children("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each((function(t, i) {
                e.parallax.setTransform(i, a)
            }
            )),
            i.each((function(t, i) {
                var n = i.progress;
                e.params.slidesPerGroup > 1 && "auto" !== e.params.slidesPerView && (n += Math.ceil(t / 2) - a * (r.length - 1)),
                n = Math.min(Math.max(n, -1), 1),
                s(i).find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each((function(t, i) {
                    e.parallax.setTransform(i, n)
                }
                ))
            }
            ))
        },
        setTransition: function(e) {
            void 0 === e && (e = this.params.speed);
            this.$el.find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each((function(t, i) {
                var a = s(i)
                  , r = parseInt(a.attr("data-swiper-parallax-duration"), 10) || e;
                0 === e && (r = 0),
                a.transition(r)
            }
            ))
        }
    }
      , oe = {
        getDistanceBetweenTouches: function(e) {
            if (e.targetTouches.length < 2)
                return 1;
            var t = e.targetTouches[0].pageX
              , i = e.targetTouches[0].pageY
              , s = e.targetTouches[1].pageX
              , a = e.targetTouches[1].pageY;
            return Math.sqrt(Math.pow(s - t, 2) + Math.pow(a - i, 2))
        },
        onGestureStart: function(e) {
            var t = this.params.zoom
              , i = this.zoom
              , a = i.gesture;
            if (i.fakeGestureTouched = !1,
            i.fakeGestureMoved = !1,
            !o.gestures) {
                if ("touchstart" !== e.type || "touchstart" === e.type && e.targetTouches.length < 2)
                    return;
                i.fakeGestureTouched = !0,
                a.scaleStart = oe.getDistanceBetweenTouches(e)
            }
            a.$slideEl && a.$slideEl.length || (a.$slideEl = s(e.target).closest("." + this.params.slideClass),
            0 === a.$slideEl.length && (a.$slideEl = this.slides.eq(this.activeIndex)),
            a.$imageEl = a.$slideEl.find("img, svg, canvas, picture, .swiper-zoom-target"),
            a.$imageWrapEl = a.$imageEl.parent("." + t.containerClass),
            a.maxRatio = a.$imageWrapEl.attr("data-swiper-zoom") || t.maxRatio,
            0 !== a.$imageWrapEl.length) ? (a.$imageEl.transition(0),
            this.zoom.isScaling = !0) : a.$imageEl = void 0
        },
        onGestureChange: function(e) {
            var t = this.params.zoom
              , i = this.zoom
              , s = i.gesture;
            if (!o.gestures) {
                if ("touchmove" !== e.type || "touchmove" === e.type && e.targetTouches.length < 2)
                    return;
                i.fakeGestureMoved = !0,
                s.scaleMove = oe.getDistanceBetweenTouches(e)
            }
            s.$imageEl && 0 !== s.$imageEl.length && (o.gestures ? i.scale = e.scale * i.currentScale : i.scale = s.scaleMove / s.scaleStart * i.currentScale,
            i.scale > s.maxRatio && (i.scale = s.maxRatio - 1 + Math.pow(i.scale - s.maxRatio + 1, .5)),
            i.scale < t.minRatio && (i.scale = t.minRatio + 1 - Math.pow(t.minRatio - i.scale + 1, .5)),
            s.$imageEl.transform("translate3d(0,0,0) scale(" + i.scale + ")"))
        },
        onGestureEnd: function(e) {
            var t = this.params.zoom
              , i = this.zoom
              , s = i.gesture;
            if (!o.gestures) {
                if (!i.fakeGestureTouched || !i.fakeGestureMoved)
                    return;
                if ("touchend" !== e.type || "touchend" === e.type && e.changedTouches.length < 2 && !I.android)
                    return;
                i.fakeGestureTouched = !1,
                i.fakeGestureMoved = !1
            }
            s.$imageEl && 0 !== s.$imageEl.length && (i.scale = Math.max(Math.min(i.scale, s.maxRatio), t.minRatio),
            s.$imageEl.transition(this.params.speed).transform("translate3d(0,0,0) scale(" + i.scale + ")"),
            i.currentScale = i.scale,
            i.isScaling = !1,
            1 === i.scale && (s.$slideEl = void 0))
        },
        onTouchStart: function(e) {
            var t = this.zoom
              , i = t.gesture
              , s = t.image;
            i.$imageEl && 0 !== i.$imageEl.length && (s.isTouched || (I.android && e.preventDefault(),
            s.isTouched = !0,
            s.touchesStart.x = "touchstart" === e.type ? e.targetTouches[0].pageX : e.pageX,
            s.touchesStart.y = "touchstart" === e.type ? e.targetTouches[0].pageY : e.pageY))
        },
        onTouchMove: function(e) {
            var t = this.zoom
              , i = t.gesture
              , s = t.image
              , a = t.velocity;
            if (i.$imageEl && 0 !== i.$imageEl.length && (this.allowClick = !1,
            s.isTouched && i.$slideEl)) {
                s.isMoved || (s.width = i.$imageEl[0].offsetWidth,
                s.height = i.$imageEl[0].offsetHeight,
                s.startX = n.getTranslate(i.$imageWrapEl[0], "x") || 0,
                s.startY = n.getTranslate(i.$imageWrapEl[0], "y") || 0,
                i.slideWidth = i.$slideEl[0].offsetWidth,
                i.slideHeight = i.$slideEl[0].offsetHeight,
                i.$imageWrapEl.transition(0),
                this.rtl && (s.startX = -s.startX,
                s.startY = -s.startY));
                var r = s.width * t.scale
                  , o = s.height * t.scale;
                if (!(r < i.slideWidth && o < i.slideHeight)) {
                    if (s.minX = Math.min(i.slideWidth / 2 - r / 2, 0),
                    s.maxX = -s.minX,
                    s.minY = Math.min(i.slideHeight / 2 - o / 2, 0),
                    s.maxY = -s.minY,
                    s.touchesCurrent.x = "touchmove" === e.type ? e.targetTouches[0].pageX : e.pageX,
                    s.touchesCurrent.y = "touchmove" === e.type ? e.targetTouches[0].pageY : e.pageY,
                    !s.isMoved && !t.isScaling) {
                        if (this.isHorizontal() && (Math.floor(s.minX) === Math.floor(s.startX) && s.touchesCurrent.x < s.touchesStart.x || Math.floor(s.maxX) === Math.floor(s.startX) && s.touchesCurrent.x > s.touchesStart.x))
                            return void (s.isTouched = !1);
                        if (!this.isHorizontal() && (Math.floor(s.minY) === Math.floor(s.startY) && s.touchesCurrent.y < s.touchesStart.y || Math.floor(s.maxY) === Math.floor(s.startY) && s.touchesCurrent.y > s.touchesStart.y))
                            return void (s.isTouched = !1)
                    }
                    e.preventDefault(),
                    e.stopPropagation(),
                    s.isMoved = !0,
                    s.currentX = s.touchesCurrent.x - s.touchesStart.x + s.startX,
                    s.currentY = s.touchesCurrent.y - s.touchesStart.y + s.startY,
                    s.currentX < s.minX && (s.currentX = s.minX + 1 - Math.pow(s.minX - s.currentX + 1, .8)),
                    s.currentX > s.maxX && (s.currentX = s.maxX - 1 + Math.pow(s.currentX - s.maxX + 1, .8)),
                    s.currentY < s.minY && (s.currentY = s.minY + 1 - Math.pow(s.minY - s.currentY + 1, .8)),
                    s.currentY > s.maxY && (s.currentY = s.maxY - 1 + Math.pow(s.currentY - s.maxY + 1, .8)),
                    a.prevPositionX || (a.prevPositionX = s.touchesCurrent.x),
                    a.prevPositionY || (a.prevPositionY = s.touchesCurrent.y),
                    a.prevTime || (a.prevTime = Date.now()),
                    a.x = (s.touchesCurrent.x - a.prevPositionX) / (Date.now() - a.prevTime) / 2,
                    a.y = (s.touchesCurrent.y - a.prevPositionY) / (Date.now() - a.prevTime) / 2,
                    Math.abs(s.touchesCurrent.x - a.prevPositionX) < 2 && (a.x = 0),
                    Math.abs(s.touchesCurrent.y - a.prevPositionY) < 2 && (a.y = 0),
                    a.prevPositionX = s.touchesCurrent.x,
                    a.prevPositionY = s.touchesCurrent.y,
                    a.prevTime = Date.now(),
                    i.$imageWrapEl.transform("translate3d(" + s.currentX + "px, " + s.currentY + "px,0)")
                }
            }
        },
        onTouchEnd: function() {
            var e = this.zoom
              , t = e.gesture
              , i = e.image
              , s = e.velocity;
            if (t.$imageEl && 0 !== t.$imageEl.length) {
                if (!i.isTouched || !i.isMoved)
                    return i.isTouched = !1,
                    void (i.isMoved = !1);
                i.isTouched = !1,
                i.isMoved = !1;
                var a = 300
                  , r = 300
                  , n = s.x * a
                  , o = i.currentX + n
                  , l = s.y * r
                  , d = i.currentY + l;
                0 !== s.x && (a = Math.abs((o - i.currentX) / s.x)),
                0 !== s.y && (r = Math.abs((d - i.currentY) / s.y));
                var h = Math.max(a, r);
                i.currentX = o,
                i.currentY = d;
                var p = i.width * e.scale
                  , c = i.height * e.scale;
                i.minX = Math.min(t.slideWidth / 2 - p / 2, 0),
                i.maxX = -i.minX,
                i.minY = Math.min(t.slideHeight / 2 - c / 2, 0),
                i.maxY = -i.minY,
                i.currentX = Math.max(Math.min(i.currentX, i.maxX), i.minX),
                i.currentY = Math.max(Math.min(i.currentY, i.maxY), i.minY),
                t.$imageWrapEl.transition(h).transform("translate3d(" + i.currentX + "px, " + i.currentY + "px,0)")
            }
        },
        onTransitionEnd: function() {
            var e = this.zoom
              , t = e.gesture;
            t.$slideEl && this.previousIndex !== this.activeIndex && (t.$imageEl.transform("translate3d(0,0,0) scale(1)"),
            t.$imageWrapEl.transform("translate3d(0,0,0)"),
            e.scale = 1,
            e.currentScale = 1,
            t.$slideEl = void 0,
            t.$imageEl = void 0,
            t.$imageWrapEl = void 0)
        },
        toggle: function(e) {
            var t = this.zoom;
            t.scale && 1 !== t.scale ? t.out() : t.in(e)
        },
        in: function(e) {
            var t, i, s, a, r, n, o, l, d, h, p, c, u, v, f, m, g = this.zoom, b = this.params.zoom, w = g.gesture, y = g.image;
            (w.$slideEl || (w.$slideEl = this.slides.eq(this.activeIndex),
            w.$imageEl = w.$slideEl.find("img, svg, canvas, picture, .swiper-zoom-target"),
            w.$imageWrapEl = w.$imageEl.parent("." + b.containerClass)),
            w.$imageEl && 0 !== w.$imageEl.length) && (w.$slideEl.addClass("" + b.zoomedSlideClass),
            void 0 === y.touchesStart.x && e ? (t = "touchend" === e.type ? e.changedTouches[0].pageX : e.pageX,
            i = "touchend" === e.type ? e.changedTouches[0].pageY : e.pageY) : (t = y.touchesStart.x,
            i = y.touchesStart.y),
            g.scale = w.$imageWrapEl.attr("data-swiper-zoom") || b.maxRatio,
            g.currentScale = w.$imageWrapEl.attr("data-swiper-zoom") || b.maxRatio,
            e ? (f = w.$slideEl[0].offsetWidth,
            m = w.$slideEl[0].offsetHeight,
            s = w.$slideEl.offset().left + f / 2 - t,
            a = w.$slideEl.offset().top + m / 2 - i,
            o = w.$imageEl[0].offsetWidth,
            l = w.$imageEl[0].offsetHeight,
            d = o * g.scale,
            h = l * g.scale,
            u = -(p = Math.min(f / 2 - d / 2, 0)),
            v = -(c = Math.min(m / 2 - h / 2, 0)),
            (r = s * g.scale) < p && (r = p),
            r > u && (r = u),
            (n = a * g.scale) < c && (n = c),
            n > v && (n = v)) : (r = 0,
            n = 0),
            w.$imageWrapEl.transition(300).transform("translate3d(" + r + "px, " + n + "px,0)"),
            w.$imageEl.transition(300).transform("translate3d(0,0,0) scale(" + g.scale + ")"))
        },
        out: function() {
            var e = this.zoom
              , t = this.params.zoom
              , i = e.gesture;
            i.$slideEl || (i.$slideEl = this.slides.eq(this.activeIndex),
            i.$imageEl = i.$slideEl.find("img, svg, canvas, picture, .swiper-zoom-target"),
            i.$imageWrapEl = i.$imageEl.parent("." + t.containerClass)),
            i.$imageEl && 0 !== i.$imageEl.length && (e.scale = 1,
            e.currentScale = 1,
            i.$imageWrapEl.transition(300).transform("translate3d(0,0,0)"),
            i.$imageEl.transition(300).transform("translate3d(0,0,0) scale(1)"),
            i.$slideEl.removeClass("" + t.zoomedSlideClass),
            i.$slideEl = void 0)
        },
        enable: function() {
            var e = this.zoom;
            if (!e.enabled) {
                e.enabled = !0;
                var t = !("touchstart" !== this.touchEvents.start || !o.passiveListener || !this.params.passiveListeners) && {
                    passive: !0,
                    capture: !1
                }
                  , i = !o.passiveListener || {
                    passive: !1,
                    capture: !0
                }
                  , s = "." + this.params.slideClass;
                o.gestures ? (this.$wrapperEl.on("gesturestart", s, e.onGestureStart, t),
                this.$wrapperEl.on("gesturechange", s, e.onGestureChange, t),
                this.$wrapperEl.on("gestureend", s, e.onGestureEnd, t)) : "touchstart" === this.touchEvents.start && (this.$wrapperEl.on(this.touchEvents.start, s, e.onGestureStart, t),
                this.$wrapperEl.on(this.touchEvents.move, s, e.onGestureChange, i),
                this.$wrapperEl.on(this.touchEvents.end, s, e.onGestureEnd, t),
                this.touchEvents.cancel && this.$wrapperEl.on(this.touchEvents.cancel, s, e.onGestureEnd, t)),
                this.$wrapperEl.on(this.touchEvents.move, "." + this.params.zoom.containerClass, e.onTouchMove, i)
            }
        },
        disable: function() {
            var e = this.zoom;
            if (e.enabled) {
                this.zoom.enabled = !1;
                var t = !("touchstart" !== this.touchEvents.start || !o.passiveListener || !this.params.passiveListeners) && {
                    passive: !0,
                    capture: !1
                }
                  , i = !o.passiveListener || {
                    passive: !1,
                    capture: !0
                }
                  , s = "." + this.params.slideClass;
                o.gestures ? (this.$wrapperEl.off("gesturestart", s, e.onGestureStart, t),
                this.$wrapperEl.off("gesturechange", s, e.onGestureChange, t),
                this.$wrapperEl.off("gestureend", s, e.onGestureEnd, t)) : "touchstart" === this.touchEvents.start && (this.$wrapperEl.off(this.touchEvents.start, s, e.onGestureStart, t),
                this.$wrapperEl.off(this.touchEvents.move, s, e.onGestureChange, i),
                this.$wrapperEl.off(this.touchEvents.end, s, e.onGestureEnd, t),
                this.touchEvents.cancel && this.$wrapperEl.off(this.touchEvents.cancel, s, e.onGestureEnd, t)),
                this.$wrapperEl.off(this.touchEvents.move, "." + this.params.zoom.containerClass, e.onTouchMove, i)
            }
        }
    }
      , le = {
        loadInSlide: function(e, t) {
            void 0 === t && (t = !0);
            var i = this
              , a = i.params.lazy;
            if (void 0 !== e && 0 !== i.slides.length) {
                var r = i.virtual && i.params.virtual.enabled ? i.$wrapperEl.children("." + i.params.slideClass + '[data-swiper-slide-index="' + e + '"]') : i.slides.eq(e)
                  , n = r.find("." + a.elementClass + ":not(." + a.loadedClass + "):not(." + a.loadingClass + ")");
                !r.hasClass(a.elementClass) || r.hasClass(a.loadedClass) || r.hasClass(a.loadingClass) || (n = n.add(r[0])),
                0 !== n.length && n.each((function(e, n) {
                    var o = s(n);
                    o.addClass(a.loadingClass);
                    var l = o.attr("data-background")
                      , d = o.attr("data-src")
                      , h = o.attr("data-srcset")
                      , p = o.attr("data-sizes");
                    i.loadImage(o[0], d || l, h, p, !1, (function() {
                        if (null != i && i && (!i || i.params) && !i.destroyed) {
                            if (l ? (o.css("background-image", 'url("' + l + '")'),
                            o.removeAttr("data-background")) : (h && (o.attr("srcset", h),
                            o.removeAttr("data-srcset")),
                            p && (o.attr("sizes", p),
                            o.removeAttr("data-sizes")),
                            d && (o.attr("src", d),
                            o.removeAttr("data-src"))),
                            o.addClass(a.loadedClass).removeClass(a.loadingClass),
                            r.find("." + a.preloaderClass).remove(),
                            i.params.loop && t) {
                                var e = r.attr("data-swiper-slide-index");
                                if (r.hasClass(i.params.slideDuplicateClass)) {
                                    var s = i.$wrapperEl.children('[data-swiper-slide-index="' + e + '"]:not(.' + i.params.slideDuplicateClass + ")");
                                    i.lazy.loadInSlide(s.index(), !1)
                                } else {
                                    var n = i.$wrapperEl.children("." + i.params.slideDuplicateClass + '[data-swiper-slide-index="' + e + '"]');
                                    i.lazy.loadInSlide(n.index(), !1)
                                }
                            }
                            i.emit("lazyImageReady", r[0], o[0]),
                            i.params.autoHeight && i.updateAutoHeight()
                        }
                    }
                    )),
                    i.emit("lazyImageLoad", r[0], o[0])
                }
                ))
            }
        },
        load: function() {
            var e = this
              , t = e.$wrapperEl
              , i = e.params
              , a = e.slides
              , r = e.activeIndex
              , n = e.virtual && i.virtual.enabled
              , o = i.lazy
              , l = i.slidesPerView;
            function d(e) {
                if (n) {
                    if (t.children("." + i.slideClass + '[data-swiper-slide-index="' + e + '"]').length)
                        return !0
                } else if (a[e])
                    return !0;
                return !1
            }
            function h(e) {
                return n ? s(e).attr("data-swiper-slide-index") : s(e).index()
            }
            if ("auto" === l && (l = 0),
            e.lazy.initialImageLoaded || (e.lazy.initialImageLoaded = !0),
            e.params.watchSlidesVisibility)
                t.children("." + i.slideVisibleClass).each((function(t, i) {
                    var a = n ? s(i).attr("data-swiper-slide-index") : s(i).index();
                    e.lazy.loadInSlide(a)
                }
                ));
            else if (l > 1)
                for (var p = r; p < r + l; p += 1)
                    d(p) && e.lazy.loadInSlide(p);
            else
                e.lazy.loadInSlide(r);
            if (o.loadPrevNext)
                if (l > 1 || o.loadPrevNextAmount && o.loadPrevNextAmount > 1) {
                    for (var c = o.loadPrevNextAmount, u = l, v = Math.min(r + u + Math.max(c, u), a.length), f = Math.max(r - Math.max(u, c), 0), m = r + l; m < v; m += 1)
                        d(m) && e.lazy.loadInSlide(m);
                    for (var g = f; g < r; g += 1)
                        d(g) && e.lazy.loadInSlide(g)
                } else {
                    var b = t.children("." + i.slideNextClass);
                    b.length > 0 && e.lazy.loadInSlide(h(b));
                    var w = t.children("." + i.slidePrevClass);
                    w.length > 0 && e.lazy.loadInSlide(h(w))
                }
        }
    }
      , de = {
        LinearSpline: function(e, t) {
            var i, s, a, r, n, o = function(e, t) {
                for (s = -1,
                i = e.length; i - s > 1; )
                    e[a = i + s >> 1] <= t ? s = a : i = a;
                return i
            };
            return this.x = e,
            this.y = t,
            this.lastIndex = e.length - 1,
            this.interpolate = function(e) {
                return e ? (n = o(this.x, e),
                r = n - 1,
                (e - this.x[r]) * (this.y[n] - this.y[r]) / (this.x[n] - this.x[r]) + this.y[r]) : 0
            }
            ,
            this
        },
        getInterpolateFunction: function(e) {
            this.controller.spline || (this.controller.spline = this.params.loop ? new de.LinearSpline(this.slidesGrid,e.slidesGrid) : new de.LinearSpline(this.snapGrid,e.snapGrid))
        },
        setTranslate: function(e, t) {
            var i, s, a = this, r = a.controller.control;
            function n(e) {
                var t = a.rtlTranslate ? -a.translate : a.translate;
                "slide" === a.params.controller.by && (a.controller.getInterpolateFunction(e),
                s = -a.controller.spline.interpolate(-t)),
                s && "container" !== a.params.controller.by || (i = (e.maxTranslate() - e.minTranslate()) / (a.maxTranslate() - a.minTranslate()),
                s = (t - a.minTranslate()) * i + e.minTranslate()),
                a.params.controller.inverse && (s = e.maxTranslate() - s),
                e.updateProgress(s),
                e.setTranslate(s, a),
                e.updateActiveIndex(),
                e.updateSlidesClasses()
            }
            if (Array.isArray(r))
                for (var o = 0; o < r.length; o += 1)
                    r[o] !== t && r[o]instanceof W && n(r[o]);
            else
                r instanceof W && t !== r && n(r)
        },
        setTransition: function(e, t) {
            var i, s = this, a = s.controller.control;
            function r(t) {
                t.setTransition(e, s),
                0 !== e && (t.transitionStart(),
                t.params.autoHeight && n.nextTick((function() {
                    t.updateAutoHeight()
                }
                )),
                t.$wrapperEl.transitionEnd((function() {
                    a && (t.params.loop && "slide" === s.params.controller.by && t.loopFix(),
                    t.transitionEnd())
                }
                )))
            }
            if (Array.isArray(a))
                for (i = 0; i < a.length; i += 1)
                    a[i] !== t && a[i]instanceof W && r(a[i]);
            else
                a instanceof W && t !== a && r(a)
        }
    }
      , he = {
        makeElFocusable: function(e) {
            return e.attr("tabIndex", "0"),
            e
        },
        addElRole: function(e, t) {
            return e.attr("role", t),
            e
        },
        addElLabel: function(e, t) {
            return e.attr("aria-label", t),
            e
        },
        disableEl: function(e) {
            return e.attr("aria-disabled", !0),
            e
        },
        enableEl: function(e) {
            return e.attr("aria-disabled", !1),
            e
        },
        onEnterKey: function(e) {
            var t = this.params.a11y;
            if (13 === e.keyCode) {
                var i = s(e.target);
                this.navigation && this.navigation.$nextEl && i.is(this.navigation.$nextEl) && (this.isEnd && !this.params.loop || this.slideNext(),
                this.isEnd ? this.a11y.notify(t.lastSlideMessage) : this.a11y.notify(t.nextSlideMessage)),
                this.navigation && this.navigation.$prevEl && i.is(this.navigation.$prevEl) && (this.isBeginning && !this.params.loop || this.slidePrev(),
                this.isBeginning ? this.a11y.notify(t.firstSlideMessage) : this.a11y.notify(t.prevSlideMessage)),
                this.pagination && i.is("." + this.params.pagination.bulletClass) && i[0].click()
            }
        },
        notify: function(e) {
            var t = this.a11y.liveRegion;
            0 !== t.length && (t.html(""),
            t.html(e))
        },
        updateNavigation: function() {
            if (!this.params.loop && this.navigation) {
                var e = this.navigation
                  , t = e.$nextEl
                  , i = e.$prevEl;
                i && i.length > 0 && (this.isBeginning ? this.a11y.disableEl(i) : this.a11y.enableEl(i)),
                t && t.length > 0 && (this.isEnd ? this.a11y.disableEl(t) : this.a11y.enableEl(t))
            }
        },
        updatePagination: function() {
            var e = this
              , t = e.params.a11y;
            e.pagination && e.params.pagination.clickable && e.pagination.bullets && e.pagination.bullets.length && e.pagination.bullets.each((function(i, a) {
                var r = s(a);
                e.a11y.makeElFocusable(r),
                e.a11y.addElRole(r, "button"),
                e.a11y.addElLabel(r, t.paginationBulletMessage.replace(/{{index}}/, r.index() + 1))
            }
            ))
        },
        init: function() {
            this.$el.append(this.a11y.liveRegion);
            var e, t, i = this.params.a11y;
            this.navigation && this.navigation.$nextEl && (e = this.navigation.$nextEl),
            this.navigation && this.navigation.$prevEl && (t = this.navigation.$prevEl),
            e && (this.a11y.makeElFocusable(e),
            this.a11y.addElRole(e, "button"),
            this.a11y.addElLabel(e, i.nextSlideMessage),
            e.on("keydown", this.a11y.onEnterKey)),
            t && (this.a11y.makeElFocusable(t),
            this.a11y.addElRole(t, "button"),
            this.a11y.addElLabel(t, i.prevSlideMessage),
            t.on("keydown", this.a11y.onEnterKey)),
            this.pagination && this.params.pagination.clickable && this.pagination.bullets && this.pagination.bullets.length && this.pagination.$el.on("keydown", "." + this.params.pagination.bulletClass, this.a11y.onEnterKey)
        },
        destroy: function() {
            var e, t;
            this.a11y.liveRegion && this.a11y.liveRegion.length > 0 && this.a11y.liveRegion.remove(),
            this.navigation && this.navigation.$nextEl && (e = this.navigation.$nextEl),
            this.navigation && this.navigation.$prevEl && (t = this.navigation.$prevEl),
            e && e.off("keydown", this.a11y.onEnterKey),
            t && t.off("keydown", this.a11y.onEnterKey),
            this.pagination && this.params.pagination.clickable && this.pagination.bullets && this.pagination.bullets.length && this.pagination.$el.off("keydown", "." + this.params.pagination.bulletClass, this.a11y.onEnterKey)
        }
    }
      , pe = {
        init: function() {
            if (this.params.history) {
                if (!t.history || !t.history.pushState)
                    return this.params.history.enabled = !1,
                    void (this.params.hashNavigation.enabled = !0);
                var e = this.history;
                e.initialized = !0,
                e.paths = pe.getPathValues(),
                (e.paths.key || e.paths.value) && (e.scrollToSlide(0, e.paths.value, this.params.runCallbacksOnInit),
                this.params.history.replaceState || t.addEventListener("popstate", this.history.setHistoryPopState))
            }
        },
        destroy: function() {
            this.params.history.replaceState || t.removeEventListener("popstate", this.history.setHistoryPopState)
        },
        setHistoryPopState: function() {
            this.history.paths = pe.getPathValues(),
            this.history.scrollToSlide(this.params.speed, this.history.paths.value, !1)
        },
        getPathValues: function() {
            var e = t.location.pathname.slice(1).split("/").filter((function(e) {
                return "" !== e
            }
            ))
              , i = e.length;
            return {
                key: e[i - 2],
                value: e[i - 1]
            }
        },
        setHistory: function(e, i) {
            if (this.history.initialized && this.params.history.enabled) {
                var s = this.slides.eq(i)
                  , a = pe.slugify(s.attr("data-history"));
                t.location.pathname.includes(e) || (a = e + "/" + a);
                var r = t.history.state;
                r && r.value === a || (this.params.history.replaceState ? t.history.replaceState({
                    value: a
                }, null, a) : t.history.pushState({
                    value: a
                }, null, a))
            }
        },
        slugify: function(e) {
            return e.toString().replace(/\s+/g, "-").replace(/[^\w-]+/g, "").replace(/--+/g, "-").replace(/^-+/, "").replace(/-+$/, "")
        },
        scrollToSlide: function(e, t, i) {
            if (t)
                for (var s = 0, a = this.slides.length; s < a; s += 1) {
                    var r = this.slides.eq(s);
                    if (pe.slugify(r.attr("data-history")) === t && !r.hasClass(this.params.slideDuplicateClass)) {
                        var n = r.index();
                        this.slideTo(n, e, i)
                    }
                }
            else
                this.slideTo(0, e, i)
        }
    }
      , ce = {
        onHashCange: function() {
            var t = e.location.hash.replace("#", "");
            if (t !== this.slides.eq(this.activeIndex).attr("data-hash")) {
                var i = this.$wrapperEl.children("." + this.params.slideClass + '[data-hash="' + t + '"]').index();
                if (void 0 === i)
                    return;
                this.slideTo(i)
            }
        },
        setHash: function() {
            if (this.hashNavigation.initialized && this.params.hashNavigation.enabled)
                if (this.params.hashNavigation.replaceState && t.history && t.history.replaceState)
                    t.history.replaceState(null, null, "#" + this.slides.eq(this.activeIndex).attr("data-hash") || "");
                else {
                    var i = this.slides.eq(this.activeIndex)
                      , s = i.attr("data-hash") || i.attr("data-history");
                    e.location.hash = s || ""
                }
        },
        init: function() {
            if (!(!this.params.hashNavigation.enabled || this.params.history && this.params.history.enabled)) {
                this.hashNavigation.initialized = !0;
                var i = e.location.hash.replace("#", "");
                if (i)
                    for (var a = 0, r = this.slides.length; a < r; a += 1) {
                        var n = this.slides.eq(a);
                        if ((n.attr("data-hash") || n.attr("data-history")) === i && !n.hasClass(this.params.slideDuplicateClass)) {
                            var o = n.index();
                            this.slideTo(o, 0, this.params.runCallbacksOnInit, !0)
                        }
                    }
                this.params.hashNavigation.watchState && s(t).on("hashchange", this.hashNavigation.onHashCange)
            }
        },
        destroy: function() {
            this.params.hashNavigation.watchState && s(t).off("hashchange", this.hashNavigation.onHashCange)
        }
    }
      , ue = {
        run: function() {
            var e = this
              , t = e.slides.eq(e.activeIndex)
              , i = e.params.autoplay.delay;
            t.attr("data-swiper-autoplay") && (i = t.attr("data-swiper-autoplay") || e.params.autoplay.delay),
            clearTimeout(e.autoplay.timeout),
            e.autoplay.timeout = n.nextTick((function() {
                e.params.autoplay.reverseDirection ? e.params.loop ? (e.loopFix(),
                e.slidePrev(e.params.speed, !0, !0),
                e.emit("autoplay")) : e.isBeginning ? e.params.autoplay.stopOnLastSlide ? e.autoplay.stop() : (e.slideTo(e.slides.length - 1, e.params.speed, !0, !0),
                e.emit("autoplay")) : (e.slidePrev(e.params.speed, !0, !0),
                e.emit("autoplay")) : e.params.loop ? (e.loopFix(),
                e.slideNext(e.params.speed, !0, !0),
                e.emit("autoplay")) : e.isEnd ? e.params.autoplay.stopOnLastSlide ? e.autoplay.stop() : (e.slideTo(0, e.params.speed, !0, !0),
                e.emit("autoplay")) : (e.slideNext(e.params.speed, !0, !0),
                e.emit("autoplay")),
                e.params.cssMode && e.autoplay.running && e.autoplay.run()
            }
            ), i)
        },
        start: function() {
            return void 0 === this.autoplay.timeout && (!this.autoplay.running && (this.autoplay.running = !0,
            this.emit("autoplayStart"),
            this.autoplay.run(),
            !0))
        },
        stop: function() {
            return !!this.autoplay.running && (void 0 !== this.autoplay.timeout && (this.autoplay.timeout && (clearTimeout(this.autoplay.timeout),
            this.autoplay.timeout = void 0),
            this.autoplay.running = !1,
            this.emit("autoplayStop"),
            !0))
        },
        pause: function(e) {
            this.autoplay.running && (this.autoplay.paused || (this.autoplay.timeout && clearTimeout(this.autoplay.timeout),
            this.autoplay.paused = !0,
            0 !== e && this.params.autoplay.waitForTransition ? (this.$wrapperEl[0].addEventListener("transitionend", this.autoplay.onTransitionEnd),
            this.$wrapperEl[0].addEventListener("webkitTransitionEnd", this.autoplay.onTransitionEnd)) : (this.autoplay.paused = !1,
            this.autoplay.run())))
        }
    }
      , ve = {
        setTranslate: function() {
            for (var e = this.slides, t = 0; t < e.length; t += 1) {
                var i = this.slides.eq(t)
                  , s = -i[0].swiperSlideOffset;
                this.params.virtualTranslate || (s -= this.translate);
                var a = 0;
                this.isHorizontal() || (a = s,
                s = 0);
                var r = this.params.fadeEffect.crossFade ? Math.max(1 - Math.abs(i[0].progress), 0) : 1 + Math.min(Math.max(i[0].progress, -1), 0);
                i.css({
                    opacity: r
                }).transform("translate3d(" + s + "px, " + a + "px, 0px)")
            }
        },
        setTransition: function(e) {
            var t = this
              , i = t.slides
              , s = t.$wrapperEl;
            if (i.transition(e),
            t.params.virtualTranslate && 0 !== e) {
                var a = !1;
                i.transitionEnd((function() {
                    if (!a && t && !t.destroyed) {
                        a = !0,
                        t.animating = !1;
                        for (var e = ["webkitTransitionEnd", "transitionend"], i = 0; i < e.length; i += 1)
                            s.trigger(e[i])
                    }
                }
                ))
            }
        }
    }
      , fe = {
        setTranslate: function() {
            var e, t = this.$el, i = this.$wrapperEl, a = this.slides, r = this.width, n = this.height, o = this.rtlTranslate, l = this.size, d = this.params.cubeEffect, h = this.isHorizontal(), p = this.virtual && this.params.virtual.enabled, c = 0;
            d.shadow && (h ? (0 === (e = i.find(".swiper-cube-shadow")).length && (e = s('<div class="swiper-cube-shadow"></div>'),
            i.append(e)),
            e.css({
                height: r + "px"
            })) : 0 === (e = t.find(".swiper-cube-shadow")).length && (e = s('<div class="swiper-cube-shadow"></div>'),
            t.append(e)));
            for (var u = 0; u < a.length; u += 1) {
                var v = a.eq(u)
                  , f = u;
                p && (f = parseInt(v.attr("data-swiper-slide-index"), 10));
                var m = 90 * f
                  , g = Math.floor(m / 360);
                o && (m = -m,
                g = Math.floor(-m / 360));
                var b = Math.max(Math.min(v[0].progress, 1), -1)
                  , w = 0
                  , y = 0
                  , x = 0;
                f % 4 == 0 ? (w = 4 * -g * l,
                x = 0) : (f - 1) % 4 == 0 ? (w = 0,
                x = 4 * -g * l) : (f - 2) % 4 == 0 ? (w = l + 4 * g * l,
                x = l) : (f - 3) % 4 == 0 && (w = -l,
                x = 3 * l + 4 * l * g),
                o && (w = -w),
                h || (y = w,
                w = 0);
                var T = "rotateX(" + (h ? 0 : -m) + "deg) rotateY(" + (h ? m : 0) + "deg) translate3d(" + w + "px, " + y + "px, " + x + "px)";
                if (b <= 1 && b > -1 && (c = 90 * f + 90 * b,
                o && (c = 90 * -f - 90 * b)),
                v.transform(T),
                d.slideShadows) {
                    var E = h ? v.find(".swiper-slide-shadow-left") : v.find(".swiper-slide-shadow-top")
                      , S = h ? v.find(".swiper-slide-shadow-right") : v.find(".swiper-slide-shadow-bottom");
                    0 === E.length && (E = s('<div class="swiper-slide-shadow-' + (h ? "left" : "top") + '"></div>'),
                    v.append(E)),
                    0 === S.length && (S = s('<div class="swiper-slide-shadow-' + (h ? "right" : "bottom") + '"></div>'),
                    v.append(S)),
                    E.length && (E[0].style.opacity = Math.max(-b, 0)),
                    S.length && (S[0].style.opacity = Math.max(b, 0))
                }
            }
            if (i.css({
                "-webkit-transform-origin": "50% 50% -" + l / 2 + "px",
                "-moz-transform-origin": "50% 50% -" + l / 2 + "px",
                "-ms-transform-origin": "50% 50% -" + l / 2 + "px",
                "transform-origin": "50% 50% -" + l / 2 + "px"
            }),
            d.shadow)
                if (h)
                    e.transform("translate3d(0px, " + (r / 2 + d.shadowOffset) + "px, " + -r / 2 + "px) rotateX(90deg) rotateZ(0deg) scale(" + d.shadowScale + ")");
                else {
                    var C = Math.abs(c) - 90 * Math.floor(Math.abs(c) / 90)
                      , M = 1.5 - (Math.sin(2 * C * Math.PI / 360) / 2 + Math.cos(2 * C * Math.PI / 360) / 2)
                      , P = d.shadowScale
                      , z = d.shadowScale / M
                      , k = d.shadowOffset;
                    e.transform("scale3d(" + P + ", 1, " + z + ") translate3d(0px, " + (n / 2 + k) + "px, " + -n / 2 / z + "px) rotateX(-90deg)")
                }
            var $ = j.isSafari || j.isUiWebView ? -l / 2 : 0;
            i.transform("translate3d(0px,0," + $ + "px) rotateX(" + (this.isHorizontal() ? 0 : c) + "deg) rotateY(" + (this.isHorizontal() ? -c : 0) + "deg)")
        },
        setTransition: function(e) {
            var t = this.$el;
            this.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e),
            this.params.cubeEffect.shadow && !this.isHorizontal() && t.find(".swiper-cube-shadow").transition(e)
        }
    }
      , me = {
        setTranslate: function() {
            for (var e = this.slides, t = this.rtlTranslate, i = 0; i < e.length; i += 1) {
                var a = e.eq(i)
                  , r = a[0].progress;
                this.params.flipEffect.limitRotation && (r = Math.max(Math.min(a[0].progress, 1), -1));
                var n = -180 * r
                  , o = 0
                  , l = -a[0].swiperSlideOffset
                  , d = 0;
                if (this.isHorizontal() ? t && (n = -n) : (d = l,
                l = 0,
                o = -n,
                n = 0),
                a[0].style.zIndex = -Math.abs(Math.round(r)) + e.length,
                this.params.flipEffect.slideShadows) {
                    var h = this.isHorizontal() ? a.find(".swiper-slide-shadow-left") : a.find(".swiper-slide-shadow-top")
                      , p = this.isHorizontal() ? a.find(".swiper-slide-shadow-right") : a.find(".swiper-slide-shadow-bottom");
                    0 === h.length && (h = s('<div class="swiper-slide-shadow-' + (this.isHorizontal() ? "left" : "top") + '"></div>'),
                    a.append(h)),
                    0 === p.length && (p = s('<div class="swiper-slide-shadow-' + (this.isHorizontal() ? "right" : "bottom") + '"></div>'),
                    a.append(p)),
                    h.length && (h[0].style.opacity = Math.max(-r, 0)),
                    p.length && (p[0].style.opacity = Math.max(r, 0))
                }
                a.transform("translate3d(" + l + "px, " + d + "px, 0px) rotateX(" + o + "deg) rotateY(" + n + "deg)")
            }
        },
        setTransition: function(e) {
            var t = this
              , i = t.slides
              , s = t.activeIndex
              , a = t.$wrapperEl;
            if (i.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e),
            t.params.virtualTranslate && 0 !== e) {
                var r = !1;
                i.eq(s).transitionEnd((function() {
                    if (!r && t && !t.destroyed) {
                        r = !0,
                        t.animating = !1;
                        for (var e = ["webkitTransitionEnd", "transitionend"], i = 0; i < e.length; i += 1)
                            a.trigger(e[i])
                    }
                }
                ))
            }
        }
    }
      , ge = {
        setTranslate: function() {
            for (var e = this.width, t = this.height, i = this.slides, a = this.$wrapperEl, r = this.slidesSizesGrid, n = this.params.coverflowEffect, l = this.isHorizontal(), d = this.translate, h = l ? e / 2 - d : t / 2 - d, p = l ? n.rotate : -n.rotate, c = n.depth, u = 0, v = i.length; u < v; u += 1) {
                var f = i.eq(u)
                  , m = r[u]
                  , g = (h - f[0].swiperSlideOffset - m / 2) / m * n.modifier
                  , b = l ? p * g : 0
                  , w = l ? 0 : p * g
                  , y = -c * Math.abs(g)
                  , x = n.stretch;
                "string" == typeof x && -1 !== x.indexOf("%") && (x = parseFloat(n.stretch) / 100 * m);
                var T = l ? 0 : x * g
                  , E = l ? x * g : 0;
                Math.abs(E) < .001 && (E = 0),
                Math.abs(T) < .001 && (T = 0),
                Math.abs(y) < .001 && (y = 0),
                Math.abs(b) < .001 && (b = 0),
                Math.abs(w) < .001 && (w = 0);
                var S = "translate3d(" + E + "px," + T + "px," + y + "px)  rotateX(" + w + "deg) rotateY(" + b + "deg)";
                if (f.transform(S),
                f[0].style.zIndex = 1 - Math.abs(Math.round(g)),
                n.slideShadows) {
                    var C = l ? f.find(".swiper-slide-shadow-left") : f.find(".swiper-slide-shadow-top")
                      , M = l ? f.find(".swiper-slide-shadow-right") : f.find(".swiper-slide-shadow-bottom");
                    0 === C.length && (C = s('<div class="swiper-slide-shadow-' + (l ? "left" : "top") + '"></div>'),
                    f.append(C)),
                    0 === M.length && (M = s('<div class="swiper-slide-shadow-' + (l ? "right" : "bottom") + '"></div>'),
                    f.append(M)),
                    C.length && (C[0].style.opacity = g > 0 ? g : 0),
                    M.length && (M[0].style.opacity = -g > 0 ? -g : 0)
                }
            }
            (o.pointerEvents || o.prefixedPointerEvents) && (a[0].style.perspectiveOrigin = h + "px 50%")
        },
        setTransition: function(e) {
            this.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e)
        }
    }
      , be = {
        init: function() {
            var e = this.params.thumbs
              , t = this.constructor;
            e.swiper instanceof t ? (this.thumbs.swiper = e.swiper,
            n.extend(this.thumbs.swiper.originalParams, {
                watchSlidesProgress: !0,
                slideToClickedSlide: !1
            }),
            n.extend(this.thumbs.swiper.params, {
                watchSlidesProgress: !0,
                slideToClickedSlide: !1
            })) : n.isObject(e.swiper) && (this.thumbs.swiper = new t(n.extend({}, e.swiper, {
                watchSlidesVisibility: !0,
                watchSlidesProgress: !0,
                slideToClickedSlide: !1
            })),
            this.thumbs.swiperCreated = !0),
            this.thumbs.swiper.$el.addClass(this.params.thumbs.thumbsContainerClass),
            this.thumbs.swiper.on("tap", this.thumbs.onThumbClick)
        },
        onThumbClick: function() {
            var e = this.thumbs.swiper;
            if (e) {
                var t = e.clickedIndex
                  , i = e.clickedSlide;
                if (!(i && s(i).hasClass(this.params.thumbs.slideThumbActiveClass) || null == t)) {
                    var a;
                    if (a = e.params.loop ? parseInt(s(e.clickedSlide).attr("data-swiper-slide-index"), 10) : t,
                    this.params.loop) {
                        var r = this.activeIndex;
                        this.slides.eq(r).hasClass(this.params.slideDuplicateClass) && (this.loopFix(),
                        this._clientLeft = this.$wrapperEl[0].clientLeft,
                        r = this.activeIndex);
                        var n = this.slides.eq(r).prevAll('[data-swiper-slide-index="' + a + '"]').eq(0).index()
                          , o = this.slides.eq(r).nextAll('[data-swiper-slide-index="' + a + '"]').eq(0).index();
                        a = void 0 === n ? o : void 0 === o ? n : o - r < r - n ? o : n
                    }
                    this.slideTo(a)
                }
            }
        },
        update: function(e) {
            var t = this.thumbs.swiper;
            if (t) {
                var i = "auto" === t.params.slidesPerView ? t.slidesPerViewDynamic() : t.params.slidesPerView;
                if (this.realIndex !== t.realIndex) {
                    var s, a = t.activeIndex;
                    if (t.params.loop) {
                        t.slides.eq(a).hasClass(t.params.slideDuplicateClass) && (t.loopFix(),
                        t._clientLeft = t.$wrapperEl[0].clientLeft,
                        a = t.activeIndex);
                        var r = t.slides.eq(a).prevAll('[data-swiper-slide-index="' + this.realIndex + '"]').eq(0).index()
                          , n = t.slides.eq(a).nextAll('[data-swiper-slide-index="' + this.realIndex + '"]').eq(0).index();
                        s = void 0 === r ? n : void 0 === n ? r : n - a == a - r ? a : n - a < a - r ? n : r
                    } else
                        s = this.realIndex;
                    t.visibleSlidesIndexes && t.visibleSlidesIndexes.indexOf(s) < 0 && (t.params.centeredSlides ? s = s > a ? s - Math.floor(i / 2) + 1 : s + Math.floor(i / 2) - 1 : s > a && (s = s - i + 1),
                    t.slideTo(s, e ? 0 : void 0))
                }
                var o = 1
                  , l = this.params.thumbs.slideThumbActiveClass;
                if (this.params.slidesPerView > 1 && !this.params.centeredSlides && (o = this.params.slidesPerView),
                this.params.thumbs.multipleActiveThumbs || (o = 1),
                o = Math.floor(o),
                t.slides.removeClass(l),
                t.params.loop || t.params.virtual && t.params.virtual.enabled)
                    for (var d = 0; d < o; d += 1)
                        t.$wrapperEl.children('[data-swiper-slide-index="' + (this.realIndex + d) + '"]').addClass(l);
                else
                    for (var h = 0; h < o; h += 1)
                        t.slides.eq(this.realIndex + h).addClass(l)
            }
        }
    }
      , we = [R, q, K, U, Z, J, te, {
        name: "mousewheel",
        params: {
            mousewheel: {
                enabled: !1,
                releaseOnEdges: !1,
                invert: !1,
                forceToAxis: !1,
                sensitivity: 1,
                eventsTarged: "container"
            }
        },
        create: function() {
            n.extend(this, {
                mousewheel: {
                    enabled: !1,
                    enable: ie.enable.bind(this),
                    disable: ie.disable.bind(this),
                    handle: ie.handle.bind(this),
                    handleMouseEnter: ie.handleMouseEnter.bind(this),
                    handleMouseLeave: ie.handleMouseLeave.bind(this),
                    animateSlider: ie.animateSlider.bind(this),
                    releaseScroll: ie.releaseScroll.bind(this),
                    lastScrollTime: n.now(),
                    lastEventBeforeSnap: void 0,
                    recentWheelEvents: []
                }
            })
        },
        on: {
            init: function() {
                !this.params.mousewheel.enabled && this.params.cssMode && this.mousewheel.disable(),
                this.params.mousewheel.enabled && this.mousewheel.enable()
            },
            destroy: function() {
                this.params.cssMode && this.mousewheel.enable(),
                this.mousewheel.enabled && this.mousewheel.disable()
            }
        }
    }, {
        name: "navigation",
        params: {
            navigation: {
                nextEl: null,
                prevEl: null,
                hideOnClick: !1,
                disabledClass: "swiper-button-disabled",
                hiddenClass: "swiper-button-hidden",
                lockClass: "swiper-button-lock"
            }
        },
        create: function() {
            n.extend(this, {
                navigation: {
                    init: se.init.bind(this),
                    update: se.update.bind(this),
                    destroy: se.destroy.bind(this),
                    onNextClick: se.onNextClick.bind(this),
                    onPrevClick: se.onPrevClick.bind(this)
                }
            })
        },
        on: {
            init: function() {
                this.navigation.init(),
                this.navigation.update()
            },
            toEdge: function() {
                this.navigation.update()
            },
            fromEdge: function() {
                this.navigation.update()
            },
            destroy: function() {
                this.navigation.destroy()
            },
            click: function(e) {
                var t, i = this.navigation, a = i.$nextEl, r = i.$prevEl;
                !this.params.navigation.hideOnClick || s(e.target).is(r) || s(e.target).is(a) || (a ? t = a.hasClass(this.params.navigation.hiddenClass) : r && (t = r.hasClass(this.params.navigation.hiddenClass)),
                !0 === t ? this.emit("navigationShow", this) : this.emit("navigationHide", this),
                a && a.toggleClass(this.params.navigation.hiddenClass),
                r && r.toggleClass(this.params.navigation.hiddenClass))
            }
        }
    }, {
        name: "pagination",
        params: {
            pagination: {
                el: null,
                bulletElement: "span",
                clickable: !1,
                hideOnClick: !1,
                renderBullet: null,
                renderProgressbar: null,
                renderFraction: null,
                renderCustom: null,
                progressbarOpposite: !1,
                type: "bullets",
                dynamicBullets: !1,
                dynamicMainBullets: 1,
                formatFractionCurrent: function(e) {
                    return e
                },
                formatFractionTotal: function(e) {
                    return e
                },
                bulletClass: "swiper-pagination-bullet",
                bulletActiveClass: "swiper-pagination-bullet-active",
                modifierClass: "swiper-pagination-",
                currentClass: "swiper-pagination-current",
                totalClass: "swiper-pagination-total",
                hiddenClass: "swiper-pagination-hidden",
                progressbarFillClass: "swiper-pagination-progressbar-fill",
                progressbarOppositeClass: "swiper-pagination-progressbar-opposite",
                clickableClass: "swiper-pagination-clickable",
                lockClass: "swiper-pagination-lock"
            }
        },
        create: function() {
            n.extend(this, {
                pagination: {
                    init: ae.init.bind(this),
                    render: ae.render.bind(this),
                    update: ae.update.bind(this),
                    destroy: ae.destroy.bind(this),
                    dynamicBulletIndex: 0
                }
            })
        },
        on: {
            init: function() {
                this.pagination.init(),
                this.pagination.render(),
                this.pagination.update()
            },
            activeIndexChange: function() {
                this.params.loop ? this.pagination.update() : void 0 === this.snapIndex && this.pagination.update()
            },
            snapIndexChange: function() {
                this.params.loop || this.pagination.update()
            },
            slidesLengthChange: function() {
                this.params.loop && (this.pagination.render(),
                this.pagination.update())
            },
            snapGridLengthChange: function() {
                this.params.loop || (this.pagination.render(),
                this.pagination.update())
            },
            destroy: function() {
                this.pagination.destroy()
            },
            click: function(e) {
                this.params.pagination.el && this.params.pagination.hideOnClick && this.pagination.$el.length > 0 && !s(e.target).hasClass(this.params.pagination.bulletClass) && (!0 === this.pagination.$el.hasClass(this.params.pagination.hiddenClass) ? this.emit("paginationShow", this) : this.emit("paginationHide", this),
                this.pagination.$el.toggleClass(this.params.pagination.hiddenClass))
            }
        }
    }, {
        name: "scrollbar",
        params: {
            scrollbar: {
                el: null,
                dragSize: "auto",
                hide: !1,
                draggable: !1,
                snapOnRelease: !0,
                lockClass: "swiper-scrollbar-lock",
                dragClass: "swiper-scrollbar-drag"
            }
        },
        create: function() {
            n.extend(this, {
                scrollbar: {
                    init: re.init.bind(this),
                    destroy: re.destroy.bind(this),
                    updateSize: re.updateSize.bind(this),
                    setTranslate: re.setTranslate.bind(this),
                    setTransition: re.setTransition.bind(this),
                    enableDraggable: re.enableDraggable.bind(this),
                    disableDraggable: re.disableDraggable.bind(this),
                    setDragPosition: re.setDragPosition.bind(this),
                    getPointerPosition: re.getPointerPosition.bind(this),
                    onDragStart: re.onDragStart.bind(this),
                    onDragMove: re.onDragMove.bind(this),
                    onDragEnd: re.onDragEnd.bind(this),
                    isTouched: !1,
                    timeout: null,
                    dragTimeout: null
                }
            })
        },
        on: {
            init: function() {
                this.scrollbar.init(),
                this.scrollbar.updateSize(),
                this.scrollbar.setTranslate()
            },
            update: function() {
                this.scrollbar.updateSize()
            },
            resize: function() {
                this.scrollbar.updateSize()
            },
            observerUpdate: function() {
                this.scrollbar.updateSize()
            },
            setTranslate: function() {
                this.scrollbar.setTranslate()
            },
            setTransition: function(e) {
                this.scrollbar.setTransition(e)
            },
            destroy: function() {
                this.scrollbar.destroy()
            }
        }
    }, {
        name: "parallax",
        params: {
            parallax: {
                enabled: !1
            }
        },
        create: function() {
            n.extend(this, {
                parallax: {
                    setTransform: ne.setTransform.bind(this),
                    setTranslate: ne.setTranslate.bind(this),
                    setTransition: ne.setTransition.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                this.params.parallax.enabled && (this.params.watchSlidesProgress = !0,
                this.originalParams.watchSlidesProgress = !0)
            },
            init: function() {
                this.params.parallax.enabled && this.parallax.setTranslate()
            },
            setTranslate: function() {
                this.params.parallax.enabled && this.parallax.setTranslate()
            },
            setTransition: function(e) {
                this.params.parallax.enabled && this.parallax.setTransition(e)
            }
        }
    }, {
        name: "zoom",
        params: {
            zoom: {
                enabled: !1,
                maxRatio: 3,
                minRatio: 1,
                toggle: !0,
                containerClass: "swiper-zoom-container",
                zoomedSlideClass: "swiper-slide-zoomed"
            }
        },
        create: function() {
            var e = this
              , t = {
                enabled: !1,
                scale: 1,
                currentScale: 1,
                isScaling: !1,
                gesture: {
                    $slideEl: void 0,
                    slideWidth: void 0,
                    slideHeight: void 0,
                    $imageEl: void 0,
                    $imageWrapEl: void 0,
                    maxRatio: 3
                },
                image: {
                    isTouched: void 0,
                    isMoved: void 0,
                    currentX: void 0,
                    currentY: void 0,
                    minX: void 0,
                    minY: void 0,
                    maxX: void 0,
                    maxY: void 0,
                    width: void 0,
                    height: void 0,
                    startX: void 0,
                    startY: void 0,
                    touchesStart: {},
                    touchesCurrent: {}
                },
                velocity: {
                    x: void 0,
                    y: void 0,
                    prevPositionX: void 0,
                    prevPositionY: void 0,
                    prevTime: void 0
                }
            };
            "onGestureStart onGestureChange onGestureEnd onTouchStart onTouchMove onTouchEnd onTransitionEnd toggle enable disable in out".split(" ").forEach((function(i) {
                t[i] = oe[i].bind(e)
            }
            )),
            n.extend(e, {
                zoom: t
            });
            var i = 1;
            Object.defineProperty(e.zoom, "scale", {
                get: function() {
                    return i
                },
                set: function(t) {
                    if (i !== t) {
                        var s = e.zoom.gesture.$imageEl ? e.zoom.gesture.$imageEl[0] : void 0
                          , a = e.zoom.gesture.$slideEl ? e.zoom.gesture.$slideEl[0] : void 0;
                        e.emit("zoomChange", t, s, a)
                    }
                    i = t
                }
            })
        },
        on: {
            init: function() {
                this.params.zoom.enabled && this.zoom.enable()
            },
            destroy: function() {
                this.zoom.disable()
            },
            touchStart: function(e) {
                this.zoom.enabled && this.zoom.onTouchStart(e)
            },
            touchEnd: function(e) {
                this.zoom.enabled && this.zoom.onTouchEnd(e)
            },
            doubleTap: function(e) {
                this.params.zoom.enabled && this.zoom.enabled && this.params.zoom.toggle && this.zoom.toggle(e)
            },
            transitionEnd: function() {
                this.zoom.enabled && this.params.zoom.enabled && this.zoom.onTransitionEnd()
            },
            slideChange: function() {
                this.zoom.enabled && this.params.zoom.enabled && this.params.cssMode && this.zoom.onTransitionEnd()
            }
        }
    }, {
        name: "lazy",
        params: {
            lazy: {
                enabled: !1,
                loadPrevNext: !1,
                loadPrevNextAmount: 1,
                loadOnTransitionStart: !1,
                elementClass: "swiper-lazy",
                loadingClass: "swiper-lazy-loading",
                loadedClass: "swiper-lazy-loaded",
                preloaderClass: "swiper-lazy-preloader"
            }
        },
        create: function() {
            n.extend(this, {
                lazy: {
                    initialImageLoaded: !1,
                    load: le.load.bind(this),
                    loadInSlide: le.loadInSlide.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                this.params.lazy.enabled && this.params.preloadImages && (this.params.preloadImages = !1)
            },
            init: function() {
                this.params.lazy.enabled && !this.params.loop && 0 === this.params.initialSlide && this.lazy.load()
            },
            scroll: function() {
                this.params.freeMode && !this.params.freeModeSticky && this.lazy.load()
            },
            resize: function() {
                this.params.lazy.enabled && this.lazy.load()
            },
            scrollbarDragMove: function() {
                this.params.lazy.enabled && this.lazy.load()
            },
            transitionStart: function() {
                this.params.lazy.enabled && (this.params.lazy.loadOnTransitionStart || !this.params.lazy.loadOnTransitionStart && !this.lazy.initialImageLoaded) && this.lazy.load()
            },
            transitionEnd: function() {
                this.params.lazy.enabled && !this.params.lazy.loadOnTransitionStart && this.lazy.load()
            },
            slideChange: function() {
                this.params.lazy.enabled && this.params.cssMode && this.lazy.load()
            }
        }
    }, {
        name: "controller",
        params: {
            controller: {
                control: void 0,
                inverse: !1,
                by: "slide"
            }
        },
        create: function() {
            n.extend(this, {
                controller: {
                    control: this.params.controller.control,
                    getInterpolateFunction: de.getInterpolateFunction.bind(this),
                    setTranslate: de.setTranslate.bind(this),
                    setTransition: de.setTransition.bind(this)
                }
            })
        },
        on: {
            update: function() {
                this.controller.control && this.controller.spline && (this.controller.spline = void 0,
                delete this.controller.spline)
            },
            resize: function() {
                this.controller.control && this.controller.spline && (this.controller.spline = void 0,
                delete this.controller.spline)
            },
            observerUpdate: function() {
                this.controller.control && this.controller.spline && (this.controller.spline = void 0,
                delete this.controller.spline)
            },
            setTranslate: function(e, t) {
                this.controller.control && this.controller.setTranslate(e, t)
            },
            setTransition: function(e, t) {
                this.controller.control && this.controller.setTransition(e, t)
            }
        }
    }, {
        name: "a11y",
        params: {
            a11y: {
                enabled: !0,
                notificationClass: "swiper-notification",
                prevSlideMessage: "Previous slide",
                nextSlideMessage: "Next slide",
                firstSlideMessage: "This is the first slide",
                lastSlideMessage: "This is the last slide",
                paginationBulletMessage: "Go to slide {{index}}"
            }
        },
        create: function() {
            var e = this;
            n.extend(e, {
                a11y: {
                    liveRegion: s('<span class="' + e.params.a11y.notificationClass + '" aria-live="assertive" aria-atomic="true"></span>')
                }
            }),
            Object.keys(he).forEach((function(t) {
                e.a11y[t] = he[t].bind(e)
            }
            ))
        },
        on: {
            init: function() {
                this.params.a11y.enabled && (this.a11y.init(),
                this.a11y.updateNavigation())
            },
            toEdge: function() {
                this.params.a11y.enabled && this.a11y.updateNavigation()
            },
            fromEdge: function() {
                this.params.a11y.enabled && this.a11y.updateNavigation()
            },
            paginationUpdate: function() {
                this.params.a11y.enabled && this.a11y.updatePagination()
            },
            destroy: function() {
                this.params.a11y.enabled && this.a11y.destroy()
            }
        }
    }, {
        name: "history",
        params: {
            history: {
                enabled: !1,
                replaceState: !1,
                key: "slides"
            }
        },
        create: function() {
            n.extend(this, {
                history: {
                    init: pe.init.bind(this),
                    setHistory: pe.setHistory.bind(this),
                    setHistoryPopState: pe.setHistoryPopState.bind(this),
                    scrollToSlide: pe.scrollToSlide.bind(this),
                    destroy: pe.destroy.bind(this)
                }
            })
        },
        on: {
            init: function() {
                this.params.history.enabled && this.history.init()
            },
            destroy: function() {
                this.params.history.enabled && this.history.destroy()
            },
            transitionEnd: function() {
                this.history.initialized && this.history.setHistory(this.params.history.key, this.activeIndex)
            },
            slideChange: function() {
                this.history.initialized && this.params.cssMode && this.history.setHistory(this.params.history.key, this.activeIndex)
            }
        }
    }, {
        name: "hash-navigation",
        params: {
            hashNavigation: {
                enabled: !1,
                replaceState: !1,
                watchState: !1
            }
        },
        create: function() {
            n.extend(this, {
                hashNavigation: {
                    initialized: !1,
                    init: ce.init.bind(this),
                    destroy: ce.destroy.bind(this),
                    setHash: ce.setHash.bind(this),
                    onHashCange: ce.onHashCange.bind(this)
                }
            })
        },
        on: {
            init: function() {
                this.params.hashNavigation.enabled && this.hashNavigation.init()
            },
            destroy: function() {
                this.params.hashNavigation.enabled && this.hashNavigation.destroy()
            },
            transitionEnd: function() {
                this.hashNavigation.initialized && this.hashNavigation.setHash()
            },
            slideChange: function() {
                this.hashNavigation.initialized && this.params.cssMode && this.hashNavigation.setHash()
            }
        }
    }, {
        name: "autoplay",
        params: {
            autoplay: {
                enabled: !1,
                delay: 3e3,
                waitForTransition: !0,
                disableOnInteraction: !0,
                stopOnLastSlide: !1,
                reverseDirection: !1
            }
        },
        create: function() {
            var e = this;
            n.extend(e, {
                autoplay: {
                    running: !1,
                    paused: !1,
                    run: ue.run.bind(e),
                    start: ue.start.bind(e),
                    stop: ue.stop.bind(e),
                    pause: ue.pause.bind(e),
                    onVisibilityChange: function() {
                        "hidden" === document.visibilityState && e.autoplay.running && e.autoplay.pause(),
                        "visible" === document.visibilityState && e.autoplay.paused && (e.autoplay.run(),
                        e.autoplay.paused = !1)
                    },
                    onTransitionEnd: function(t) {
                        e && !e.destroyed && e.$wrapperEl && t.target === this && (e.$wrapperEl[0].removeEventListener("transitionend", e.autoplay.onTransitionEnd),
                        e.$wrapperEl[0].removeEventListener("webkitTransitionEnd", e.autoplay.onTransitionEnd),
                        e.autoplay.paused = !1,
                        e.autoplay.running ? e.autoplay.run() : e.autoplay.stop())
                    }
                }
            })
        },
        on: {
            init: function() {
                this.params.autoplay.enabled && (this.autoplay.start(),
                document.addEventListener("visibilitychange", this.autoplay.onVisibilityChange))
            },
            beforeTransitionStart: function(e, t) {
                this.autoplay.running && (t || !this.params.autoplay.disableOnInteraction ? this.autoplay.pause(e) : this.autoplay.stop())
            },
            sliderFirstMove: function() {
                this.autoplay.running && (this.params.autoplay.disableOnInteraction ? this.autoplay.stop() : this.autoplay.pause())
            },
            touchEnd: function() {
                this.params.cssMode && this.autoplay.paused && !this.params.autoplay.disableOnInteraction && this.autoplay.run()
            },
            destroy: function() {
                this.autoplay.running && this.autoplay.stop(),
                document.removeEventListener("visibilitychange", this.autoplay.onVisibilityChange)
            }
        }
    }, {
        name: "effect-fade",
        params: {
            fadeEffect: {
                crossFade: !1
            }
        },
        create: function() {
            n.extend(this, {
                fadeEffect: {
                    setTranslate: ve.setTranslate.bind(this),
                    setTransition: ve.setTransition.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                if ("fade" === this.params.effect) {
                    this.classNames.push(this.params.containerModifierClass + "fade");
                    var e = {
                        slidesPerView: 1,
                        slidesPerColumn: 1,
                        slidesPerGroup: 1,
                        watchSlidesProgress: !0,
                        spaceBetween: 0,
                        virtualTranslate: !0
                    };
                    n.extend(this.params, e),
                    n.extend(this.originalParams, e)
                }
            },
            setTranslate: function() {
                "fade" === this.params.effect && this.fadeEffect.setTranslate()
            },
            setTransition: function(e) {
                "fade" === this.params.effect && this.fadeEffect.setTransition(e)
            }
        }
    }, {
        name: "effect-cube",
        params: {
            cubeEffect: {
                slideShadows: !0,
                shadow: !0,
                shadowOffset: 20,
                shadowScale: .94
            }
        },
        create: function() {
            n.extend(this, {
                cubeEffect: {
                    setTranslate: fe.setTranslate.bind(this),
                    setTransition: fe.setTransition.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                if ("cube" === this.params.effect) {
                    this.classNames.push(this.params.containerModifierClass + "cube"),
                    this.classNames.push(this.params.containerModifierClass + "3d");
                    var e = {
                        slidesPerView: 1,
                        slidesPerColumn: 1,
                        slidesPerGroup: 1,
                        watchSlidesProgress: !0,
                        resistanceRatio: 0,
                        spaceBetween: 0,
                        centeredSlides: !1,
                        virtualTranslate: !0
                    };
                    n.extend(this.params, e),
                    n.extend(this.originalParams, e)
                }
            },
            setTranslate: function() {
                "cube" === this.params.effect && this.cubeEffect.setTranslate()
            },
            setTransition: function(e) {
                "cube" === this.params.effect && this.cubeEffect.setTransition(e)
            }
        }
    }, {
        name: "effect-flip",
        params: {
            flipEffect: {
                slideShadows: !0,
                limitRotation: !0
            }
        },
        create: function() {
            n.extend(this, {
                flipEffect: {
                    setTranslate: me.setTranslate.bind(this),
                    setTransition: me.setTransition.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                if ("flip" === this.params.effect) {
                    this.classNames.push(this.params.containerModifierClass + "flip"),
                    this.classNames.push(this.params.containerModifierClass + "3d");
                    var e = {
                        slidesPerView: 1,
                        slidesPerColumn: 1,
                        slidesPerGroup: 1,
                        watchSlidesProgress: !0,
                        spaceBetween: 0,
                        virtualTranslate: !0
                    };
                    n.extend(this.params, e),
                    n.extend(this.originalParams, e)
                }
            },
            setTranslate: function() {
                "flip" === this.params.effect && this.flipEffect.setTranslate()
            },
            setTransition: function(e) {
                "flip" === this.params.effect && this.flipEffect.setTransition(e)
            }
        }
    }, {
        name: "effect-coverflow",
        params: {
            coverflowEffect: {
                rotate: 50,
                stretch: 0,
                depth: 100,
                modifier: 1,
                slideShadows: !0
            }
        },
        create: function() {
            n.extend(this, {
                coverflowEffect: {
                    setTranslate: ge.setTranslate.bind(this),
                    setTransition: ge.setTransition.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                "coverflow" === this.params.effect && (this.classNames.push(this.params.containerModifierClass + "coverflow"),
                this.classNames.push(this.params.containerModifierClass + "3d"),
                this.params.watchSlidesProgress = !0,
                this.originalParams.watchSlidesProgress = !0)
            },
            setTranslate: function() {
                "coverflow" === this.params.effect && this.coverflowEffect.setTranslate()
            },
            setTransition: function(e) {
                "coverflow" === this.params.effect && this.coverflowEffect.setTransition(e)
            }
        }
    }, {
        name: "thumbs",
        params: {
            thumbs: {
                multipleActiveThumbs: !0,
                swiper: null,
                slideThumbActiveClass: "swiper-slide-thumb-active",
                thumbsContainerClass: "swiper-container-thumbs"
            }
        },
        create: function() {
            n.extend(this, {
                thumbs: {
                    swiper: null,
                    init: be.init.bind(this),
                    update: be.update.bind(this),
                    onThumbClick: be.onThumbClick.bind(this)
                }
            })
        },
        on: {
            beforeInit: function() {
                var e = this.params.thumbs;
                e && e.swiper && (this.thumbs.init(),
                this.thumbs.update(!0))
            },
            slideChange: function() {
                this.thumbs.swiper && this.thumbs.update()
            },
            update: function() {
                this.thumbs.swiper && this.thumbs.update()
            },
            resize: function() {
                this.thumbs.swiper && this.thumbs.update()
            },
            observerUpdate: function() {
                this.thumbs.swiper && this.thumbs.update()
            },
            setTransition: function(e) {
                var t = this.thumbs.swiper;
                t && t.setTransition(e)
            },
            beforeDestroy: function() {
                var e = this.thumbs.swiper;
                e && this.thumbs.swiperCreated && e && e.destroy()
            }
        }
    }];
    return void 0 === W.use && (W.use = W.Class.use,
    W.installModule = W.Class.installModule),
    W.use(we),
    W
}
));
