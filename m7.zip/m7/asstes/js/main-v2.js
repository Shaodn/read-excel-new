(function () {
    'use strict';
    let html = document.documentElement,
        screenWidth = html.clientWidth,
        screenHeight = html.clientHeight,
        isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches,
        ua = navigator.userAgent.toLowerCase(),
        isUC = ua.indexOf('ucbrowser') !== -1,
        isWeChat = ua.indexOf('micromessenger') !== -1,
        controller = new ScrollMagic.Controller(),
        main = document.body.querySelector('main'),
        isIE11 = !!window.ActiveXObject || "ActiveXObject" in window;

    if (window.NodeList && !NodeList.prototype.forEach) {
        NodeList.prototype.forEach = Array.prototype.forEach;
    }

    function tlClassToggle(element, className) {
        return function () {
            element.classList.toggle(className);
        };
    }

    const SUPPORT = {
        sticky: false,
        intersectionObserver: false,
        init: function () {
            if (!!(window.CSS && window.CSS.supports || window.supportsCSS || false)) {
                if (CSS.supports('position', '-webkit-sticky') || CSS.supports('position', 'sticky')) {
                    this.sticky = true;
                } else {
                    this.sticky = false;
                    html.classList.add('no-sticky');
                }
            } else {
                this.sticky = false;
                html.classList.add('no-sticky');
            }

            if (!('IntersectionObserver' in window) || !('IntersectionObserverEntry' in window) || !('intersectionRatio' in window.IntersectionObserverEntry.prototype)) {
                this.intersectionObserver = false;
            } else {
                this.intersectionObserver = true;
            }
        },
    };

    const COMMON = {
        init: function () {
            gsap.defaults({
                duration: 1,
            });
            this.setupGA();
            this.setupPopupMediaGA();
            this.setupMedia();
            this.setupPopupMedia();
            this.setupWillChange();
            this.setupPopupMediaGAWatch1();
            this.setupPopupMediaGAWatch2();
            this.setupPopupMediaGAWatch3();

            let resizeTimeOut,
                self = this;

            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    self.setupMedia();
                }, 66);
            });
        },
        setupGA: function () {
            const heroTestDrive = document.getElementById('hero-test-drive');
            heroTestDrive.addEventListener('click', function (button) {
                window.dataLayer.push({
                    'event': 'reservation_intent',
                    'page_name': window.pageInfo.pageName,
                    'booking_position': 'Product KV',
                    'page_category2': window.pageInfo.pageCategory2
                });

                window.dataLayer.push({
                    'event': 'PDP_banner_interaction',
                    'page_name': window.pageInfo.pageName,
                    'banner_name': 'AITO | 问界 M5 行无界 智千里',
                    'banner_position': 'Top',
                    'link_destination': 'https://aito.auto/model/m5/test-drive/',
                    'click_area': '预约试驾'
                });
            });

            const buttonLinks = main.querySelectorAll('.section-button-link');
            buttonLinks.forEach(function (button) {
                button.addEventListener('click', function () {
                    window.dataLayer.push({
                        'event': 'PDP_banner_interaction',
                        'page_name': window.pageInfo.pageName,
                        'banner_name': button.getAttribute('data-ga-banner-name'),
                        'banner_position': button.getAttribute('data-ga-banner-position'),
                        'link_destination': button.href,
                        'click_area': button.innerText
                    });
                });
            });
        },
        setupPopupMediaGA: function () {
            const tvcButton = main.querySelector('#watch-tvc .popup-video-button');
            const tvcVideo = main.querySelector('#section-popup-media video');

            let playedPercent = {
                _25: false,
                _50: false,
                _75: false,
                _100: false,
            };

            function pushData(videoName, videoStep) {
                window.dataLayer.push({
                    'event': 'video_interaction',
                    'video_name': videoName,
                    'video_step': videoStep,
                });
            }

            function videoStep(video, videoName) {
                let progress = Math.floor(video.currentTime * 100 / video.duration);

                if (progress >= 25 && progress < 50 && !playedPercent._25) {
                    pushData(videoName, '25%');
                    playedPercent._25 = true;
                } else if (progress >= 50 && progress < 75 && !playedPercent._50) {
                    pushData(videoName, '50%');
                    playedPercent._50 = true;
                } else if (progress >= 75 && progress < 100 && !playedPercent._75) {
                    pushData(videoName, '75%');
                    playedPercent._75 = true;
                }
            }

            function videoStatus(video, videoName) {
                pushData(videoName, 'play');

                video.onpause = function () {
                    if (video.currentTime == 0 || video.currentTime == video.duration) {
                        return false;
                    }
                    pushData(videoName, 'pause');
                };

                video.ontimeupdate = function () {
                    videoStep(video, videoName);
                };

                video.onended = function () {
                    if (!playedPercent._100) {
                        pushData(videoName, '100%');
                        playedPercent._100 = true;
                    }
                };

            }

            tvcButton.addEventListener('click', function () {
                videoStatus(tvcVideo, tvcButton.getAttribute('data-ga-video-name'));
            });

        },
        setupPopupMediaGAWatch1: function () {
            const tvcButton = main.querySelector('#touchscreen-watch1 .popup-video-button');
            const tvcVideo = main.querySelector('#section-popup-media video');

            let playedPercent = {
                _25: false,
                _50: false,
                _75: false,
                _100: false,
            };

            function pushData(videoName, videoStep) {
                window.dataLayer.push({
                    'event': 'video_interaction',
                    'video_name': videoName,
                    'video_step': videoStep,
                });
            }

            function videoStep(video, videoName) {
                let progress = Math.floor(video.currentTime * 100 / video.duration);

                if (progress >= 25 && progress < 50 && !playedPercent._25) {
                    pushData(videoName, '25%');
                    playedPercent._25 = true;
                } else if (progress >= 50 && progress < 75 && !playedPercent._50) {
                    pushData(videoName, '50%');
                    playedPercent._50 = true;
                } else if (progress >= 75 && progress < 100 && !playedPercent._75) {
                    pushData(videoName, '75%');
                    playedPercent._75 = true;
                }
            }

            function videoStatus(video, videoName) {
                pushData(videoName, 'play');

                video.onpause = function () {
                    if (video.currentTime == 0 || video.currentTime == video.duration) {
                        return false;
                    }
                    pushData(videoName, 'pause');
                };

                video.ontimeupdate = function () {
                    videoStep(video, videoName);
                };

                video.onended = function () {
                    if (!playedPercent._100) {
                        pushData(videoName, '100%');
                        playedPercent._100 = true;
                    }
                };

            }

            tvcButton.addEventListener('click', function () {
                videoStatus(tvcVideo, tvcButton.getAttribute('data-ga-video-name'));
            });

        },
        setupPopupMediaGAWatch2: function () {
            const tvcButton = main.querySelector('#touchscreen-watch2 .popup-video-button');
            const tvcVideo = main.querySelector('#section-popup-media video');

            let playedPercent = {
                _25: false,
                _50: false,
                _75: false,
                _100: false,
            };

            function pushData(videoName, videoStep) {
                window.dataLayer.push({
                    'event': 'video_interaction',
                    'video_name': videoName,
                    'video_step': videoStep,
                });
            }

            function videoStep(video, videoName) {
                let progress = Math.floor(video.currentTime * 100 / video.duration);

                if (progress >= 25 && progress < 50 && !playedPercent._25) {
                    pushData(videoName, '25%');
                    playedPercent._25 = true;
                } else if (progress >= 50 && progress < 75 && !playedPercent._50) {
                    pushData(videoName, '50%');
                    playedPercent._50 = true;
                } else if (progress >= 75 && progress < 100 && !playedPercent._75) {
                    pushData(videoName, '75%');
                    playedPercent._75 = true;
                }
            }

            function videoStatus(video, videoName) {
                pushData(videoName, 'play');

                video.onpause = function () {
                    if (video.currentTime == 0 || video.currentTime == video.duration) {
                        return false;
                    }
                    pushData(videoName, 'pause');
                };

                video.ontimeupdate = function () {
                    videoStep(video, videoName);
                };

                video.onended = function () {
                    if (!playedPercent._100) {
                        pushData(videoName, '100%');
                        playedPercent._100 = true;
                    }
                };

            }

            tvcButton.addEventListener('click', function () {
                videoStatus(tvcVideo, tvcButton.getAttribute('data-ga-video-name'));
            });

        },
        setupPopupMediaGAWatch3: function () {
            const tvcButton = main.querySelector('#touchscreen-watch3 .popup-video-button');
            const tvcVideo = main.querySelector('#section-popup-media video');

            let playedPercent = {
                _25: false,
                _50: false,
                _75: false,
                _100: false,
            };

            function pushData(videoName, videoStep) {
                window.dataLayer.push({
                    'event': 'video_interaction',
                    'video_name': videoName,
                    'video_step': videoStep,
                });
            }

            function videoStep(video, videoName) {
                let progress = Math.floor(video.currentTime * 100 / video.duration);

                if (progress >= 25 && progress < 50 && !playedPercent._25) {
                    pushData(videoName, '25%');
                    playedPercent._25 = true;
                } else if (progress >= 50 && progress < 75 && !playedPercent._50) {
                    pushData(videoName, '50%');
                    playedPercent._50 = true;
                } else if (progress >= 75 && progress < 100 && !playedPercent._75) {
                    pushData(videoName, '75%');
                    playedPercent._75 = true;
                }
            }

            function videoStatus(video, videoName) {
                pushData(videoName, 'play');

                video.onpause = function () {
                    if (video.currentTime == 0 || video.currentTime == video.duration) {
                        return false;
                    }
                    pushData(videoName, 'pause');
                };

                video.ontimeupdate = function () {
                    videoStep(video, videoName);
                };

                video.onended = function () {
                    if (!playedPercent._100) {
                        pushData(videoName, '100%');
                        playedPercent._100 = true;
                    }
                };

            }

            tvcButton.addEventListener('click', function () {
                videoStatus(tvcVideo, tvcButton.getAttribute('data-ga-video-name'));
            });

        },
        setupMedia: function () {
            const inlineVideos = main.querySelectorAll('.section-inline-media video');
            inlineVideos.forEach(function (video) {
                // if (isPortrait) {
                //     video.setAttribute('poster', video.getAttribute('data-poster-xs'));
                // } else {
                //     video.setAttribute('poster', video.getAttribute('data-poster'));
                // }
                video.querySelectorAll('source').forEach(function (source) {
                    if (isUC || isWeChat) {
                        return false;
                    }
                    if (video.classList.contains('inline-video')) {
                        if (isPortrait) {
                            source.setAttribute('src', source.getAttribute('data-src-xs'));
                        } else {
                            source.setAttribute('src', source.getAttribute('data-src'));
                        }
                    }
                });
                setTimeout(function () {
                    if (!isWeChat && !isUC) {
                        video.load();
                    }
                }, 100);
                if (isUC || isWeChat) {
                    html.classList.add('no-inline-video');
                }
            });

            inlineVideos.forEach(function (video) {
                video.addEventListener('playing', function () {
                    video.parentElement.classList.remove('pause');
                    video.parentElement.classList.add('playing');
                });
            });

            if (!isWeChat && !isUC) {
                document.addEventListener('visibilitychange', function () {
                    if (document.visibilityState === 'visible') {
                        inlineVideos.forEach(function (video) {
                            if (video.parentElement.classList.contains('pause')) {
                                video.play();
                                video.parentElement.classList.remove('pause');
                                video.parentElement.classList.add('playing');
                            }
                        });
                    } else {
                        inlineVideos.forEach(function (video) {
                            if (video.parentElement.classList.contains('playing')) {
                                video.pause();
                                video.parentElement.classList.remove('playing');
                                video.parentElement.classList.add('pause');
                            }
                        });
                    }
                });
            }
        },
        setupPopupMedia: function () {
            const popupContainer = main.querySelector('#section-popup-media');
            const popupButton = main.querySelectorAll('.popup-video-button');
            const popupVideo = popupContainer.querySelector('video');
            const popupClose = popupContainer.querySelector('#popup-media-close-button');
            const inlineVideos = main.querySelectorAll('.section-inline-media video');
            popupButton.forEach(function (button) {
                button.addEventListener('click', function (e) {
                    e.preventDefault();

                    let video = button.href;
                    let poster = button.getAttribute('data-poster');

                    popupVideo.setAttribute('poster', poster);
                    popupVideo.querySelector('source[type="video/mp4"]').setAttribute('src', video);
                    popupVideo.load();
                    popupContainer.classList.remove('media-closed');
                    popupContainer.classList.add('media-open');
                    // popupContainer.classList.add('media-open', 'media-fadein');
                    // html.classList.add('media-open');
                    // setTimeout(function() {
                    //     popupContainer.classList.remove('media-fadein');
                    // }, 500);
                    inlineVideos.forEach(function (video) {
                        if (video.parentElement.classList.contains('playing')) {
                            video.pause();
                            video.parentElement.classList.remove('playing');
                            video.parentElement.classList.add('pause');
                        }
                    });
                    popupVideo.play();

                    // if (SUPPORT.touch && popupVideo.requestFullscreen) {
                    //     popupVideo.requestFullscreen();
                    //     setTimeout(function() {
                    //         document.addEventListener('fullscreenchange', fullscreenExit, false);
                    //     }, 1500);
                    // }
                });
            });
            document.addEventListener('visibilitychange', function () {
                if (!popupContainer.classList.contains('media-closed')) {
                    if (document.visibilityState === 'visible') {
                        popupVideo.play();
                        popupContainer.classList.remove('pause');
                        popupContainer.classList.add('playing');
                    } else {
                        popupVideo.pause();
                        popupContainer.classList.remove('playing');
                        popupContainer.classList.add('pause');
                    }
                }
            });

            // function fullscreenExit() {
            //     if (document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement !== null) {
            //         closeWindow();
            //         document.removeEventListener('fullscreenchange', fullscreenExit, false);
            //     }
            // }

            function closeWindow() {
                popupVideo.pause();
                popupContainer.classList.remove('media-open');
                popupContainer.classList.add('media-closed');
                popupContainer.classList.remove('playing');
                popupContainer.classList.remove('pause');
                inlineVideos.forEach(function (video) {
                    if (video.parentElement.classList.contains('pause')) {
                        video.play();
                        video.parentElement.classList.add('playing');
                        video.parentElement.classList.remove('pause');
                    }
                });
            }

            popupClose.addEventListener('click', function (e) {
                e.preventDefault();
                closeWindow();
            });

            popupContainer.addEventListener('click', function (e) {
                e.preventDefault();
                closeWindow();
            });

            popupVideo.addEventListener('click', function (e) {
                e.stopPropagation();
            });
        },
        setupWillChange: function () {
            if (SUPPORT.intersectionObserver) {
                const sections = main.querySelectorAll('.section-will-change');
                let io = new IntersectionObserver(
                    function (entries) {
                        entries.forEach(function (entry) {
                            if (entry.intersectionRatio > 0) {
                                sections.forEach(function (section) {
                                    section.classList.remove('will-change');
                                });
                                entry.target.classList.add('will-change');
                            }
                        });
                    }, {
                    rootMargin: "-45% 0% -45% 0%",
                    threshold: [0],
                }
                );

                sections.forEach(function (e) {
                    io.observe(e);
                });
            }
        },
    };
    const MAIN = {
        init: function () {
            this.details();
            this.shifter();
            this.intelligent();
            this.intelligentNew();
            this.enjoy();
            this.technology();
            this.touchscreenXs();
            this.watchControl();
            // this.newAddVideoGA();

            if (SUPPORT.sticky) {
                this.tvc();
                this.superSection();
                this.touchscreen();
            } else {
                this.superSectionFallback();
            }
        },
        tvc: function () {
            // const tvc = document.getElementById('hero-tvc');
            let tl = gsap.timeline()
                .to('#section-brand-logo', {
                    delay: 0.5,
                    duration: 2,
                    scale: 5,
                })
                .to('#section-brand-logo', {
                    duration: 0.3,
                    autoAlpha: 0,
                }, '-=0.4')
                .to('.watch-tvc', {
                    duration: 0.3,
                    autoAlpha: 1,
                }, '-=0.3');

            new ScrollMagic.Scene({
                duration: '120%',
                triggerElement: '#section-tvc-trigger',
                triggerHook: 0
            })
                // .on('enter', function() {
                //     setTimeout(function() {
                //         tvc.currentTime = 0;
                //         tvc.pause();
                //     }, 120);
                // })
                // .on('end', function() {
                //     setTimeout(function() {
                //         tvc.play();
                //     }, 110);
                // })
                .setTween(tl)
                // .addIndicators()
                .addTo(controller);
        },
        details: function () {
            const content = document.getElementById('section-details-content');
            const gallery = document.getElementById('section-details-wrapper');
            const medias = content.querySelectorAll('.section-media');

            let tl = gsap.timeline()
                .to('#section-details-content .swiper-wrapper', {
                    scale: 1,
                });

            new ScrollMagic.Scene({
                duration: isPortrait ? '50%' : '100%',
                triggerElement: '#section-details-content',
                triggerHook: 1
            })
                .setTween(tl)
                // .addIndicators()
                .addTo(controller);

            let width = gallery.clientWidth + 'px';
            let height = gallery.clientHeight + 'px';
            let resizeTimeOut;

            medias.forEach(function (media) {
                media.style.width = width;
                media.style.height = height;
            });

            const swiper = new Swiper('#section-details-content', {
                // preventInteractionOnTransition : true,
                // allowTouchMove: false,
                speed: isPortrait ? 600 : 1000,
                effect: "fade",
                pagination: {
                    el: '.main-section-design .swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '#section-details-wrapper .gallery-button-next',
                    prevEl: '#section-details-wrapper .gallery-button-prev',
                },
            });

            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    width = gallery.clientWidth + 'px';
                    height = gallery.clientHeight + 'px';
                    screenHeight = html.clientHeight;

                    medias.forEach(function (media) {
                        media.style.width = width;
                        media.style.height = height;
                    });
                }, 66);
            });
        },
        superSection: function () {
            document.querySelectorAll('.section-super').forEach(function (section) {
                const trigger = section.querySelector('.section-super-trigger');
                const media = section.querySelector('.section-media');
                const video = section.querySelector('video');
                const content = section.querySelector('.section-content');
                let tl = gsap.timeline()
                    .to(media, {
                        duration: 4,
                        scale: 1,
                        autoAlpha: 1
                    })
                    .fromTo(content, {
                        duration: 0,
                        yPercent: 30
                    }, {
                        yPercent: 0,
                        autoAlpha: 1,
                    }, '+=0.4')
                    .set({}, {}, '+=0.6');

                new ScrollMagic.Scene({
                    duration: '150%',
                    triggerElement: trigger,
                    triggerHook: 1
                })
                    .setTween(tl)
                    // .addIndicators()
                    .addTo(controller);


                new ScrollMagic.Scene({
                    triggerElement: trigger,
                    triggerHook: 0.3
                })
                    .on('enter', function () {
                        setTimeout(function () {
                            if (!isWeChat && !isUC) {
                                video.play();
                            }
                        }, 110);
                    })
                    // .addIndicators()
                    .addTo(controller);
            });
        },
        superSectionFallback: function () {
            document.querySelectorAll('.section-super').forEach(function (section) {
                const video = section.querySelector('video');
                setTimeout(function () {
                    video.play();
                }, 1000);
            });
        },
        watchControl: function () {
            const swiperWrapper = document.getElementById('section-watch-control-swiper');
            const introWrapper = document.getElementById('section-watch-control-intro');
            const paginationWrapper = document.getElementById('watch-control-pagination-xs-wrapper');
            const paginationBar = document.getElementById('section-watch-control-bar');

            const swiperText = new Swiper('#section-watch-control-text', {
                allowTouchMove: false,
                speed: 600,
                effect: 'fade',
                fadeEffect: {
                    crossFade: true,
                }
            })
            const swiper = new Swiper('#section-watch-control-swiper', {
                allowTouchMove: false,
                init: true,
                speed: 600,
                effect: 'fade',
                pagination: {
                    el: '#watch-control-pagination-xs',
                    clickable: true,
                    renderBullet: function (index, className) {
                        const name = swiperWrapper.getAttribute('data-headline-' + (index + 1));
                        return '<div class="' + className + '">' + name + '</div>';
                    },
                },
                on: {
                    init: function () {
                        window.addEventListener('load', function () {
                            paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                            paginationWrapper.querySelectorAll('.swiper-pagination-bullet').forEach(function (pagination, index) {
                                let left = index > 0 ? 500 : 0;

                                pagination.addEventListener('click', function () {
                                    if (!isIE11) {
                                        paginationWrapper.scrollTo({
                                            left: left,
                                            behavior: 'smooth'
                                        });
                                    } else {
                                        paginationWrapper.scrollLeft = left;
                                    }

                                });
                            });
                        });
                    },
                    slideChangeTransitionStart: function () {
                        introWrapper.querySelector('.intro-active').classList.remove('intro-active');
                        introWrapper.querySelector('.section-intro[data-id="' + (this.activeIndex + 1) + '"]').classList.add('intro-active');

                        let left = this.activeIndex > 0 ? 500 : 0;

                        if (!isIE11) {
                            paginationWrapper.scrollTo({
                                left: left,
                                behavior: 'smooth'
                            });
                        } else {
                            paginationWrapper.scrollLeft = left;
                        }

                        // let resizeTimeOut;
                        // clearTimeout(resizeTimeOut);
                        // resizeTimeOut = setTimeout(function() {
                        paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                        paginationBar.style.transform = 'translateX(' + paginationWrapper.querySelector('.swiper-pagination-bullet-active').offsetLeft + 'px)';
                        // }, 100);
                    },
                },
                controller: {
                    control: swiperText,
                }
            });


            let resizeTimeOut;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    if (isPortrait) {
                        swiper.init();
                    }
                }, 66);
            });
        },
        touchscreen: function () {
            const section = document.getElementById('section-touchscreen');
            const stickyContent = section.querySelector('.sticky-content');
            const item = document.getElementById('section-touchscreen-item');
            const item2 = document.getElementById('section-touchscreen-item2');
            const item3 = document.getElementById('section-touchscreen-item3');
            const content1 = document.getElementById('section-touchscreen-content1');
            const content2 = document.getElementById('section-touchscreen-content2');
            const content3 = document.getElementById('section-touchscreen-content3');

            function sticyCenter() {
                if (isPortrait) {
                    let itemHeight = item.clientWidth / (11 / 15);
                    let top = (screenHeight - 64 - itemHeight) / 2;

                    stickyContent.style.top = top > 0 ? top + 64 + 'px' : 64 + 'px';
                }
            }
            sticyCenter();

            let resizeTimeOut;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    sticyCenter();
                }, 66);
            });

            let tl = gsap.timeline()
                .to(content1, {
                    delay: 0.2,
                    yPercent: -5,
                    autoAlpha: 0,
                })
                .call(tlClassToggle(item2, 'animated'))
                .fromTo(content2, {
                    duration: 0,
                    yPercent: 10
                }, {
                    yPercent: 0,
                    autoAlpha: 1,
                }, '+=0.4')
                .to(content2, {
                    yPercent: -5,
                    autoAlpha: 0,
                })
                .call(tlClassToggle(item3, 'animated'))
                .fromTo(content3, {
                    duration: 0,
                    yPercent: 10
                }, {
                    yPercent: 0,
                    autoAlpha: 1,
                }, '+=0.4');

            new ScrollMagic.Scene({
                duration: '150%',
                triggerElement: '#section-touchscreen-trigger',
                triggerHook: 0
            })
                .setTween(tl)
                // .addIndicators()
                .addTo(controller);



        },
        touchscreenXs: function () {
            const swiperWrapper = document.getElementById('section-touchscreen-swiper');
            const introWrapper = document.getElementById('section-touchscreen-intro');
            const paginationWrapper = document.getElementById('touchscreen-pagination-xs-wrapper');
            const paginationBar = document.getElementById('section-touchscreen-bar');

            const swipertouchscreen = new Swiper('#section-touchscreen-swiper', {
                allowTouchMove: false,
                init: isPortrait ? true : false,
                speed: 600,
                effect: 'fade',
                pagination: {
                    el: '#touchscreen-pagination-xs',
                    clickable: true,
                    renderBullet: function (index, className) {
                        const name = swiperWrapper.getAttribute('data-headline-' + (index + 1));
                        return '<div class="' + className + '">' + name + '</div>';
                    },
                },
                on: {
                    init: function () {
                        window.addEventListener('load', function () {
                            paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                            paginationWrapper.querySelectorAll('.swiper-pagination-bullet').forEach(function (pagination, index) {
                                let left = index > 0 ? 500 : 0;

                                pagination.addEventListener('click', function () {
                                    paginationWrapper.scrollTo({
                                        left: left,
                                        behavior: 'smooth'
                                    });

                                    if (!isWeChat && !isUC) {
                                        const xsVideos = swiperWrapper.querySelectorAll('video');
                                        xsVideos.forEach(function (v) {
                                            v.pause();
                                            v.currentTime = 0;
                                        });

                                        let video = swiperWrapper.querySelector('.swiper-slide:nth-child(' + (index + 1) + ') video');
                                        video.play();
                                    }
                                });
                            });
                        });
                    },
                    slideChangeTransitionStart: function () {
                        introWrapper.querySelector('.intro-active').classList.remove('intro-active');
                        introWrapper.querySelector('.section-intro[data-id="' + (this.activeIndex + 1) + '"]').classList.add('intro-active');

                        let left = this.activeIndex > 0 ? 500 : 0;

                        paginationWrapper.scrollTo({
                            left: left,
                            behavior: 'smooth'
                        });

                        paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                        paginationBar.style.transform = 'translateX(' + paginationWrapper.querySelector('.swiper-pagination-bullet-active').offsetLeft + 'px)';
                    },
                },
            });


            let resizeTimeOutN;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOutN);
                resizeTimeOutN = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    if (isPortrait) {
                        swipertouchscreen.init();
                    }
                }, 66);
            });
        },
        intelligent: function () {
            const section = document.getElementById('section-intelligent-wrapper');
            const items = section.querySelectorAll('.section-item');

            items.forEach(function (item) {
                item.addEventListener('click', function () {
                    let notCurrent = this.classList.contains('animated') ? false : true;
                    section.querySelector('.animated').classList.remove('animated');
                    this.classList.add('animated');

                    if (!isWeChat && !isUC) {
                        const notCurrentVideos = section.querySelectorAll('.section-item:not(.animated) video');
                        notCurrentVideos.forEach(function (video) {
                            video.pause();
                            video.currentTime = 0;
                            video.parentElement.classList.remove('playing');
                            video.parentElement.classList.remove('pause');
                        });

                        const currentVideo = this.querySelector('video');
                        currentVideo.play();
                        video.parentElement.classList.add('playing');
                    }

                    if (notCurrent) {
                        section.classList.add('prevent-click');
                        setTimeout(function () {
                            section.classList.remove('prevent-click');
                        }, 600);
                    }
                });
            });

            const swiperWrapper = document.getElementById('section-intelligent-swiper');
            const introWrapper = document.getElementById('section-intelligent-intro');
            const paginationWrapper = document.getElementById('smart-pagination-xs-wrapper');
            const paginationBar = document.getElementById('section-intelligent-bar');

            const swiper = new Swiper('#section-intelligent-swiper', {
                allowTouchMove: false,
                init: isPortrait ? true : false,
                speed: 600,
                effect: 'fade',
                pagination: {
                    el: '#smart-pagination-xs',
                    clickable: true,
                    renderBullet: function (index, className) {
                        const name = swiperWrapper.getAttribute('data-headline-' + (index + 1));
                        return '<div class="' + className + '">' + name + '</div>';
                    },
                },
                on: {
                    init: function () {
                        window.addEventListener('load', function () {
                            paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                            paginationWrapper.querySelectorAll('.swiper-pagination-bullet').forEach(function (pagination, index) {
                                let left = index > 0 ? 500 : 0;

                                pagination.addEventListener('click', function () {
                                    paginationWrapper.scrollTo({
                                        left: left,
                                        behavior: 'smooth'
                                    });

                                    if (!isWeChat && !isUC) {
                                        const xsVideos = swiperWrapper.querySelectorAll('video');
                                        xsVideos.forEach(function (v) {
                                            v.pause();
                                            v.currentTime = 0;
                                        });

                                        let video = swiperWrapper.querySelector('.swiper-slide:nth-child(' + (index + 1) + ') video');
                                        video.play();
                                    }
                                });
                            });
                        });
                    },
                    slideChangeTransitionStart: function () {
                        introWrapper.querySelector('.intro-active').classList.remove('intro-active');
                        introWrapper.querySelector('.section-intro[data-id="' + (this.activeIndex + 1) + '"]').classList.add('intro-active');

                        let left = this.activeIndex > 0 ? 500 : 0;

                        paginationWrapper.scrollTo({
                            left: left,
                            behavior: 'smooth'
                        });

                        // let resizeTimeOut;
                        // clearTimeout(resizeTimeOut);
                        // resizeTimeOut = setTimeout(function() {
                        paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                        paginationBar.style.transform = 'translateX(' + paginationWrapper.querySelector('.swiper-pagination-bullet-active').offsetLeft + 'px)';
                        // }, 100);
                    },
                },
            });


            let resizeTimeOut;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    if (isPortrait) {
                        swiper.init();
                    }
                }, 66);
            });
        },
        intelligentNew: function () {
            const section = document.getElementById('section-intelligent-wrapper-new');
            const items = section.querySelectorAll('.section-item');

            items.forEach(function (item) {
                item.addEventListener('click', function () {
                    let notCurrent = this.classList.contains('animated') ? false : true;
                    section.querySelector('.animated').classList.remove('animated');
                    this.classList.add('animated');

                    if (!isWeChat && !isUC) {
                        const notCurrentVideos = section.querySelectorAll('.section-item:not(.animated) video');
                        notCurrentVideos.forEach(function (video) {
                            video.pause();
                            video.currentTime = 0;
                            video.parentElement.classList.remove('playing');
                            video.parentElement.classList.remove('pause');
                        });

                        const currentVideo = this.querySelector('video');
                        currentVideo.play();
                        video.parentElement.classList.add('playing');
                    }

                    if (notCurrent) {
                        section.classList.add('prevent-click');
                        setTimeout(function () {
                            section.classList.remove('prevent-click');
                        }, 600);
                    }
                });
            });

            const swiperWrapper = document.getElementById('section-intelligent-swiper-new');
            const introWrapper = document.getElementById('section-intelligent-intro-new');
            const paginationWrapper = document.getElementById('smart-pagination-xs-wrapper-new');
            const paginationBar = document.getElementById('section-intelligent-bar-new');

            const swiperNew = new Swiper('#section-intelligent-swiper-new', {
                allowTouchMove: false,
                init: isPortrait ? true : false,
                speed: 600,
                effect: 'fade',
                pagination: {
                    el: '#smart-pagination-xs-new',
                    clickable: true,
                    renderBullet: function (index, className) {
                        const name = swiperWrapper.getAttribute('data-headline-' + (index + 1));
                        return '<div class="' + className + '">' + name + '</div>';
                    },
                },
                on: {
                    init: function () {
                        window.addEventListener('load', function () {
                            paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                            paginationWrapper.querySelectorAll('.swiper-pagination-bullet').forEach(function (pagination, index) {
                                let left = index > 0 ? 500 : 0;

                                pagination.addEventListener('click', function () {
                                    paginationWrapper.scrollTo({
                                        left: left,
                                        behavior: 'smooth'
                                    });

                                    if (!isWeChat && !isUC) {
                                        const xsVideos = swiperWrapper.querySelectorAll('video');
                                        xsVideos.forEach(function (v) {
                                            v.pause();
                                            v.currentTime = 0;
                                        });

                                        let video = swiperWrapper.querySelector('.swiper-slide:nth-child(' + (index + 1) + ') video');
                                        video.play();
                                    }
                                });
                            });
                        });
                    },
                    slideChangeTransitionStart: function () {
                        introWrapper.querySelector('.intro-active').classList.remove('intro-active');
                        introWrapper.querySelector('.section-intro[data-id="' + (this.activeIndex + 1) + '"]').classList.add('intro-active');

                        let left = this.activeIndex > 0 ? 500 : 0;

                        // paginationWrapper.scrollTo({
                        //     left: left,
                        //     behavior: 'smooth'
                        // });

                        // let resizeTimeOut;
                        // clearTimeout(resizeTimeOut);
                        // resizeTimeOut = setTimeout(function() {
                        paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                        paginationBar.style.transform = 'translateX(' + paginationWrapper.querySelector('.swiper-pagination-bullet-active').offsetLeft + 'px)';
                        // }, 100);
                    },
                },
            });


            let resizeTimeOut;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    if (isPortrait) {
                        swiperNew.init();
                    }
                }, 66);
            });
        },
        enjoy: function () {
            const swiperWrapper = document.getElementById('section-enjoy-swiper');
            const paginationWrapper = document.getElementById('enjoy-pagination-xs-wrapper');
            const paginationBar = document.getElementById('section-enjoy-bar');
            const swiper = new Swiper('#section-enjoy-swiper', {
                allowTouchMove: false,
                init: isPortrait ? true : false,
                speed: 1000,
                effect: 'fade',
                pagination: {
                    el: '#enjoy-pagination-xs',
                    clickable: true,
                    renderBullet: function (index, className) {
                        const name = swiperWrapper.getAttribute('data-headline-' + (index + 1));
                        return '<div class="' + className + '">' + name + '</div>';
                    },
                },
                on: {
                    init: function () {
                        window.addEventListener('load', function () {
                            paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                            paginationWrapper.querySelectorAll('.swiper-pagination-bullet').forEach(function (pagination, index) {
                                let left = index > 0 ? 500 : 0;

                                pagination.addEventListener('click', function () {
                                    paginationWrapper.scrollTo({
                                        left: left,
                                        behavior: 'smooth'
                                    });
                                });
                            });
                        });
                    },
                    slideChangeTransitionStart: function () {
                        // let resizeTimeOut;
                        // clearTimeout(resizeTimeOut);
                        // resizeTimeOut = setTimeout(function() {
                        paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                        paginationBar.style.transform = 'translateX(' + paginationWrapper.querySelector('.swiper-pagination-bullet-active').offsetLeft + 'px)';
                        // }, 100);

                        let left = this.activeIndex > 0 ? 500 : 0;

                        paginationWrapper.scrollTo({
                            left: left,
                            behavior: 'smooth'
                        });
                    },
                },
            });
            let resizeTimeOut;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    if (isPortrait) {
                        swiper.init();
                    }
                }, 66);
            });
        },
        technology: function () {
            const swiperWrapper = document.getElementById('section-technology-swiper');
            const introWrapper = document.getElementById('section-technology-intro');
            const paginationWrapper = document.getElementById('technology-pagination-xs-wrapper');
            const paginationBar = document.getElementById('section-technology-bar');
            const swiper = new Swiper('#section-technology-swiper', {
                allowTouchMove: false,
                init: isPortrait ? true : false,
                speed: 1000,
                effect: 'fade',
                pagination: {
                    el: '#technology-pagination-xs',
                    clickable: true,
                    renderBullet: function (index, className) {
                        const name = swiperWrapper.getAttribute('data-headline-' + (index + 1));
                        return '<div class="' + className + '">' + name + '</div>';
                    },
                },
                on: {
                    init: function () {
                        window.addEventListener('load', function () {
                            paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                            paginationWrapper.querySelectorAll('.swiper-pagination-bullet').forEach(function (pagination, index) {
                                let left = index > 0 ? 500 : 0;

                                pagination.addEventListener('click', function () {
                                    paginationWrapper.scrollTo({
                                        left: left,
                                        behavior: 'smooth'
                                    });
                                });
                            });
                        });
                    },
                    slideChangeTransitionStart: function () {
                        introWrapper.querySelector('.intro-active').classList.remove('intro-active');
                        introWrapper.querySelector('.section-intro[data-id="' + (this.activeIndex + 1) + '"]').classList.add('intro-active');

                        let left = this.activeIndex > 0 ? 500 : 0;

                        paginationWrapper.scrollTo({
                            left: left,
                            behavior: 'smooth'
                        });

                        // let resizeTimeOut;
                        // clearTimeout(resizeTimeOut);
                        // resizeTimeOut = setTimeout(function() {
                        paginationBar.style.width = paginationWrapper.querySelector('.swiper-pagination-bullet-active').clientWidth + 'px';
                        paginationBar.style.transform = 'translateX(' + paginationWrapper.querySelector('.swiper-pagination-bullet-active').offsetLeft + 'px)';
                        // }, 100);

                    },
                },
            });
            let resizeTimeOut;
            window.addEventListener('resize', function () {
                clearTimeout(resizeTimeOut);
                resizeTimeOut = setTimeout(function () {
                    isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;
                    if (isPortrait) {
                        swiper.init();
                    }
                }, 66);
            });
        },
        shifter:function name() {
            const swiper = new Swiper('#shifter-swiper', {
                speed: isPortrait ? 600 : 1000,
                effect: "fade",
                navigation: {
                    nextEl: '.section-enjoy .gallery-button-next',
                    prevEl: '.section-enjoy .gallery-button-prev',
                },
            });
            const swiperXs = new Swiper('#shifter-swiper-xs', {
                speed: isPortrait ? 600 : 1000,
                effect: "fade",
                pagination: {
                    el: '#shifter-swiper-xs .swiper-pagination',
                    clickable: true,
                },
            });
        },
    };

    document.addEventListener('DOMContentLoaded', function () {
        SUPPORT.init();
        COMMON.init();
        MAIN.init();
    });

}());