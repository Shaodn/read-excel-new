(function () {
    let bannerSwiper = new Swiper('#banner-wrap', {
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        loop: true,
        speed: 1000,
        pagination: {
            el: '.swiper-pagination-lines',
            bulletClass: 'swiper-pagination-line',
            bulletActiveClass: 'active',
            clickable: true,
        },
    })
    gsap.timeline({
        scrollTrigger: {
            trigger: '.section-main-headline',
            start: 'top 100%',
            end: '+=80%',
            scrub: 1,
            // markers: true,
        }
    })
    .from('.section-main-headline', {
        scale: 2,
    });
    const wrapper = document.getElementById('section-design-seat');
    gsap.timeline({
        scrollTrigger: {
            trigger: '#section-design-2-trigger',
            start: 'top 100%',
            end: '+=100%',
            scrub: 1,
        }
    })
    .from('#section-design-seat', {
        scale: 0.5
    });

    gsap.timeline({
        scrollTrigger: {
            trigger: '#section-design-2-trigger',
            start: 'top 0',
            end: 'bottom 100%',
            onUpdate: function(self) {
                let progress = self.progress;

                if (progress > 0.25 && progress < 0.5) {
                    wrapper.classList.add('active-2');
                    wrapper.classList.remove('active-3');
                    wrapper.classList.remove('active-4');
                } else if (progress > 0.5 && progress < 0.75) {
                    wrapper.classList.add('active-3');
                    wrapper.classList.remove('active-4');
                } else if (progress > 0.75) {
                    wrapper.classList.add('active-4');
                } else {
                    wrapper.classList.remove('active-2');
                    wrapper.classList.remove('active-3');
                    wrapper.classList.remove('active-4');
                }
            },
        }
    });
    const
        BODY = document.body,
        MAIN = BODY.querySelector('main');
    const
        container = MAIN.querySelector('#section-seat-swiper'),
        pagination = container.querySelector('.section-headline-wrapper'),
        headlines = pagination.querySelectorAll('h2');
    new Swiper('#section-seat-swiper', {
        speed: 500,
        resistanceRatio: 0,
        watchSlidesProgress: true,
        noSwipingSelector: '.section-swiper-content, .section-modal-copy, .section-modal-button, .section-video-button, .modal-video-open',
        pagination: {
            el: '.section-headline-wrapper',
            bulletClass: 'section-headline-reduced',
            bulletActiveClass: 'active',
            clickable: true,
            renderBullet: function(index, className) {
                return '<h2 class="' + className + '">' + headlines[index].innerHTML + '</h2>';
            },
        },
        scrollbar: {
            el: '.section-scrollbar',
            draggable: false,
        },
        on: {
            slideChangeTransitionStart: function() {
                container.setAttribute('data-active-slide', this.activeIndex + 1);
            },
            slideChangeTransitionEnd: function() {
                container.setAttribute('data-active-slide', this.activeIndex + 1);

            },
            touchEnd: function() {
                container.setAttribute('data-active-slide', this.activeIndex + 1);
            },
        },
    });
    const modalButtons = MAIN.querySelectorAll('.section-modal-button');
    modalButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            this.parentElement.classList.toggle('modal-active');
        });
    });
    const playTriggers = MAIN.querySelectorAll('.section-content-video');

    playTriggers.forEach(function(playTrigger) {
        const video = playTrigger.querySelector('video');

        gsap.timeline({
            scrollTrigger: {
                trigger: playTrigger,
                start:'top 70%',
                end:'top 70%',
                once: true,
                onEnter: function() {
                    setTimeout(function() {
                        video.play();
                    }, 200);
                }
            }
        });
    });
}());