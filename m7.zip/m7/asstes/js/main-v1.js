(function() {
    'use strict';

    const
        HTML = document.documentElement,
        BODY = document.body,
        MAIN = BODY.querySelector('main'),
        UA = navigator.userAgent.toLowerCase();

    let
        screenWidth = HTML.clientWidth,
        screenHeight = HTML.clientHeight,
        windowWidth = window.innerWidth,
        windowHeight = window.innerHeight,
        isPortrait = window.matchMedia('(max-aspect-ratio: 11/10)').matches;

    if (window.NodeList && !NodeList.prototype.forEach) {
        NodeList.prototype.forEach = Array.prototype.forEach;
    }

    const Browser = {
        isIE: UA.match(/(msie|MSIE)/) || UA.match(/(T|t)rident/) || UA.indexOf('edge') !== -1,
        isUC: UA.indexOf('ucbrowser') !== -1,
        isWeChat: UA.indexOf('micromessenger') !== -1,
        init: function() {
            if (this.isIE) {
                MAIN.classList.add('fallback-mode');
            }
        },
    };

    const Support = {
        sticky: false,
        objectFit: false,
        intersectionObserver: false,
        init: function() {
            this.detectCSS();
            this.detectJS();

            this.detectCSS = null;
            this.detectJS = null;
        },
        detectCSS: function() {
            if (!!(window.CSS && window.CSS.supports || window.supportsCSS || false)) {
                // Detect sticky
                if (CSS.supports('position', 'sticky')) {
                    this.sticky = true;
                } else {
                    MAIN.classList.add('fallback-mode');
                    MAIN.classList.add('no-sticky');
                }
                // Detect objectFit
                if ('objectFit' in document.documentElement.style !== false) {
                    this.objectFit = true;
                } else {
                    MAIN.classList.add('no-object-fit');
                }
            } else {
                MAIN.classList.add('fallback-mode');
                MAIN.classList.add('no-sticky');
                MAIN.classList.add('no-object-fit');
            }
        },
        detectJS: function() {
            // Detect IntersectionObserver
            if (!('IntersectionObserver' in window) || !('IntersectionObserverEntry' in window) || !('intersectionRatio' in window.IntersectionObserverEntry.prototype)) {
                MAIN.classList.add('no-intersection-observer');
            } else {
                this.intersectionObserver = true;
            }
        },
    };

    const U = {
        addClass: function(element, classname) {
            return function() {
                if (classname) {
                    element.classList.add(classname);
                }
            };
        },
        removeClass: function(element, classname) {
            return function() {
                if (classname) {
                    element.classList.remove(classname);
                }
            };
        }
    };

    const ModalVideo = {
        modal: document.getElementById('section-modal-video'),
        modalOpen: MAIN.querySelectorAll('.modal-video-open'),
        modalClose: document.getElementById('modal-video-close'),
        modalVideo: MAIN.querySelector('#section-modal-video video'),
        modalSource: MAIN.querySelector('#section-modal-video source'),
        init: function() {
            this.setupVideo();
            this.setupGA();
            this.setupVideo = null;
            this.setupGA = null;
        },
        setupVideo: function() {
            const self = this;

            self.modalOpen.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();

                    let video = button.href,
                        poster = button.getAttribute('data-poster');

                    self.modalVideo.setAttribute('poster', poster);
                    self.modalSource.setAttribute('src', video);

                    self.modalVideo.load();

                    self.modal.classList.remove('modal-closed');
                    self.modal.classList.add('modal-open');

                    self.modalVideo.play();
                });
            });

            document.addEventListener('visibilitychange', function() {
                if (!self.modal.classList.contains('modal-closed')) {
                    if (document.hidden) {
                        self.modalVideo.pause();
                        self.modal.classList.remove('playing');
                        self.modal.classList.add('pause');
                    } else {
                        self.modalVideo.play();
                        self.modal.classList.remove('pause');
                        self.modal.classList.add('playing');
                    }
                }
            });

            function closeModal() {
                self.modalVideo.pause();
                self.modal.classList.remove('modal-open');
                self.modal.classList.add('modal-closed');
                self.modal.classList.remove('playing');
                self.modal.classList.remove('pause');
            }

            self.modalVideo.addEventListener('click', function(e) {
                e.stopPropagation();
            });

            self.modalClose.addEventListener('click', function(e) {
                e.preventDefault();
                closeModal();
            });

            self.modal.addEventListener('click', function(e) {
                e.preventDefault();
                closeModal();
            });
        },
        setupGA: function() {
            const self = this;
            let playedPercent = [];

            function pushData(videoName, videoStep) {
                window.dataLayer.push({
                    'event': 'video_interaction',
                    'video_name': videoName,
                    'video_step': videoStep,
                });
            }

            function videoStep(video, videoName, index) {
                let progress = Math.floor(video.currentTime * 100 / video.duration);

                if (progress >= 25 && progress < 50 && !playedPercent[index]._25) {
                    pushData(videoName, '25%');
                    playedPercent[index]._25 = true;
                } else if (progress >= 50 && progress < 75 && !playedPercent[index]._50) {
                    pushData(videoName, '50%');
                    playedPercent[index]._50 = true;
                } else if (progress >= 75 && progress < 100 && !playedPercent[index]._75) {
                    pushData(videoName, '75%');
                    playedPercent[index]._75 = true;
                }
            }

            function videoStatus(video, videoName, index) {
                pushData(videoName, 'play');
                video.onpause = function() {
                    if (video.currentTime == 0 || video.currentTime == video.duration) {
                        return false;
                    }
                    pushData(videoName, 'pause');
                };

                video.ontimeupdate = function() {
                    videoStep(video, videoName, index);
                };

                video.onended = function() {
                    if (!playedPercent[index]._100) {
                        pushData(videoName, '100%');
                        playedPercent[index]._100 = true;
                    }
                };
            }

            this.modalOpen.forEach(function(button, index) {
                let percent = {
                    _25: false,
                    _50: false,
                    _75: false,
                    _100: false,
                };

                playedPercent.push(percent);

                button.addEventListener('click', function() {
                    videoStatus(self.modalVideo, button.getAttribute('data-ga-video-name'), index);
                });
            });
        },
    };

    const Helper = {
        init: function() {
            this.setupWillChange();
            this.setupInlineVideo();

            this.setupWillChange = null;
            this.setupInlineVideo = null;

            if (!isPortrait) {
                this.setupFootnoteAnchor();
                this.setupFootnoteAnchor = null;
            }
        },
        setupWillChange: function() {
            if (Support.intersectionObserver) {
                const sections = MAIN.querySelectorAll('.section-will-change');
                if (sections.length) {
                    let intersectionObserver = new IntersectionObserver(function(entries) {
                        entries.forEach(function(entry) {
                            if (entry.intersectionRatio > 0) {
                                entry.target.classList.add('will-change');
                            } else {
                                entry.target.classList.remove('will-change');
                            }
                        });
                    });

                    sections.forEach(function(e) {
                        intersectionObserver.observe(e);
                    });
                }
            }
        },
        setupInlineVideo: function() {
            if (Browser.isWeChat || Browser.isUC) {
                MAIN.classList.add('no-inline-video');
            } else {
                const videos = MAIN.querySelectorAll('.section-inline-video video');
                videos.forEach(function(video) {
                    let
                        posterLG = video.getAttribute('data-poster'),
                        posterXS = video.getAttribute('data-poster-xs');

                    if (isPortrait && posterXS) {
                        video.setAttribute('poster', posterXS);
                    } else if (posterLG) {
                        video.setAttribute('poster', posterLG);
                    }
                    video.querySelectorAll('source').forEach(function(source) {
                        let
                            srcLG = source.getAttribute('data-src'),
                            srcXS = source.getAttribute('data-src-xs');

                        if (isPortrait && srcXS) {
                            source.setAttribute('src', srcXS);
                        } else if (srcLG) {
                            source.setAttribute('src', srcLG);
                        }
                    });

                    setTimeout(function() {
                        video.load();
                    }, 200);

                    video.addEventListener('playing', function() {
                        video.classList.add('playing');
                        video.classList.remove('pause');
                        video.classList.remove('ended');
                        video.parentElement.classList.remove('ended');
                    });

                    video.addEventListener('ended', function() {
                        video.classList.add('ended');
                        video.classList.add('played');
                        video.classList.remove('pause');
                        video.classList.remove('playing');
                        video.parentElement.classList.add('ended');
                        video.parentElement.classList.add('played');
                    });
                });

                document.addEventListener('visibilitychange', function() {
                    if (document.hidden) {
                        videos.forEach(function(video) {
                            if (video.classList.contains('playing')) {
                                video.pause();
                                video.classList.remove('playing');
                                video.classList.add('pause');
                            }
                        });
                    } else {
                        videos.forEach(function(video) {
                            if (video.classList.contains('pause')) {
                                video.play();
                                video.classList.remove('pause');
                                video.classList.add('playing');
                            }
                        });
                    }
                });
            }
        },
        smoothScroll: function(target, offset) {
            offset = offset || this.navHeight;

            let start,
                requestId;

            const
                startPosition = window.scrollY || window.pageYOffset || HTML.scrollTop,
                duration = 1000,
                outCube = function(n) {
                    // https://github.com/component/ease/blob/master/index.js
                    return --n * n * n + 1;
                },
                getTop = function(target) {
                    let top = 0;
                    while (target.offsetParent) {
                        top += target.offsetTop;
                        target = target.offsetParent;
                    }
                    return top;
                },
                scrolling = function(timestamp) {
                    if (!start) {
                        start = timestamp;
                    }

                    const
                        distance = target ? getTop(target) - offset : 0,
                        elapsed = timestamp - start,
                        progress = Math.min(elapsed / duration, 1),
                        position = target ? startPosition + (distance - startPosition) * outCube(progress) : startPosition - startPosition * outCube(progress);

                    window.scrollTo(0, position);

                    if (elapsed < duration) {
                        requestId = requestAnimationFrame(scrolling);
                    } else {
                        cancelAnimationFrame(requestId);
                    }
                };

            requestId = requestAnimationFrame(scrolling);
        },
        setupAnchor: function(anchors, offset, fn, render) {
            anchors = anchors || '[data-anchor]';
            offset = offset || null;
            fn = fn || null;
            render = render || null;

            if (render) {
                document.addEventListener('click', function(event) {
                    let t = event.target;

                    if (t.classList.contains(anchors.split('.')[1])) {
                        let element = t.getAttribute('href') || t.getAttribute('data-anchor'),
                            target = document.querySelectorAll(element)[0];

                        event.preventDefault();
                        Helper.smoothScroll(target, offset);

                        if (fn) {
                            fn(target);
                        }
                    }
                });
            } else {
                document.querySelectorAll(anchors).forEach(function(anchor) {
                    let element = anchor.getAttribute('href') || anchor.getAttribute('data-anchor'),
                        target = document.querySelectorAll(element)[0];

                    anchor.addEventListener('click', function(e) {
                        e.preventDefault();
                        Helper.smoothScroll(target, offset);

                        if (fn) {
                            fn(target);
                        }
                    });

                    anchor = null;
                });
            }
        },
        setupFootnoteAnchor: function() {
            function highlight(target) {
                const section = MAIN.querySelector('.section-footnote');

                section.querySelectorAll('li').forEach(function(footnote) {
                    footnote.classList.remove('current');
                });

                target.classList.add('current');
            }

            this.setupAnchor('.footnote-anchor', 120, highlight, true);
        },
    };

    const Site = {
        init: function() {
            gsap.defaults({
                duration: 1,
            });

            // Common
            Browser.init();
            Support.init();
            Helper.init();
            ModalVideo.init();

            Browser.init = null;
            Support.init = null;
            Helper.init = null;
            ModalVideo.init = null;

            // Main
            this.localnav();
            this.hero();
            this.seat.init();
            this.harmonyOS.init();
            this.smart();
            this.performance();
            this.design.init();
            this.configuration();
            this.blackTech();
            this.testDrive.init();
            this.setupGA.init();

            this.localnav = null;
            this.hero = null;
            this.seat.init = null;
            this.harmonyOS.init = null;
            this.smart = null;
            this.performance = null;
            this.design.init = null;
            this.configuration = null;
            this.blackTech = null;
            this.testDrive.init = null;
            this.setupGA.init = null;

            if (!Browser.isIE) {
                this.enterSection.init();
                this.enterSection.init = null;
            }

            if (!Browser.isWeChat && !Browser.isUC) {
                this.triggerPlayVideo();
                this.replayVideo();

                this.triggerPlayVideo = null;
                this.replayVideo = null;
            }
        },
        localnav: function() {
            Helper.setupAnchor('.ln-anchor', 64);
        },
        newSwiperLine: function(swiperEl, trigger) {
            trigger = trigger || null;
            let init = trigger ? false : true;

            const mySwiper = new Swiper(swiperEl, {
                init: init,
                speed: trigger ? 500 : 1000,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                },
                loop: true,
                pagination: {
                    el: '.swiper-pagination-lines',
                    bulletClass: 'swiper-pagination-line',
                    bulletActiveClass: 'active',
                    clickable: true,
                },
            });

            function setupLineClick() {
                mySwiper.pagination.bullets[0].classList.add('first-line');

                setTimeout(function() {
                    mySwiper.pagination.bullets[0].classList.remove('first-line');
                }, 5000);
            }

            if (trigger) {
                gsap.timeline({
                    scrollTrigger: {
                        trigger: trigger,
                        start: 'top 100%',
                        end: 'top 100%',
                        once: true,
                        // markers: true,
                        onEnter: function() {
                            mySwiper.init();
                            setupLineClick();
                        }
                    }
                });
            } else {
                setupLineClick();
            }
        },
        hero: function() {
            this.newSwiperLine('#section-hero-swiper');

            setTimeout(function() {
                const duplicates = MAIN.querySelectorAll('.swiper-slide-duplicate');

                duplicates.forEach(function(d) {
                    const img = d.querySelector('img');
                    img.classList.add('lazyloaded');
                });
            }, 8000);
        },
        enterSection: {
            sections: MAIN.querySelectorAll('.section-start'),
            headline: MAIN.querySelector('.section-headline-gradient'),
            init: function() {
                const
                    self = this,
                    height = self.headline.offsetHeight;

                this.sections.forEach(function(section) {
                    self.zoomInHeadline(section, height);
                    self.zoomInContent(section);
                    self.fadeOutPrevSection(section);
                });

                this.sections = null;
                this.headline = null;
            },
            zoomInHeadline: function(section, height) {
                const headline = section.querySelector('.section-headline-gradient');

                gsap.timeline({
                        scrollTrigger: {
                            trigger: headline,
                            start: 'top 100%',
                            end: '+=80%',
                            scrub: isPortrait ? 0.2 : 1,
                            // markers: true,
                        }
                    })
                    .from(headline, {
                        scale: 2,
                    });

                gsap.timeline({
                        scrollTrigger: {
                            trigger: headline,
                            start: isPortrait ? 'top 70' : 'top 64',
                            end: '+=' + height,
                            scrub: isPortrait ? 0.2 : 1,
                            // markers: true,
                        }
                    })
                    .to(headline, {
                        ease: 'none',
                        autoAlpha: 0,
                    });
            },
            zoomInContent: function(section) {
                const content = section.querySelector('.section-will-zoomin') || null;

                if (content) {
                    const
                        trigger = section.querySelector('.section-content-trigger'),
                        ratio1920 = 1920 / Number(trigger.getAttribute('data-1920-height')),
                        ratio720 = 720 / Number(trigger.getAttribute('data-720-height')),
                        scaleDuration = isPortrait ? windowWidth / ratio720 * (3 / 4) : windowWidth / ratio1920;

                    gsap.timeline({
                            scrollTrigger: {
                                trigger: trigger,
                                start: 'top 100%',
                                end: '+=' + scaleDuration,
                                scrub: isPortrait ? 0.2 : 1,
                                // markers: true,
                            }
                        })
                        .from(content, {
                            scale: 0.8,
                        });
                }
            },
            fadeOutPrevSection: function(section) {
                const
                    prevSection = section.previousElementSibling,
                    fadeOutSection = prevSection.querySelector('.section-will-fadeout') || prevSection,
                    mask = prevSection.querySelector('.section-out-mask') || null;

                gsap.timeline({
                        scrollTrigger: {
                            trigger: section,
                            start: isPortrait ? 'top 40%' : 'top 50%',
                            end: '+=50%',
                            scrub: 0.2,
                            // markers: true,
                        }
                    })
                    .to(mask ? mask : fadeOutSection, {
                        ease: 'none',
                        autoAlpha: mask ? 1 : 0,
                    });
            },
        },
        triggerPlayVideo: function() {
            const playTriggers = MAIN.querySelectorAll('.section-play-trigger');

            playTriggers.forEach(function(playTrigger) {
                const video = playTrigger.querySelector('video');

                gsap.timeline({
                    scrollTrigger: {
                        trigger: playTrigger,
                        start: isPortrait ? 'top 90%' : 'top 70%',
                        end: isPortrait ? 'top 90%' : 'top 70%',
                        // markers: true,
                        once: true,
                        onEnter: function() {
                            setTimeout(function() {
                                video.play();
                            }, 200);
                        }
                    }
                });
            });
        },
        replayVideo: function() {
            const replayButtons = MAIN.querySelectorAll('.section-replay-button');

            replayButtons.forEach(function(replayButton) {
                const video = replayButton.parentElement.querySelector('video');

                replayButton.addEventListener('click', function() {
                    video.currentTime = 0;
                    video.play();
                });
            });
        },
        activeSlidePlayVideo: function(slides, activeIndex) {
            const
                activeSlide = slides[activeIndex],
                video = activeSlide.querySelector('video') || null;

            if (video && !video.classList.contains('played') && !video.classList.contains('playing')) {
                video.play();
            }
        },
        newSwiper: function(containerEl) {
            const
                self = this,
                container = MAIN.querySelector(containerEl),
                pagination = container.querySelector('.section-headline-wrapper'),
                headlines = pagination.querySelectorAll('h2'),
                slides = container.querySelectorAll('.swiper-slide');

            new Swiper(containerEl, {
                speed: 500,
                // allowTouchMove: isPortrait ? false : true,
                resistanceRatio: 0,
                watchSlidesProgress: true,
                noSwipingSelector: '.section-swiper-content, .section-modal-copy, .section-modal-button, .section-video-button, .modal-video-open',
                pagination: {
                    el: pagination,
                    bulletClass: 'section-headline-reduced',
                    bulletActiveClass: 'active',
                    clickable: true,
                    renderBullet: function(index, className) {
                        return '<h2 class="' + className + '">' + headlines[index].innerHTML + '</h2>';
                    },
                },
                scrollbar: {
                    el: '.section-scrollbar',
                    draggable: false,
                },
                on: {
                    slideChangeTransitionStart: function() {
                        container.setAttribute('data-active-slide', this.activeIndex + 1);
                    },
                    slideChangeTransitionEnd: function() {
                        container.setAttribute('data-active-slide', this.activeIndex + 1);

                        self.activeSlidePlayVideo(slides, this.activeIndex);
                    },
                    touchEnd: function() {
                        container.setAttribute('data-active-slide', this.activeIndex + 1);

                        self.activeSlidePlayVideo(slides, this.activeIndex);
                    },
                },
            });
        },
        seat: {
            init: function() {
                this.section1();
                this.section1 = null;

                if (!Browser.isIE) {
                    this.section2();
                    this.section2 = null;
                }
            },
            section1: function() {
                // Swiper
                Site.newSwiper('#section-seat-swiper');
            },
            section2: function() {
                gsap.timeline({
                        scrollTrigger: {
                            trigger: '#section-seat-2-trigger',
                            start: 'top 150%',
                            end: 'bottom 100%',
                            scrub: isPortrait ? 0.2 : 1,
                            // markers: true,
                        }
                    })
                    .from('#section-seat-2-content', {
                        scale: 0.5,
                    })
                    .set({}, {}, isPortrait ? '+=0.1' : '+=0.2');
            }
        },
        harmonyOS: {
            init: function() {
                this.section1();
                this.section2();
                this.setupFeatures();

                this.section1 = null;
                this.section2 = null;
                this.setupFeatures = null;
            },
            section1: function() {
                // Powered by HarmonyOS
                gsap.timeline({
                        scrollTrigger: {
                            trigger: '.section-powered-by',
                            start: 'top 50%',
                            end: '+=100%',
                            scrub: isPortrait ? 0.2 : 1,
                            // markers: true,
                        }
                    })
                    .to('.section-powered-by', {
                        autoAlpha: 0
                    });

                // Swiper
                Site.newSwiper('#section-harmonyos-1-swiper');
            },
            section2: function() {
                // Swiper
                Site.newSwiper('#section-harmonyos-2-swiper');
            },
            setupFeatures: function() {
                const wrappers = MAIN.querySelectorAll('.section-features');

                wrappers.forEach(function(wrapper) {
                    const features = wrapper.querySelectorAll('.section-features > li.section-headline');

                    // feature to short, so based on wrapper progress
                    gsap.timeline({
                        scrollTrigger: {
                            trigger: wrapper,
                            start: 'top 50%',
                            end: 'bottom 50%',
                            // markers: true,
                            onUpdate: function(self) {
                                let progress = self.progress;

                                if (progress > 0.33 && progress < 0.66) {
                                    features[0].classList.remove('active');
                                    features[1].classList.add('active');
                                    features[2].classList.remove('active');
                                } else if (progress > 0.66) {
                                    features[0].classList.remove('active');
                                    features[1].classList.remove('active');
                                    features[2].classList.add('active');
                                } else {
                                    features[0].classList.add('active');
                                    features[1].classList.remove('active');
                                    features[2].classList.remove('active');
                                }
                            }
                        }
                    });

                    // onEnterBack remove first active
                    gsap.timeline({
                        scrollTrigger: {
                            trigger: features[0],
                            start: 'top 100%',
                            end: 'top 100%',
                            // markers: true,
                            onEnterBack: function() {
                                features[0].classList.remove('active');
                            }
                        }
                    });

                    // onLeave remove last active
                    gsap.timeline({
                        scrollTrigger: {
                            trigger: features[2],
                            start: 'top 0',
                            end: 'bottom 0',
                            // markers: true,
                            onLeave: function() {
                                features[2].classList.remove('active');
                            }
                        }
                    });
                });
            },
        },
        smart: function() {
            // Swiper
            Site.newSwiper('#section-smart-swiper');
        },
        performance: function() {
            // Swiper
            Site.newSwiper('#section-performance-swiper');
        },
        design: {
            mainSwiper: null,
            colorSwiper: null,
            familySwiper: null,
            init: function() {
                this.start();
                this.newMainSwiper();
                this.newColorSwiper();
                this.newFamilySwiper();
                this.section2();
                this.section3();

                this.start = null;
                this.newMainSwiper = null;
                this.newColorSwiper = null;
                this.newFamilySwiper = null;
                this.section2 = null;
                this.section3 = null;
            },
            start: function() {
                const self = this;

                if (isPortrait || Browser.isIE) {
                    // trigger swiper autoplay only
                    gsap.timeline({
                        scrollTrigger: {
                            trigger: '#section-design-1-content',
                            start: 'top 80%',
                            end: 'top 80%',
                            // markers: true,
                            onEnter: function() {
                                if (self.mainSwiper.activeIndex === 0) {
                                    self.colorSwiper.autoplay.start();
                                } else {
                                    self.familySwiper.autoplay.start();
                                }
                            }
                        }
                    });
                } else {
                    const
                        container = document.getElementById('section-design-1-swiper'),
                        content = document.getElementById('section-design-1-content'),
                        fixSpacer = ((screenHeight - 64) - (screenHeight - 64) * 0.8) / 2;

                    gsap.timeline({
                            scrollTrigger: {
                                trigger: '#section-design-1-content',
                                start: 'top 0',
                                end: 'bottom 100%',
                                scrub: 1,
                                // markers: true,
                            }
                        })
                        .from('#section-design-1-swiper', {
                            scale: isPortrait ? 1 : 0.75
                        })
                        .call(U.removeClass(container, 'active'))
                        .call(function() {
                            self.colorSwiper.autoplay.stop();
                            self.familySwiper.autoplay.stop();
                        })
                        .set({}, {}, '+=0.02')
                        .call(U.addClass(container, 'active'))
                        .call(function() {
                            if (self.mainSwiper.activeIndex === 0) {
                                self.colorSwiper.autoplay.start();
                            } else {
                                self.familySwiper.autoplay.start();
                            }
                        })
                        .set({}, {}, '+=1');

                    // Fix Spacer
                    content.style.setProperty('--fix-spacer', -fixSpacer + 'px');
                }
            },
            newMainSwiper: function() {
                const
                    self = this,
                    container = MAIN.querySelector('#section-design-1-swiper'),
                    pagination = container.querySelector('.section-headline-wrapper'),
                    headlines = pagination.querySelectorAll('h2');

                this.mainSwiper = new Swiper('#section-design-1-swiper', {
                    speed: 500,
                    allowTouchMove: false,
                    pagination: {
                        el: pagination,
                        bulletClass: 'section-headline-reduced',
                        bulletActiveClass: 'active',
                        clickable: true,
                        renderBullet: function(index, className) {
                            return '<h2 class="' + className + ' section-headline-reduced">' + headlines[index].innerHTML + '</h2>';
                        },
                    },
                    scrollbar: {
                        el: '.section-scrollbar',
                        draggable: false,
                    },
                    on: {
                        slideChangeTransitionStart: function() {
                            container.setAttribute('data-active-slide', this.activeIndex + 1);
                        },
                    },
                });

                // switch autoplay
                this.mainSwiper.pagination.bullets[0].addEventListener('click', function() {
                    self.colorSwiper.autoplay.start();
                    self.familySwiper.autoplay.stop();
                });

                this.mainSwiper.pagination.bullets[1].addEventListener('click', function() {
                    self.familySwiper.autoplay.start();
                    self.colorSwiper.autoplay.stop();
                });
            },
            newColorSwiper: function() {
                const
                    container = document.getElementById('section-design-color-swiper'),
                    pagination = container.querySelector('.section-color-pagination'),
                    colors = pagination.querySelectorAll('h2');

                if (Browser.isIE) {
                    this.colorSwiper = new Swiper(container, {
                        speed: 600,
                        loop: true,
                        allowTouchMove: false,
                        effect: 'fade',
                        pagination: {
                            el: pagination,
                            clickable: true,
                            renderBullet: function(index, className) {
                                return '<div class="' + className + '"><p class="section-color-copy">' + colors[index].innerHTML + '</p></div>';
                            },
                        },
                    });
                } else {
                    this.colorSwiper = new Swiper(container, {
                        speed: 600,
                        loop: true,
                        allowTouchMove: false,
                        direction: 'vertical',
                        preventInteractionOnTransition: true,
                        watchSlidesProgress: true,
                        pagination: {
                            el: pagination,
                            clickable: true,
                            renderBullet: function(index, className) {
                                return '<div class="' + className + '"><p class="section-color-copy">' + colors[index].innerHTML + '</p></div>';
                            },
                        },
                        on: {
                            progress: function() {
                                const swiper = this;

                                for (let i = 0; i < swiper.slides.length; i++) {
                                    let slideProgress = swiper.slides[i].progress,
                                        innerTranslate = slideProgress * swiper.height * 0.9;

                                    swiper.slides[i].querySelector('.section-picture').style.transform = 'translate3d(0,' + innerTranslate + 'px,  0)';
                                }
                            },
                            touchStart: function() {
                                const swiper = this;

                                for (let i = 0; i < swiper.slides.length; i++) {
                                    swiper.slides[i].style.transition = '';
                                }
                            },
                            setTransition: function(speed) {
                                const swiper = this;

                                for (let i = 0; i < swiper.slides.length; i++) {
                                    swiper.slides[i].style.transition = speed + 'ms';
                                    swiper.slides[i].querySelector('.section-picture').style.transition = speed + 'ms';
                                }
                            }
                        }
                    });
                }
            },
            newFamilySwiper: function() {
                const
                    container = document.getElementById('section-design-family-swiper'),
                    pagination = container.querySelector('.swiper-pagination'),
                    colors = pagination.querySelectorAll('h2');

                if (Browser.isIE) {
                    this.familySwiper = new Swiper(container, {
                        speed: 600,
                        loop: true,
                        allowTouchMove: false,
                        effect: 'fade',
                        pagination: {
                            el: pagination,
                            clickable: true,
                            renderBullet: function(index, className) {
                                return '<div class="' + className + '"><p class="section-color-copy">' + colors[index].innerHTML + '</p></div>';
                            },
                        },
                    });
                } else {
                    this.familySwiper = new Swiper(container, {
                        speed: 600,
                        loop: true,
                        allowTouchMove: false,
                        direction: 'vertical',
                        preventInteractionOnTransition: true,
                        watchSlidesProgress: true,
                        pagination: {
                            el: pagination,
                            clickable: true,
                            renderBullet: function(index, className) {
                                return '<div class="' + className + '"><p class="section-color-copy">' + colors[index].innerHTML + '</p></div>';
                            },
                        },
                        on: {
                            progress: function() {
                                const swiper = this;

                                for (let i = 0; i < swiper.slides.length; i++) {
                                    let slideProgress = swiper.slides[i].progress,
                                        innerTranslate = slideProgress * swiper.height * 0.9;

                                    swiper.slides[i].querySelector('.section-picture').style.transform = 'translate3d(0,' + innerTranslate + 'px,  0)';
                                }
                            },
                            touchStart: function() {
                                const swiper = this;

                                for (let i = 0; i < swiper.slides.length; i++) {
                                    swiper.slides[i].style.transition = '';
                                }
                            },
                            setTransition: function(speed) {
                                const swiper = this;

                                for (let i = 0; i < swiper.slides.length; i++) {
                                    swiper.slides[i].style.transition = speed + 'ms';
                                    swiper.slides[i].querySelector('.section-picture').style.transition = speed + 'ms';
                                }
                            }
                        }
                    });
                }
            },
            section2: function() {
                const wrapper = document.getElementById('section-design-seat');

                if (Browser.isIE) {
                    gsap.timeline({
                        scrollTrigger: {
                            trigger: '#section-design-2-trigger',
                            start: 'top 20%',
                            end: 'top 20%',
                            once: true,
                            // markers: true,
                            onEnter: function() {
                                autoplay();
                            }
                        }
                    });

                    const autoplay = function() {
                        let index = 1;

                        setInterval(function() {
                            index++;
                            index = index > 4 ? 1 : index;

                            switch (index) {
                                case 1:
                                    wrapper.classList.remove('active-2');
                                    wrapper.classList.remove('active-3');
                                    wrapper.classList.remove('active-4');
                                    break;
                                case 2:
                                    wrapper.classList.add('active-2');
                                    break;
                                case 3:
                                    wrapper.classList.add('active-3');
                                    break;
                                case 4:
                                    wrapper.classList.add('active-4');
                                    break;
                            }
                        }, 3000);
                    };
                } else {
                    // ZoomIn Content
                    gsap.timeline({
                            scrollTrigger: {
                                trigger: '#section-design-2-trigger',
                                start: 'top 100%',
                                end: '+=100%',
                                scrub: isPortrait ? 0.2 : 1,
                                // markers: true,
                            }
                        })
                        .from(wrapper, {
                            scale: 0.5
                        });

                    gsap.timeline({
                        scrollTrigger: {
                            trigger: '#section-design-2-trigger',
                            start: 'top 0',
                            end: 'bottom 100%',
                            // markers: true,
                            onUpdate: function(self) {
                                let progress = self.progress;

                                if (progress > 0.25 && progress < 0.5) {
                                    wrapper.classList.add('active-2');
                                    wrapper.classList.remove('active-3');
                                    wrapper.classList.remove('active-4');
                                } else if (progress > 0.5 && progress < 0.75) {
                                    wrapper.classList.add('active-3');
                                    wrapper.classList.remove('active-4');
                                } else if (progress > 0.75) {
                                    wrapper.classList.add('active-4');
                                } else {
                                    wrapper.classList.remove('active-2');
                                    wrapper.classList.remove('active-3');
                                    wrapper.classList.remove('active-4');
                                }
                            },
                        }
                    });
                }
            },
            section3: function() {
                if (!Browser.isIE) {
                    const
                        content = document.getElementById('section-design-3-swiper'),
                        trigger = document.getElementById('section-design-3-content'),
                        ratio1920 = 1920 / Number(trigger.getAttribute('data-1920-height')),
                        ratio720 = 720 / Number(trigger.getAttribute('data-720-height')),
                        scaleDuration = isPortrait ? windowWidth / ratio720 : windowWidth / ratio1920;

                    gsap.timeline({
                            scrollTrigger: {
                                trigger: trigger,
                                start: 'top 100%',
                                end: '+=' + scaleDuration,
                                scrub: isPortrait ? 0.2 : 1,
                                // markers: true,
                            }
                        })
                        .from(content, {
                            scale: 0.8,
                        });
                }

                // Swiper
                Site.newSwiper('#section-design-3-swiper');
            },
        },
        configuration: function() {
            this.newSwiperLine('#section-configuration-swiper', '#section-configuration');
        },
        blackTech: function() {
            const
                modalButtons = MAIN.querySelectorAll('.section-modal-button'),
                $page_name = window.pageInfo.pageName;

            modalButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    this.parentElement.classList.toggle('modal-active');

                    // GA
                    window.dataLayer.push({
                        'event': 'm7_high_tech_click',
                        'page_name': $page_name,
                        'banner_name': button.getAttribute('data-banner-name'),
                        'high_tech_button': '黑科技',
                        'm7_high_tech_tab': button.getAttribute('data-tab-name'),
                    });
                });
            });
        },
        setupGA: {
            $page_name: window.pageInfo.pageName,
            $page_category2: window.pageInfo.pageCategory2,
            $aito_model: 'model-m7',
            linkButtons: MAIN.querySelectorAll('.section-button-link'),
            testDriveButtons: MAIN.querySelectorAll('.ga-test-drive'),
            floatTestDriveButton: document.getElementById('section-test-drive-button'),
            downloadLinks: MAIN.querySelectorAll('.download-link'),
            init: function() {
                this.linkButtonsGA();
                this.testDriveButtonsGA();
                this.floatTestDriveButtonGA();
                this.downloadGA();

                this.linkButtonsGA = null;
                this.testDriveButtonsGA = null;
                this.floatTestDriveButtonGA = null;
                this.downloadGA = null;
            },
            linkButtonsGA: function() {
                const self = this;

                this.linkButtons.forEach(function(button) {
                    button.addEventListener('click', function() {
                        window.dataLayer.push({
                            'event': 'PDP_banner_interaction',
                            'page_name': self.$page_name,
                            'banner_name': button.getAttribute('data-banner-name'),
                            'banner_position': button.getAttribute('data-banner-position'),
                            'link_destination': button.href,
                            'click_area': button.getAttribute('data-click-area'),
                        });
                    });
                });
            },
            testDriveButtonsGA: function() {
                const self = this;

                this.testDriveButtons.forEach(function(button) {
                    button.addEventListener('click', function() {
                        const $booking_position = button.getAttribute('data-booking-position') || null;
                        window.dataLayer.push({
                            'event': 'reservation_intent',
                            'page_name': self.$page_name,
                            'booking_position': $booking_position ? $booking_position : 'product',
                            'page_category2': self.$page_category2,
                            'aito_model': self.$aito_model,
                        });
                    });
                });
            },
            floatTestDriveButtonGA: function() {
                const self = this;

                self.floatTestDriveButton.addEventListener('click', function() {
                    window.dataLayer.push({
                        'event': 'click_float_reservation',
                        'page_name': self.$page_name,
                        'aito_model': self.$aito_model,
                    });
                });

                self.floatTestDriveButton = null;
            },
            downloadGA: function() {
                this.downloadLinks.forEach(function(link) {
                    link.addEventListener('click', function() {
                        window.dataLayer.push({
                            'event': 'home_brand_banner_interaction',
                            'page_name': self.$page_name,
                            'banner_name': link.getAttribute('data-banner-name'),
                            'banner_position': link.getAttribute('data-banner-position'),
                            'link_destination': 'https://aito.auto/model/m7/',
                            'click_area': link.getAttribute('data-click-area'),
                        });
                    });
                });
            }
        },
        testDrive: {
            floatButton: document.getElementById('section-test-drive-button'),
            init: function() {
                this.widget();
                this.widget = null;
            },
            widget: function() {
                const
                    self = this,
                    form = document.getElementById('section-test-drive'),
                    close = document.getElementById('section-form-close'),
                    mask = document.getElementById('section-test-drive-mask');

                let scrollTimeOut;


                gsap.timeline({
                    scrollTrigger: {
                        trigger: '#section-seat',
                        start: 'top 50%',
                        end: 'top 50%',
                        // markers: true,
                        onEnter: function() {
                            self.floatButton.classList.remove('hide');
                        },
                        onEnterBack: function() {
                            self.floatButton.classList.add('hide');
                        }
                    }
                });

                // hide float button when scrolling
                window.addEventListener('scroll', function() {
                    self.floatButton.classList.add('scrolling');

                    clearTimeout(scrollTimeOut);

                    scrollTimeOut = setTimeout(function() {
                        self.floatButton.classList.remove('scrolling');
                    }, 1000);
                });

                // open text drive form
                self.floatButton.addEventListener('click', function() {
                    form.classList.add('show');
                    mask.classList.add('show');
                    BODY.classList.add('form-locked');
                    self.floatButton.classList.add('hide');
                });

                // close text drive form
                close.addEventListener('click', function() {
                    form.classList.remove('show');
                    mask.classList.remove('show');
                    self.floatButton.classList.remove('hide');
                    BODY.classList.remove('form-locked');
                });
            },
        }
    };

    document.addEventListener('DOMContentLoaded', function() {
        Site.init();
        Site.init = null;
    });
}());