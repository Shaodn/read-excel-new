var superagent = require('superagent')
var fs = require('fs')
var xlsx = require('node-xlsx');
var asc = require('async');
const { exit } = require('process');
// 33
var orgUrl = 3
var orgarr = [
    '/content/panasonic/au/en/consumer',
'/content/panasonic/be/fr/consumer',
'/content/panasonic/be/nl/consumer',
'/content/panasonic/bg/bg/consumer',
'/content/panasonic/ch/de/consumer',
'/content/panasonic/ch/fr/consumer',
'/content/panasonic/cz/cs/consumer',
'/content/panasonic/de/de/consumer',
'/content/panasonic/dk/da/consumer',
'/content/panasonic/ee/et/consumer',
'/content/panasonic/es/es/consumer',
'/content/panasonic/fi/fi/consumer',
'/content/panasonic/fr/fr/consumer',
'/content/panasonic/hr/hr/consumer',
'/content/panasonic/hu/hu/consumer',
'/content/panasonic/id/id/consumer',
'/content/panasonic/it/it/consumer',
'/content/panasonic/lt/lt/consumer',
'/content/panasonic/lv/lv/consumer',
'/content/panasonic/mea/ar/consumer',
'/content/panasonic/mea/en/consumer',
'/content/panasonic/mx/es/consumo',
'/content/panasonic/my/en/consumer',
'/content/panasonic/nl/nl/consumer',
'/content/panasonic/no/no/consumer',
'/content/panasonic/nz/en/consumer',
'/content/panasonic/pe/es/consumo',
'/content/panasonic/ph/en/consumer',
'/content/panasonic/pl/pl/consumer',
'/content/panasonic/pt/pt/consumer',
'/content/panasonic/ro/ro/consumer',
'/content/panasonic/rs/sr/consumer',
'/content/panasonic/se/sv/consumer',
'/content/panasonic/sg/en/consumer',
'/content/panasonic/sk/sk/consumer',
'/content/panasonic/th/th/consumer',
'/content/panasonic/uk/en/consumer',
'/content/panasonic/vn/vi/consumer',
'/content/panasonic/vn/en/consumer',
'/content/panasonic/technics-au/en/products',
'/content/panasonic/technics-be/fr/produits',
'/content/panasonic/technics-be/nl/producten',
'/content/panasonic/technics-bg/bg/products',
'/content/panasonic/technics-ch/de/produkte',
'/content/panasonic/technics-ch/fr/produits',
'/content/panasonic/technics-cz/cs/products',
'/content/panasonic/technics-de/de/produkte',
'/content/panasonic/technics-dk/da/products',
'/content/panasonic/technics-ee/et/tooted',
'/content/panasonic/technics-es/es/productos',
'/content/panasonic/technics-fi/fi/products',
'/content/panasonic/technics-fr/fr/produits',
'/content/panasonic/technics-hr/hr/proizvodi',
'/content/panasonic/technics-hu/hu/termekek',
'/content/panasonic/technics-id/id/products',
'/content/panasonic/technics-it/it/prodotti',
'/content/panasonic/technics-lt/lt/gaminiai',
'/content/panasonic/technics-mx/es/products',
'/content/panasonic/technics-my/en/products',
'/content/panasonic/technics-nl/nl/producten',
'/content/panasonic/technics-no/no/products',
'/content/panasonic/technics-nz/en/products',
'/content/panasonic/technics-pe/es/productos',
'/content/panasonic/technics-pl/pl/produkty',
'/content/panasonic/technics-pt/pt/produtos',
'/content/panasonic/technics-ro/ro/produse',
'/content/panasonic/technics-se/sv/produkter',
'/content/panasonic/technics-sg/en/products',
'/content/panasonic/technics-sk/sk/produkty',
'/content/panasonic/technics-th/th/products',
'/content/panasonic/technics-uk/en/products',
]

var orgarr2 = [
    '/content/panasonic/tr/tr/consumer',
    '/content/panasonic/si/sl/consumer',
    '/content/panasonic/ba/bs/consumer',
    '/content/panasonic/gr/el/consumer',
]
var nowDate = new Date();
 var year = nowDate.getFullYear();
 var month = nowDate.getMonth() + 1 < 10 ? "0" + (nowDate.getMonth() + 1)
  : nowDate.getMonth() + 1;
 var day = nowDate.getDate() < 10 ? "0" + nowDate.getDate() : nowDate
  .getDate();
 var dateStr = year + month + day;
var filename = orgarr[orgUrl].split('/')[3]
var filename2 = '-'+orgarr[orgUrl].split('/')[4]
// filename2=''
var cookies = 'login-token=6c7954db-b968-4350-b995-641e489d529d%3a0043d0ae-df59-4dc6-af36-4e512d1d137d_5dd6fc97d253e2bcf9961e9603fc3709%3acrx.default'
var login_url = "https://wcp.panasonic.cn/libs/cq/core/content/login.html/j_security_check"
var browserMsg = {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"101\", \"Google Chrome\";v=\"101\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "x-requested-with": "XMLHttpRequest",
    "Referrer-Policy": "strict-origin-when-cross-origin"
};
fs.mkdirSync('./result_/'+dateStr+'/',{recursive:true});
var loginMsg = {
    j_validate: true,
    j_username: 'zhychen@cn.ibm.com',
    j_password: 'selina5',
    _charset_: 'utf8'
};
var page = [
        ['title', 'published', 'modified', 'URL','template']
    ]
var hassub = [orgarr[orgUrl]],
    subCount = 0,
    temsub = []
Array.prototype.remove = function(val) {
    var index = this.indexOf(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};
var loginin = function() {
    return new Promise(function(resolve) {
        superagent.post(login_url).set(browserMsg).send(loginMsg).redirects(0).end(function(err, response) {
            if (!err) {
                cookies = response.headers["set-cookie"][0].split(';')[0];
                //var cooki=querystring.parse(cookies[0],';')
                //var cooki=cookies.split(';')[0]
                cookies = cookies.replace(/%3a/g, ':')

            } else {
                console.dir(err);
            }
            resolve()

        })
    })
}
function isEmptyObject(obj){  

    for(var key in obj){  

        return false;

    };  

    return true;

};
var getLeaf = function(url) {
    console.log(url)
    return new Promise(function(resolve) {
        function getleafin(url) {
            temsub.remove(url)
            superagent.get('https://wcp.panasonic.cn/bin/wcm/siteadmin/tree.json')
                .query({ '_charset_': 'utf-8', 'path': url })
                .set({ Cookie: cookies })
                .end(function(err, res) {
                    if(err){
                        console.log(err)
                    }
                    subCount ++
                    var rejson = res.body
                    try {
                        rejson.forEach(function(element) {

                            // if (element.sub&&element.name!='feature'&&element.name!='template-demo1'&&element.name!='pim-panels'&&element.name!='demo-contents'&&element.name!='feature'&&element.name!='dhp-slide'&&element.name!='dhp-offer'&&element.name!='lccmcrawl'&&element.name!='system-wrapper'&&element.name!='demo'&&element.name!='consumer_top') {
                            if (element.sub&&element.name!='feature'&&element.name!='template-demo1'&&element.name!='pim-panels'&&element.name!='demo-contents'&&element.name!='feature'&&element.name!='dhp-slide'&&element.name!='dhp-offer'&&element.name!='lccmcrawl'&&element.name!='system-wrapper'&&element.name!='demo'&&element.name!='consumer_top') {
                                hassub.push(url + '/' + element.name)
                                temsub.push(url + '/' + element.name)
                            }
                            // if (element.sub) {
                            //     hassub.push(url + '/' + element.name)
                            //     temsub.push(url + '/' + element.name)
                            // }
                        });
                        
                    
                        if (subCount == hassub.length && subCount != 1 && temsub.length == 0) {
                            resolve(hassub)
                        } else {
                            temsub.forEach(function(temurl) {
                                getleafin(temurl)
                            })
                        }
                    } catch (error) {
                        let errmsg={}
                        console.log(res)
                        // console.log(res.body=="{}")
                        // // console.log(Json.stringify(res.body)=="{}")
                        // console.log(isEmptyObject(res.body),url)
                        // console.log(typeof(res.body))
                        exit;
                    }
                })
        }
        getleafin(url)
    })
}

function getdetial(url, callback) {
    var urls = 'https://wcp.panasonic.cn' + url + '.pages.json?predicate=siteadmin'
    console.log(urls)
    superagent.get(urls).set({ Cookie: cookies }).timeout({
        response: 5000,
        deadline: 20000,
      }).end(async function(err, res) {
        if (err) {
            console.log(err)
            if(res==undefined) {console.log('res is  undefined')}
            await setTimeout(() => {
               getdetial(url, callback)
            }, 2000);
        } else {
            var rejsonP = res.body.pages
            if(rejsonP){
                for (var i = 0; i < rejsonP.length; i++) {
                    if(['ProductPageV2','ProductPage'].indexOf(rejsonP[i].templateShortTitle)!=-1){
                        var Ptitle = rejsonP[i].title
                        var Purl = 'https://wcp.panasonic.cn' + rejsonP[i].path + '.html'
    
                        if (rejsonP[i].replication.action) {
                            var Pstauts = rejsonP[i].replication.action
                            if (rejsonP[i].replication.published - rejsonP[i].lastModified > 0) {
                                //publish && noone modified
                                page.push([Ptitle, Pstauts, 'no', Purl,rejsonP[i].templateShortTitle])
                            } else {
                                //publish && modified
                                page.push([Ptitle, Pstauts, 'yes', Purl,rejsonP[i].templateShortTitle])
                            }
                        } else {
                            // not publish
                            page.push([Ptitle, 'not published', 'yes', Purl,rejsonP[i].templateShortTitle])
                        }
    
                    }   
                }
            }
            
            callback(null)
        }

    })
}
var getdetail = function(catarr) {
    return new Promise(function(resolve) {
        asc.mapLimit(catarr, 1, function(url, callback) {
            getdetial(url, callback)
        }, (err, result) => {
            console.log('getdetail done')
            resolve('11111done')

        })

    })
}
// loginin().then(function() {
//     return getLeaf(orgUrl)
// }).then(function(catarr) {
//     console.log('============start find product Info==========')
//     return getdetail(catarr)
// }).then(function() {
//     var buffer = xlsx.build([{
//         name: 'product',
//         data: page
//     }]);
//     fs.writeFile('./result/sdp/' + filename + filename2 + '.xlsx', buffer, function(err) {
//         console.log('done')
//     })
// })

getLeaf(orgarr[orgUrl])
.then(function(catarr) {
    console.log('============start find product Info==========')
    return getdetail(catarr)
}).then(function() {
    var buffer = xlsx.build([{
        name: 'product',
        data: page
    }]);
    fs.writeFile('./result_/'+dateStr+'/' + filename + filename2 + '.xlsx', buffer, function(err) {
        console.log('done')
    })
})
