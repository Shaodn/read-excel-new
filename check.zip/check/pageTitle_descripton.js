var readexcel = require('./readexcel.js');
var data = readexcel.read('zhang.xlsx')
var cheerio = require('cheerio');
var superagent = require('superagent');
var async = require('async');
var fs=require('fs')
var cookies = 'login-token=95e19c2e-9dd4-430c-9234-59d0d3392cda%3ab6ad9f17-b1f2-4d2e-8ebd-7ae60c61eb0c_92a46deff5cfae19%3acrx.default';
var urls = data.urls
console.log(urls)
var fetchP = function (product) {
    return new Promise(function (resolve, reject) {
        
        superagent.get(product.url).redirects(0).end(function(err, res) {
            
            // console.log(res)
            if (err) {
                console.log(err)
                if(res==undefined) {console.log('res is  undefined')}
                if(res.statusCode == 301 || res.statusCode == 302 || res.statusCode == 303 || res.statusCode == 404) {
                    console.log('statusCode: '+res.statusCode);
                    product.status = res.statusCode;
                }
            } else {
                var $ = cheerio.load(res.text)
                product.title = $('title').eq(0).text()
                product.description = $("meta[name$='description']").attr('content')
                console.log(product.description)
                console.log(product.title)
            }
            resolve()
        })
    })
}
async.mapLimit(urls, 1, function (url, callback) {
    var product = {
        url:'',
        title:'',
        description:''
    }
    product.url = url;
    console.log(product.url)
    Promise.all([fetchP(product)]).then((result) => {
        // data.table.push(product.table)
        callback(null, product)
    })

}, function (err, result) {
    console.log(result)
    var Excel = require('exceljs');
    var workbook = new Excel.Workbook();
    var ws1 = workbook.addWorksheet('result');
    ws1.addRow(['Url','Meta Title','Meta Description'])
    for(var i = 0;i <result.length;i++){
        ws1.addRow([result[i].url,result[i].title,result[i].description])
    }
    workbook.xlsx.writeFile('./result/Rezepte.xlsx')
    .then(function(){
        console.log('生成 xlsx');
    });
})
