var Excel = require('exceljs');
var workbook = new Excel.Workbook();
var asc = require('async')
var cheerio = require('cheerio')
var superagent = require('superagent')
var cookies = 'login-token=95e19c2e-9dd4-430c-9234-59d0d3392cda%3aed1103f3-8dd3-41ba-a288-e081450a60f1_49a1111aebf50dd0%3acrx.default'
var login_url = "https://wcp.panasonic.cn/libs/cq/core/content/login.html/j_security_check"
var browserMsg = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36",
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
};
var xmlreader = require('xmlreader');
function getFirstAttr(obj) {
    for (var k in obj) return k;
}
// 读文件
async function readfile(filename) {
    await workbook.xlsx.readFile(filename)
    return workbook
}
// 写文件
async function writefile(workbook) {
    // var formdate=formatDate(new Date())
    // console.log('done')
    await workbook.xlsx.writeFile(`b.xlsx`)
    return 'done'
}
function fetchnow(idx,worksheet){
    return new Promise((resolve,reject)=>{
        let row = worksheet.getRow(idx)
       
        // let prourl=row.getCell(4).value.trim().replace('.html','/jcr:content.infinity.json')
        // let template=row.getCell(8).value.trim()
        
        if(row.getCell(4).value!=''&&row.getCell(4).value!=null){
            let prourl=row.getCell(4).value.trim()+'?wcmmode=disabled'

            console.log(prourl)
            // superagent.get(prourl).redirects(0).set(browserMsg).end((err,sres)=>{
            superagent.get(prourl).set({ Cookie: cookies }).redirects(0).set(browserMsg).end((err,sres)=>{
            if(err) {
                console.log('issue'+prourl)
                console.log(11111111111111111111)
                row.getCell(6).value=err.status
                // console.log(err)
                resolve()
                // fetchnow(idx,worksheet)
            } else{
                // console.log(sres.body)
                // if (sres.body['productpath']) {
                //     console.log(sres.body['productpath'])
                //     row.getCell(2).value=sres.body['productpath']
                // } 
                // if (sres.body['sling:vanityPath']) {
                //     console.log(sres.body['sling:vanityPath'])
                //     if (Array.isArray(sres.body['sling:vanityPath'])) {
                //         for (let i = 0; i < sres.body['sling:vanityPath'].length; i++) {
                //             row.getCell(8+i).value=sres.body['sling:vanityPath'][i]
                //         }
                //     } else {
                //         row.getCell(8).value=sres.body['sling:vanityPath']
                //     }
                // } 
                // if (sres.body['hideInNav']) {
                //     console.log(sres.body['hideInNav'])
                //     row.getCell(11).value='Yes'
                // } 
                // if (sres.body['jcr:created']) {
                //     let ctime=new Date(sres.body['jcr:created']).toLocaleString('chinese',{hour12:false})
                //     row.getCell(11).value=ctime
                // } else {
                //     LM.push(' ')
                // }
                let $ = cheerio.load(sres.text)
                // // // $('#globalheader').remove()
                var hasWord = $('html').html().indexOf('home.panasonic.cn/microwaveoven-poll') != -1 ? 'yes' : 'no';
                row.getCell(6).value = hasWord
                console.log(hasWord)
                // var pattern1 = /(\btv\snow\b)|(\btvnow\b)/gi,
                // pattern2 = /\btv\snow\b/gi,
                // pattern3 = /\btvnow\b/gi;
                // if($('#page').length>0&&pattern1.test($('#page').html())){
                //     row.getCell(7).value='yes'
                //     console.log('yes')
                // }
                // if($('#page').length>0&&pattern2.test($('#page').html())){
                //     row.getCell(7).value='yes'
                // }
                // if($('#page').length>0&&pattern3.test($('#page').html())){
                //     row.getCell(8).value='yes'
                // }
                // if($('#browsebar-buy a').length>0&&$('#browsebar-buy a').attr('href').indexOf('/consumer/air-conditioner/contact')!=-1){
                //     row.getCell(7).value='yes'
                //     console.log('yesyes')
                // }
                // let price=$('#browsebar-utils .price .price-nu').text().trim().replace('￥','').replace(',','')
                // console.log(price)
                // row.getCell(16).value=price
                
                resolve()
            }
        })
        }else{
            resolve()
        }
        
    })
}
// function fetchreview(prokey,idx,worksheet){
//     return new Promise((resolve,reject)=>{
//         if(prokey!=null){
//             let row = worksheet.getRow(idx)
//             let rurl='https://api.bazaarvoice.com/data/batch.json?passkey=catyz67N0DWMPB2LOEJHBcGeiqlRINhLvMdgOQvI9dvxs&apiversion=5.5&displaycode=12517-de_de&resource.q0=reviews&filter.q0=isratingsonly%3Aeq%3Afalse&filter.q0=productid%3Aeq%3A'+prokey+'&filter.q0=contentlocale%3Aeq%3Ade_DE&sort.q0=submissiontime%3Adesc&stats.q0=reviews&filteredstats.q0=reviews&include.q0=authors%2Cproducts%2Ccomments&filter_reviews.q0=contentlocale%3Aeq%3Ade_DE&filter_reviewcomments.q0=contentlocale%3Aeq%3Ade_DE&filter_comments.q0=contentlocale%3Aeq%3Ade_DE&limit.q0=100&offset.q0=0&limit_comments.q0=3'
//             superagent.get(rurl).set(browserMsg).end((err,sres)=>{
//                 console.log(sres.body.BatchedResults.q0.TotalResults)
//                 row.getCell(8).value=sres.body.BatchedResults.q0.TotalResults
//                 let jsonstring=JSON.stringify(sres.body)
//                 var pattern1 = /(\btv\snow\b)|(\btvnow\b)/gi
//                 if(pattern1.test(jsonstring)){
//                     row.getCell(6).value="Yes"
//                     console.log('yes')
//                 }
//                 resolve()
//             })
//         }else{
//             resolve()
//         }
        

//     })
// }

var sleep = async (duration) => {
    return new Promise((resolve, reject) => {
        setTimeout(resolve, duration);
    });
  };
async function excuteall() {
    file = await readfile('./cn-zh.xlsx')
    // 获取第一个sheet，从1开始
    let worksheet = file.getWorksheet(1)
        console.log(worksheet.rowCount)
        // console.log(worksheet.getRow(1).getCell(1).value)
    for(count=2;count <=worksheet.rowCount;count++){
   
            if(worksheet.getRow(count).getCell(1).value!=null){
                await sleep(100)
            }
            
            await fetchnow(count, worksheet)
            // await fetchreview(pkey,count, worksheet)
            if(count%20==0||count==worksheet.rowCount){
                await writefile(file)
            }
            
            
        
        
     
    }
    
  
    console.log('alldone')
}
excuteall()