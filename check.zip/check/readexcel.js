var xlsx = require('node-xlsx');
var data = {
    urls:[]
}
module.exports={
    read:function(filename){
        var obj = xlsx.parse(filename);
        
        obj[0].data.forEach((url,idx) => {
            if(idx > 0){
                data.urls.push(url[0])
            }
            
        });
        return(data)
    }
}