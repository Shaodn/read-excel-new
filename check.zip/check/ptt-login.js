let cookies="ptt_time_enforcement_warnings=0; ppt_user=Zhi.Chen%40concentrix.com;PHPSESSID=sq8etb756gh1jjuo7k9540ipo6;"
let superagent=require("superagent")
let browserMsg={
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-User': '?1',
    'Sec-Fetch-Dest': 'document',
}
var browserMsgLogin = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-language": "en-US,en;q=0.9,zh;q=0.8,fr;q=0.7,de;q=0.6,en-GB;q=0.5,it;q=0.4,zh-CN;q=0.3,uk;q=0.2,cs;q=0.1",
    "cache-control": "no-cache",
    "content-type": "application/x-www-form-urlencoded",
    "pragma": "no-cache",
    "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"102\", \"Google Chrome\";v=\"102\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "cookie": "ptt_time_enforcement_warnings=0; ptt_user_name=Zhi.Chen%40concentrix.com; ppt_user=Zhi.Chen%40concentrix.com; PHPSESSID=sq8etb756gh1jjuo7k9540ipo6",
    "Referer": "https://live.pttgps.com/track/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
};
let login=function(){
    return new Promise(function(resolve) {
    let form={
        'login': 'Login',
        'password': 'chenzhiyue2047!',
        'username': 'Zhi.Chen@concentrix.com'
      }
        let superagent=require("superagent")
        superagent.post('https://live.pttgps.com/track/').send(form).set(browserMsgLogin).end(function(err,res){
            
            // cookies += (res.header["set-cookie"][0].split(";")[0])
            // console.log(res.header["set-cookie"][0].split(";")[0])
            console.log("login")
            resolve()
        })
    })
}
let cheerio=require("cheerio")
let fetchptt=function(pttid){
    return new Promise((resolve,reject)=>{
        superagent.get("https://live.pttgps.com/track/asig_alt/displaya_new.php").query({"editid":pttid}).set({Cookie:cookies}).set(browserMsg).end(function(err,res){
           

            let $ = cheerio.load(res.text);
           
                
            //    cookies = "ptt_time_enforcement_warnings=0; ppt_user=Zhi.Chen%40concentrix.com;"+res.header["set-cookie"][0].split(";")[0]
          
               if($("#password").length>0){
                    reject("login")
               }else{

                console.log($("#setpdis").html()) 
                resolve()
               }
               
            
        })
    })
}
let excuse=async (id)=>{
    try{
        await fetchptt(id)
    }catch{
        await login()
        await fetchptt(id)
    }
    
}
excuse(1456233)