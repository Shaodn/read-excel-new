var readexcel = require('./readexcel.js');
var data = readexcel.read('url.xlsx')
var cheerio = require('cheerio');
var superagent = require('superagent');
var async = require('async');
var fs=require('fs')
var cookies = 'login-token=95e19c2e-9dd4-430c-9234-59d0d3392cda%3a8a109a5a-44fd-4834-83af-ae657b2c27f9_89acfed9967fc053%3acrx.default';
var urls = data.urls
var browserMsg = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36",
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
};

var fetchP = function (product) {
    return new Promise(function (resolve, reject) {
        
        superagent.get(product.url).set({ Cookie: cookies }).set(browserMsg).redirects(0).end(function(err, res) {
            // if(err){console.log(err)}
            if(res){
                if(res.statusCode == '301' || res.statusCode == '302'){
                    // product.status = 'yes'
                    // product.redirect = res.header.location
                }
                product.productpath = res.body.productpath
                console.log(product.productpath)
                console.log(product.productpath.split('/').pop())
            }
            resolve()
        })
    })
}
var index = 0
async.mapLimit(urls, 1, function (url, callback) {
    var product = {
        url:'',
        productpath:'',
    }
    url = url.replace('.html', '')        
    url += '/jcr:content.infinity.json'
    product.url = url;
    index++
    console.log(index)
    console.log(product.url)
    
    Promise.all([fetchP(product)]).then((result) => {
        callback(null, product)
    })

}, function (err, result) {
    var Excel = require('exceljs');
    var workbook = new Excel.Workbook();
    var ws1 = workbook.addWorksheet('result');
    ws1.addRow(['Url','DISCONTINUED'])
    for(var i = 0;i <result.length;i++){
        ws1.addRow([result[i].url,result[i].productpath,result[i].productpath.split('/').pop()])
    }
    workbook.xlsx.writeFile('./result/result.xlsx')
    .then(function(){
        console.log('生成 xlsx');
    });
})


// var fetchP = function (product) {
//     return new Promise(function (resolve, reject) {
        
//         superagent.get(product.url).set(browserMsg).redirects(0).end(function(err, res) {
//             // if(err){console.log(err)}
//             if(res){
//                 var $ = cheerio.load(res.text)
//                 var item = [];
//                 item.push(product.url)
//                 item.push($('.specs-colors dd').length)
//                 $('.specs-colors dd').each((idx,ele) => {
//                     item.push($(ele).find('img').attr('data-vari-name'))
//                 })
//                 product.content.push(item)
//                 console.log(item)
//             }
//             resolve()
//         })
//     })
// }
// var index = 0
// async.mapLimit(urls, 1, function (url, callback) {
//     var product = {
//         url:'',
//         content:[],
//     }
//     // url = url.replace('.html', '')        
//     // url += '/jcr:content.infinity.json'
//     product.url = url;
//     index++
//     console.log(index)
//     console.log(product.url)
    
//     Promise.all([fetchP(product)]).then((result/jcr:content.infinity.json) => {
//         callback(null, product)
//     })

// }, function (err, result) {
//     var Excel = require('exceljs');
//     var workbook = new Excel.Workbook();
//     var ws1 = workbook.addWorksheet('result');
//     ws1.addRow(['Url','len','color'])
//     for(var i = 0;i <result.length;i++){
//         for(var j = 0;j < result[i].content.length;j++){
//             ws1.addRow(result[i].content[j])
//         }
//     }
//     workbook.xlsx.writeFile('./result/result.xlsx')
//     .then(function(){
//         console.log('生成 xlsx');
//     });
// })