var superagent = require('superagent')
var fs = require('fs')
var xlsx = require('node-xlsx');
var asc = require('async')
var orgUrl = '/content/panasonic/be/fr/promotions'
// var orgUrl = '/content/panasonic/uk/en/consumer'
var filename = orgUrl.split('/')[3]
var filename2 = '-'+orgUrl.split('/')[4]
var filename3 = orgUrl.split('/')[5] != 'consumer' && orgUrl.split('/')[5] ?  '-'+orgUrl.split('/')[5] : ''
var cookies = 'login-token=6c7954db-b968-4350-b995-641e489d529d%3a517b5a4d-9ee6-4403-a476-e63e291e7801_e459d169fe30eb81c30a48e645e6fe08%3acrx.default'
var login_url = "https://wcp.panasonic.cn/libs/granite/core/content/login.html/j_security_check"

var browserMsg = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36",
    
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9,de;q=0.8,en-GB;q=0.7,it;q=0.6,zh-CN;q=0.5,zh;q=0.4,uk;q=0.3,cs;q=0.2",
    "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
    "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"98\", \"Google Chrome\";v=\"98\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "Referer": "https://wcp.panasonic.cn/libs/granite/core/content/login.html?resource=%2Fsiteadmin&$$login$$=%24%24login%24%24&j_reason=unknown&j_reason_code=unknown",
    "Referrer-Policy": "strict-origin-when-cross-origin"
};
var loginMsg = {
    j_validate: true,
    j_username: 'zhychen@cn.ibm.com',
    j_password: 'selina5',
    _charset_: 'utf8'
};
var resultcat = [
    ['title', 'published', 'modified', 'URL']
],
    resultpro = [
        ['title', 'published', 'modified', 'URL', 'hide']
    ],
    resultLMcat = [
        ['title', 'published', 'modified', 'URL', 'publish date','create time']
    ],
    resultLMcategory = [
        ['title', 'published', 'modified', 'URL']
    ]

var hassub = [orgUrl],
    subCount = 0,
    temsub = []
Array.prototype.remove = function (val) {
    var index = this.indexOf(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};
function timestampToTime(timestamp) {
    var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = date.getDate();
    var h = date.getHours() + ':';
    var m = date.getMinutes() + ':';
    var s = date.getSeconds();
    return Y + M + D + ' ' + h + m + s;
}
var loginin = function () {
    return new Promise(function (resolve) {
        superagent.post(login_url).set(browserMsg).send(loginMsg).redirects(0).end(function (err, response) {
            if (!err) {
                cookies = response.headers["set-cookie"][0].split(';')[0];
                //var cooki=querystring.parse(cookies[0],';')
                //var cooki=cookies.split(';')[0]
                cookies = cookies.replace(/%3a/g, ':')
            } else {
                console.dir(err);
            }
            resolve()

        })
    })
}
var getLeaf = function (url) {
    return new Promise(function (resolve) {
        function getleafin(url) {
            temsub.remove(url)
            superagent.get('https://wcp.panasonic.cn/bin/wcm/siteadmin/tree.json')
                .query({ '_charset_': 'utf-8', 'path': url })
                .set({ Cookie: cookies })
                .end(function (err, res) {
                    if (err) {
                        console.log(err)
                    }
                    subCount++
                    var rejson = res.body
                    rejson.forEach(function (element) {

                        if (element.sub && element.name != 'feature' && element.name != 'aspire' && element.name != 'pim-panels') {
                            hassub.push(url + '/' + element.name)
                            temsub.push(url + '/' + element.name)
                        }
                    });
                    if (subCount == hassub.length && subCount != 1 && temsub.length == 0) {
                        resolve(hassub)
                    } else {
                        temsub.forEach(function (temurl) {
                            getleafin(temurl)
                        })
                    }
                })
        }
        getleafin(url)
    })
}

function getdetial(url, callback) {
    var urls = 'https://wcp.panasonic.cn' + url + '.pages.json?predicate=siteadmin'
    superagent.get(urls).set({ Cookie: cookies }).redirects(0).end(async function (err, res) {
        console.log(url)
        if (err) {
            console.log(err)
            if (res == undefined) { console.log('res is  undefined') }
            if (res.statusCode == 302) { console.log('302'); callback(null) } else {
                await setTimeout(() => {
                    getdetial(url, callback)
                }, 2000);
            }

        } else {
            var rejsonP = res.body.pages
            for (var i = 0; i < rejsonP.length; i++) {
                if (rejsonP[i].templateShortTitle == 'ProductPage') {
                    //产品页
                    var Ptitle = rejsonP[i].title
                    var Purl = 'https://wcp.panasonic.cn' + rejsonP[i].path + '.html'

                    if (rejsonP[i].replication.action) {
                        var Pstauts = rejsonP[i].replication.action
                        if (rejsonP[i].replication.published - rejsonP[i].lastModified > 0) {
                            //publish && noone modified
                            resultpro.push([Ptitle, Pstauts, 'no', Purl])
                        } else {
                            //publish && modified
                            resultpro.push([Ptitle, Pstauts, 'yes', Purl])
                        }
                    } else {
                        // not publish
                        resultpro.push([Ptitle, 'not published', 'yes', Purl])
                    }

                } else if (rejsonP[i].templateShortTitle == 'CategoryBrowsePage') {
                    var Ctitle = rejsonP[i].title
                    var Curl = 'https://wcp.panasonic.cn' + rejsonP[i].path + '.html'
                    if (rejsonP[i].replication.action) {
                        var Cstauts = rejsonP[i].replication.action
                        if (rejsonP[i].replication.published - rejsonP[i].lastModified > 0) {
                            //publish && noone modified
                            resultcat.push([Ctitle, Cstauts, 'no', Curl])
                        } else {
                            //publish && modified
                            resultcat.push([Ctitle, Cstauts, 'yes', Curl])
                        }
                    } else {
                        // not publish
                        resultcat.push([Ctitle, 'not published', 'yes', Curl])
                    }
                } else if (rejsonP[i].templateShortTitle == 'LearnContent') {
                    var Ctitle = rejsonP[i].title
                    var Curl = 'https://wcp.panasonic.cn' + rejsonP[i].path + '.html'
                    if (rejsonP[i].replication.action) {
                        var Cstauts = rejsonP[i].replication.action
                        let publishtime=timestampToTime(rejsonP[i].replication.published) 
                        if (rejsonP[i].replication.published - rejsonP[i].lastModified > 0) {
                            //publish && noone modified
                            resultLMcat.push([Ctitle, Cstauts, 'no', Curl,publishtime])
                        } else {
                            //publish && modified
                            resultLMcat.push([Ctitle, Cstauts, 'yes', Curl,publishtime])
                        }
                    } else {
                        // not publish
                        resultLMcat.push([Ctitle, 'not published', 'yes', Curl,''])
                    }
                } else if (rejsonP[i].templateShortTitle == 'CategoryLearn') {
                    var Ctitle = rejsonP[i].title
                    var Curl = 'https://wcp.panasonic.cn' + rejsonP[i].path + '.html'
                    if (rejsonP[i].replication.action) {
                        var Cstauts = rejsonP[i].replication.action
                        if (rejsonP[i].replication.published - rejsonP[i].lastModified > 0) {
                            //publish && noone modified
                            resultLMcategory.push([Ctitle, Cstauts, 'no', Curl])
                        } else {
                            //publish && modified
                            resultLMcategory.push([Ctitle, Cstauts, 'yes', Curl])
                        }
                    } else {
                        // not publish
                        resultLMcategory.push([Ctitle, 'not published', 'yes', Curl])
                    }
                }

            }
            callback(null)
        }

    })
}
var getdetail = function (catarr) {
    return new Promise(function (resolve) {
        asc.mapLimit(catarr, 1, function (url, callback) {
            getdetial(url, callback)
        }, (err, result) => {
            console.log('getdetail done')
            resolve('11111done')

        })

    })
}

function getpagedetail(pro, callback) {
    var url = pro[3]
    if (url != 'URL') {
        console.log(url)
        url = url.replace('.html', '')
        url += '/jcr:content.2.json'
        superagent.get(url).set({ Cookie: cookies }).end(async function (err, res) {
            if (err) {
                console.log(err)
                if (err.status == 300) {
                    callback(null, null)
                } else {
                    await setTimeout(() => {
                        getpagedetail(pro, callback)
                    }, 2000);
                }

            } else {
                console.log(res.body['jcr:created'])
                if (res.body['jcr:created']) {
                    pro.push(res.body['jcr:created'])
                } else {
                    pro.push(' ')
                }
                if (res.body['shopbar']) {
                    if (res.body['shopbar']['buylink']) {
                        pro.push(res.body['shopbar']['buylink'])
                    } else {
                        pro.push(' ')
                    }
                    if (res.body['shopbar']['wheretobuylink']) {
                        pro.push(res.body['shopbar']['wheretobuylink'])
                    } else {
                        pro.push(' ')
                    }
                } else {
                    pro.push(' ')
                    pro.push(' ')
                }

                callback(null, null)

            }


        })

    } else {
        callback(null, null)
    }


}
var getpage = function (resultpro) {
    return new Promise(function (resolve) {
        asc.mapLimit(resultpro, 1, function (pro, callback) {
            getpagedetail(pro, callback)
            // if(pro[0] != 'Kup wybrane modele aparatów Panasonic z wydłużoną 5-letnią gwarancją'){
            //     getpagedetail(pro, callback)
            // }else{
            //     for(var i = 0; i < pro.length;i++){
            //         pro[i] = encodeURI(pro[i])
            //     }
            //     getpagedetail(pro, callback)
            // }
            
        }, function (err, result) {
            // console.log(resultpro)
            resolve('done')
        })
    })
}
var getcatgory = function () {
    return new Promise(function (resolve) {
        var categoryArr = []
        var productArr = []
        var maxC = 0
        for (var i = 1; i < resultcat.length; i++) {

            var catnNameArr = resultcat[i][3].replace('.html', '').split(orgUrl)[1].split('/')
            var catName = catnNameArr[catnNameArr.length - 1]
            var catTitle = resultcat[i][0]
            categoryArr.push([catTitle, catName])
        }
        for (var p = 1; p < resultpro.length; p++) {
            productArr[p] = []

            var productNameArr = resultpro[p][3].replace('.html', '').split(orgUrl)[1].split('/')
            // console.log(productNameArr)
            if (productNameArr.length - 2 > maxC) {
                //获得最大几个category
                maxC = productNameArr.length - 2
            }
            for (var c = 1; c < productNameArr.length - 1; c++) {
                for (var cA = 0; cA < categoryArr.length; cA++) {
                    if (productNameArr[c] == categoryArr[cA][1]) {
                        productArr[p][c - 1] = categoryArr[cA][0]
                    }
                }
            }
        }

        for (var p = 1; p < resultpro.length; p++) {
            for (var maxCi = 0; i < maxC; maxCi++) {
                if (productArr[p][maxCi] == undefined) {
                    productArr[p][maxCi] = ''
                }
            }
            productArr[p][maxC] = resultpro[p][0]
            productArr[p][maxC + 1] = resultpro[p][1]
            productArr[p][maxC + 2] = resultpro[p][2]
            productArr[p][maxC + 3] = resultpro[p][3]
            productArr[p][maxC + 4] = resultpro[p][4]
            productArr[p][maxC + 5] = resultpro[p][5]
            productArr[p][maxC + 6] = resultpro[p][6]
        }

        productArr[0] = []
        for (var i = 0; i < maxC; i++) {
            var catnum = i
            productArr[0][i] = 'cat' + (catnum + 1)
        }

        productArr[0][maxC] = 'title'
        productArr[0][maxC + 1] = 'published'
        productArr[0][maxC + 2] = 'modified'
        productArr[0][maxC + 3] = 'URL'
        productArr[0][maxC + 4] = 'create time'
        productArr[0][maxC + 5] = 'buylink'
        productArr[0][maxC + 6] = 'wheretobuylink'
        // console.log(productArr[0])
        resolve(productArr)

    })
}
loginin().then(function () {
    return getLeaf(orgUrl)
}).then(function (catarr) {
    console.log('============start find product Info==========')
    return getdetail(catarr)
}).then(function () {
    //  return getpage(resultpro)
}).then(function () {
    return getpage(resultLMcat)
}).then(function () {
    return getcatgory()
}).then(function (productArr) {
    var buffer = xlsx.build([
        {
            name: 'LM',
            data: resultLMcat
        },
        // {
        //     name: 'product',
        //     data: productArr
        // },
        // {
        //     name: 'category',
        //     data: resultcat
        // },
        // {
        //     name: 'LMcategory',
        //     data: resultLMcategory
        // }
    ]);
    if(filename.indexOf('technics') == -1){
        fs.writeFile('./result-czm/panasonic/' + filename + filename2 + filename3 + '.xlsx', buffer, function (err) {
            console.log('done')
        })
    }else{
        fs.writeFile('./result-czm/technics/' + filename + filename2 + filename3 + '.xlsx', buffer, function (err) {
            console.log('done')
        })
    }
    
    
})
