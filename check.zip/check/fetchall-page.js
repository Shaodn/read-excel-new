var superagent = require('superagent')
var fs = require('fs')
var xlsx = require('node-xlsx');
var asc = require('async')
var orgUrl = '/content/panasonic/ca/fr'
var filename = orgUrl.split('/')[3]
var filename2 = '-'+orgUrl.split('/')[4]
// filename2=''
var cookies = 'login-token=95e19c2e-9dd4-430c-9234-59d0d3392cda%3a421071c5-dea6-440a-a893-89746a8c9724_2087767088976a5b%3acrx.default'
var login_url = "https://wcp.panasonic.cn/libs/cq/core/content/login.html/j_security_check"
var browserMsg = {
    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36",
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
};
var loginMsg = {
    j_validate: true,
    j_username: 'zhychen@cn.ibm.com',
    j_password: 'selina5',
    _charset_: 'utf8'
};
var page = [
        ['title', 'published', 'modified', 'URL','template']
    ]
var hassub = [orgUrl],
    subCount = 0,
    temsub = []
Array.prototype.remove = function(val) {
    var index = this.indexOf(val);
    if (index > -1) {
        this.splice(index, 1);
    }
};
var loginin = function() {
    return new Promise(function(resolve) {
        superagent.post(login_url).set(browserMsg).send(loginMsg).redirects(0).end(function(err, response) {
            if (!err) {
                cookies = response.headers["set-cookie"][0].split(';')[0];
                //var cooki=querystring.parse(cookies[0],';')
                //var cooki=cookies.split(';')[0]
                cookies = cookies.replace(/%3a/g, ':')

            } else {
                console.dir(err);
            }
            resolve()

        })
    })
}
var getLeaf = function(url) {
    return new Promise(function(resolve) {
        function getleafin(url) {
            temsub.remove(url)
            superagent.get('https://wcp.panasonic.cn/bin/wcm/siteadmin/tree.json')
                .query({ '_charset_': 'utf-8', 'path': url })
                .set({ Cookie: cookies })
                .end(function(err, res) {
                    subCount++
                    var rejson = res.body
                    rejson.forEach(function(element) {

                        if (element.sub&&element.name!='feature'&&element.name!='template-demo1'&&element.name!='pim-panels'&&element.name!='demo-contents'&&element.name!='feature'&&element.name!='dhp-slide'&&element.name!='dhp-offer'&&element.name!='lccmcrawl'&&element.name!='system-wrapper') {
                            hassub.push(url + '/' + element.name)
                            temsub.push(url + '/' + element.name)
                        }
                        // if (element.sub) {
                        //     hassub.push(url + '/' + element.name)
                        //     temsub.push(url + '/' + element.name)
                        // }
                    });
                    if (subCount == hassub.length && subCount != 1 && temsub.length == 0) {
                        resolve(hassub)
                    } else {
                        temsub.forEach(function(temurl) {
                            getleafin(temurl)
                        })
                    }
                })
        }
        getleafin(url)
    })
}

function getdetial(url, callback) {
    var urls = 'https://wcp.panasonic.cn' + url + '.pages.json?predicate=siteadmin'
    superagent.get(urls).set({ Cookie: cookies }).end(async function(err, res) {
        console.log(url)
        if (err) {
            console.log(err)
            if(res==undefined) {console.log('res is  undefined')}
            await setTimeout(() => {
               getdetial(url, callback)
            }, 2000);
        } else {
            var rejsonP = res.body.pages
            for (var i = 0; i < rejsonP.length; i++) {
                // if(rejsonP[i].templateShortTitle=='ProductPage'){
                    var Ptitle = rejsonP[i].title
                    var Purl = 'https://wcp.panasonic.cn' + rejsonP[i].path + '.html'

                    if (rejsonP[i].replication.action) {
                        var Pstauts = rejsonP[i].replication.action
                        if (rejsonP[i].replication.published - rejsonP[i].lastModified > 0) {
                            //publish && noone modified
                            page.push([Ptitle, Pstauts, 'no', Purl,rejsonP[i].templateShortTitle])
                        } else {
                            //publish && modified
                            page.push([Ptitle, Pstauts, 'yes', Purl,rejsonP[i].templateShortTitle])
                        }
                    } else {
                        // not publish
                        page.push([Ptitle, 'not published', 'yes', Purl,rejsonP[i].templateShortTitle])
                    }

                // }   
            }
            callback(null)
        }

    })
}
var getdetail = function(catarr) {
    return new Promise(function(resolve) {
        asc.mapLimit(catarr, 1, function(url, callback) {
            getdetial(url, callback)
        }, (err, result) => {
            console.log('getdetail done')
            resolve('11111done')

        })

    })
}
// loginin().then(function() {
//     return getLeaf(orgUrl)
// }).then(function(catarr) {
//     console.log('============start find product Info==========')
//     return getdetail(catarr)
// }).then(function() {
//     var buffer = xlsx.build([{
//         name: 'product',
//         data: page
//     }]);
//     fs.writeFile('./result/' + filename + '-all.xlsx', buffer, function(err) {
//         console.log('done')
//     })
// })
getLeaf(orgUrl)
.then(function(catarr) {
    console.log('============start find product Info==========')
    return getdetail(catarr)
}).then(function() {
    var buffer = xlsx.build([{
        name: 'product',
        data: page
    }]);
    fs.writeFile('./results/wyy/' + filename + filename2 + '.xlsx', buffer, function(err) {
        console.log('done')
    })
})